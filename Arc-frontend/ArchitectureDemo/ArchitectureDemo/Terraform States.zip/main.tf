resource "azurerm_resource_group" "res-0" {
  location = "eastus"
  name     = "amedeusnevio_rg"
  tags = {
    application = "amedeus"
  }
}
resource "azurerm_api_management" "res-1" {
  location             = "eastus"
  name                 = "NevioServiceCenterAPIM"
  publisher_email      = "savitha.ekambaram@tcs.com"
  publisher_name       = "NevioServiceCenter"
  resource_group_name  = "amedeusnevio_rg"
  sku_name             = "Developer_1"
  virtual_network_type = "External"
  virtual_network_configuration {
    subnet_id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Network/virtualNetworks/amadeusnevio-vn/subnets/APIM-Subnet"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_api_management_api_version_set" "res-3" {
  api_management_name = "NevioServiceCenterAPIM"
  display_name        = "func-checkout-confirm-dev-eus"
  name                = "6899c4f11de3e935a8ffefb8"
  resource_group_name = "amedeusnevio_rg"
  versioning_scheme   = "Segment"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_api" "res-4" {
  api_management_name   = "NevioServiceCenterAPIM"
  name                  = "app-config"
  resource_group_name   = "amedeusnevio_rg"
  revision              = "1"
  subscription_required = false
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_api_policy" "res-5" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "app-config"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api.res-4
  ]
}
resource "azurerm_api_management_api_schema" "res-6" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "app-config"
  content_type        = "application/vnd.ms-azure-apim.graphql.schema"
  resource_group_name = "amedeusnevio_rg"
  schema_id           = "graphql"
  value               = "directive @extends on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\ndirective @external(reason: String) on\r\n  | OBJECT\r\n  | FIELD_DEFINITION\r\n\r\ndirective @key(fields: _FieldSet!, resolvable: Boolean = true) on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\n# Indicates exactly one field must be supplied and this field must not be `null`.\r\ndirective @oneOf on\r\n  | INPUT_OBJECT\r\n\r\ndirective @provides(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\ndirective @requires(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\n# Exposes a URL that specifies the behavior of this scalar.\r\ndirective @specifiedBy(\r\n  # The URL that specifies the behavior of this scalar.\r\n  url: String!\r\n) on\r\n  | SCALAR\r\n\r\ndirective @tag(name: String!) on\r\n  | FIELD_DEFINITION\r\n  | OBJECT\r\n  | INTERFACE\r\n  | UNION\r\n  | ARGUMENT_DEFINITION\r\n  | SCALAR\r\n  | ENUM\r\n  | ENUM_VALUE\r\n  | INPUT_OBJECT\r\n  | INPUT_FIELD_DEFINITION\r\n\r\nschema {\r\n  query: Query\r\n  mutation: Mutation\r\n}\r\n\r\ntype Airline {\r\n  name: String\r\n  airlinecode: String\r\n}\r\n\r\ninput AirlineInput {\r\n  name: String\r\n  airlinecode: String\r\n}\r\n\r\ntype Airport {\r\n  airportcode: String\r\n  airportname: String\r\n  airline: Airline\r\n  city: City\r\n}\r\n\r\ninput AirportInput {\r\n  airportcode: String\r\n  airportname: String\r\n  airlinecode: String\r\n  citycode: String\r\n}\r\n\r\ntype CabinTypes {\r\n  code: String\r\n  name: String\r\n  airline: Airline\r\n}\r\n\r\ninput CabinTypesInput {\r\n  code: String\r\n  name: String\r\n  airlinecode: String\r\n}\r\n\r\ntype City {\r\n  citycode: String\r\n  cityname: String\r\n  airline: Airline\r\n  country: Country\r\n}\r\n\r\ninput CityInput {\r\n  citycode: String\r\n  cityname: String\r\n  airlinecode: String\r\n  countrycode: String\r\n}\r\n\r\ntype Country {\r\n  countrycode: String\r\n  countryname: String\r\n  airline: Airline\r\n}\r\n\r\ninput CountryInput {\r\n  countrycode: String\r\n  countryname: String\r\n  airlinecode: String\r\n}\r\n\r\ninput CreateNotificationInput {\r\n  airlinecode: String!\r\n  message: String\r\n  enddate: Date\r\n  startdate: Date\r\n}\r\n\r\ntype Currency {\r\n  currencycode: String\r\n  currencyname: String\r\n  airline: Airline\r\n  country: Country\r\n}\r\n\r\ninput CurrencyInput {\r\n  currencycode: String\r\n  currencyname: String\r\n  airlinecode: String\r\n  countrycode: String\r\n}\r\n\r\n# A date string, such as 2007-12-03, compliant with the `full-date` format outlined in section 5.6 of the RFC 3339 profile of the ISO 8601 standard for representation of dates and times using the Gregorian calendar.\r\nscalar Date\r\n\r\ntype DeleteResponse {\r\n  errors: [Errors]\r\n  warnings: [Warnings]\r\n}\r\n\r\ntype Errors {\r\n  code: String\r\n  message: String\r\n  severity: Int\r\n}\r\n\r\ntype FareType {\r\n  cffcode: String\r\n  farename: String\r\n  airline: Airline\r\n  country: Country\r\n}\r\n\r\ntype FrequentFlyerPrograms {\r\n  companycode: String\r\n  name: String\r\n  airline: Airline\r\n}\r\n\r\ntype Languages {\r\n  code: String\r\n  name: String\r\n  airline: Airline\r\n}\r\n\r\ninput LanguagesInput {\r\n  code: String\r\n  name: String\r\n  airlinecode: String\r\n}\r\n\r\ntype Mutation {\r\n  createAirline(input: AirlineInput): Response\r\n  deleteAirline(airlinecode: String): DeleteResponse\r\n  updateAirline(airlinecode: String!, input: AirlineInput): Response\r\n  createAirport(input: AirportInput): Response\r\n  deleteAirport(input: AirportInput): DeleteResponse\r\n  updateAirport(existingData: AirportInput, input: AirportInput): Response\r\n  createCity(input: CityInput): Response\r\n  deleteCity(input: CityInput): DeleteResponse\r\n  updateCity(existingData: CityInput, input: CityInput): Response\r\n  createCountry(input: CountryInput): Response\r\n  deleteCountry(input: CountryInput): DeleteResponse\r\n  updateCountry(existingData: CountryInput, input: CountryInput): Response\r\n  createCurrency(input: CurrencyInput): Response\r\n  deleteCurrency(input: CurrencyInput): DeleteResponse\r\n  updateCurrency(existingData: CurrencyInput, input: CurrencyInput!): Response\r\n  createFareType(input: fareTypeInput): Response\r\n  deleteFareType(input: fareTypeInput): DeleteResponse\r\n  updateFareType(existingData: fareTypeInput, input: fareTypeInput): Response\r\n  createFrequentFlyerPrograms(input: frequentflyerprogramsInput): Response\r\n  deleteFrequentFlyerPrograms(input: frequentflyerprogramsInput): DeleteResponse\r\n  updateFrequentFlyerPrograms(existingData: frequentflyerprogramsInput, input: frequentflyerprogramsInput): Response\r\n  createPassengerTypes(input: passengerTypesInput): Response\r\n  deletePassengerTypes(input: passengerTypesInput): DeleteResponse\r\n  updatePassengerTypes(existingData: passengerTypesInput, input: passengerTypesInput): Response\r\n  createPTCDiscountCodes(input: PtcDiscountCodesInput): Response\r\n  deletePTCDiscountCodes(input: PtcDiscountCodesInput): DeleteResponse\r\n  updatePTCDiscountCodes(existingData: PtcDiscountCodesInput, input: PtcDiscountCodesInput): Response\r\n  createWaiverReason(input: WaiverReasonsInput): Response\r\n  deleteWaiverReason(input: WaiverReasonsInput): DeleteResponse\r\n  updateWavierReason(ExistingData: WaiverReasonsInput, input: WaiverReasonsInput): Response\r\n  createRole(input: RoleInput!): RoleResponse!\r\n  createRolePermission(input: RolePermissionInput!): RolePermissionResponse!\r\n  updateRole(role: RoleInput!, input: RoleInput!): RoleResponse!\r\n  deleteRole(input: RoleDeleteInput!): String!\r\n  deleteRolePermission(input: RolePermissionInput!): String!\r\n  createCabinTypes(input: CabinTypesInput): Response\r\n  deleteCabinTypes(input: CabinTypesInput): DeleteResponse\r\n  updateCabinTypes(existingData: CabinTypesInput, input: CabinTypesInput): Response\r\n  createTripTypes(input: TripTypesInput): Response\r\n  deleteTripTypes(input: TripTypesInput): DeleteResponse\r\n  updateTripTypes(existingData: TripTypesInput, input: TripTypesInput): Response\r\n  createShoppingType(input: ShoppingTypesInput): Response\r\n  deleteShoppingTypes(input: ShoppingTypesInput): DeleteResponse\r\n  updateShoppingTypes(existingData: ShoppingTypesInput, input: ShoppingTypesInput): Response\r\n  createLanguages(input: LanguagesInput): Response\r\n  deleteLanguages(input: LanguagesInput): DeleteResponse\r\n  updateLanguages(existingData: LanguagesInput, input: LanguagesInput): Response\r\n  createNotification(input: CreateNotificationInput): NotificationMutationResponse\r\n  updateNotification(id: Int, input: CreateNotificationInput): NotificationMutationResponse\r\n  deleteNotification(id: Int): NotificationDeleteResponse\r\n}\r\n\r\ntype Notification {\r\n  id: Int\r\n  message: String\r\n  startdate: Date\r\n  enddate: Date\r\n}\r\n\r\ntype NotificationDeleteResponse {\r\n  warnings: [Warning]\r\n  data: Status\r\n}\r\n\r\ntype NotificationMutationResponse {\r\n  warnings: [Warning]\r\n  data: Notification\r\n}\r\n\r\ntype NotificationQueryResponse {\r\n  warnings: [Warning]\r\n  data: [Notification]\r\n}\r\n\r\ntype PTCDiscountCodes {\r\n  discountcode: String\r\n  name: String\r\n  airline: Airline\r\n  passengertypes: PassengerTypes\r\n}\r\n\r\ntype PassengerTypes {\r\n  code: String\r\n  name: String\r\n  age_lower_bound: Int\r\n  age_upper_bound: Int\r\n  airline: Airline\r\n}\r\n\r\ntype PermissionResponse {\r\n  warnings: [Warnings]\r\n  response: Permissions\r\n}\r\n\r\ntype Permissions {\r\n  permission: String\r\n  description: String\r\n}\r\n\r\ntype PermissionsResponse {\r\n  warnings: [Warnings]\r\n  response: [Permissions]\r\n}\r\n\r\ninput PtcDiscountCodesInput {\r\n  discountcode: String\r\n  airlinecode: String\r\n  name: String\r\n  passengertype: String\r\n}\r\n\r\ntype Query {\r\n  getAirline(airlinecode: String): Response\r\n  getAirlines: Response\r\n  _service: _Service!\r\n  getAirports(airlinecode: String!): Response\r\n  getCities(airlinecode: String): Response\r\n  getCountries(airlinecode: String!): Response\r\n  getCurrencies(airlinecode: String!): Response\r\n  getFareType(airlinecode: String!): Response\r\n  getFrequentFlyerPrograms(airlinecode: String!): Response\r\n  getPassengerTypes(airlinecode: String!): Response\r\n  getPTCDiscountCodes(airlinecode: String!): Response\r\n  getWaiverReasons(airlinecode: String!): Response\r\n  getRoles(airlinecode: String!): RolesResponse!\r\n  getPermissions: PermissionsResponse!\r\n  getRolepermissions(input: RolePermissionQueryInput): RolePermissionsResponse!\r\n  getCabinTypes(airlinecode: String!): Response\r\n  getTripTypes(airlinecode: String): Response\r\n  getShoppingTypes(airlinecode: String): Response\r\n  getLanguages(airlinecode: String!): Response\r\n  getNotifications(airlinecode: String): NotificationQueryResponse\r\n}\r\n\r\ntype Response {\r\n  errors: [Errors]\r\n  warnings: [Warnings]\r\n  data: [ResponseData]\r\n}\r\n\r\nunion ResponseData = Airline | Airport | City | Country | Currency | FareType | FrequentFlyerPrograms | PassengerTypes | PTCDiscountCodes | WaiverReasons | CabinTypes | TripTypes | ShoppingTypes | Languages\r\n\r\ninput RoleDeleteInput {\r\n  role: String!\r\n  airlinecode: String!\r\n}\r\n\r\ninput RoleInput {\r\n  role: String!\r\n  airlinecode: String!\r\n  details: String\r\n}\r\n\r\ninput RolePermissionInput {\r\n  role: String!\r\n  permission: String!\r\n  airlinecode: String!\r\n}\r\n\r\ninput RolePermissionQueryInput {\r\n  role: String!\r\n  airlinecode: String!\r\n}\r\n\r\ntype RolePermissionResponse {\r\n  warnings: [Warnings]\r\n  response: RolePermissions\r\n}\r\n\r\ntype RolePermissions {\r\n  role: Roles\r\n  permission: Permissions\r\n}\r\n\r\ntype RolePermissionsResponse {\r\n  warnings: [Warnings]\r\n  response: [RolePermissions]\r\n}\r\n\r\ntype RoleResponse {\r\n  warnings: [Warnings]\r\n  response: Roles\r\n}\r\n\r\ntype Roles {\r\n  role: String\r\n  details: String\r\n  airline: Airline\r\n}\r\n\r\ntype RolesResponse {\r\n  warnings: [Warnings]\r\n  response: [Roles]\r\n}\r\n\r\ntype ShoppingTypes {\r\n  code: String\r\n  name: String\r\n  airline: Airline\r\n}\r\n\r\ninput ShoppingTypesInput {\r\n  code: String\r\n  name: String\r\n  airlinecode: String\r\n}\r\n\r\ntype Status {\r\n  status: String\r\n}\r\n\r\ntype TripTypes {\r\n  code: String\r\n  name: String\r\n  airline: Airline\r\n}\r\n\r\ninput TripTypesInput {\r\n  code: String\r\n  name: String\r\n  airlinecode: String\r\n}\r\n\r\ntype WaiverReasons {\r\n  code: String\r\n  reason: String\r\n  airline: Airline\r\n}\r\n\r\ninput WaiverReasonsInput {\r\n  code: String\r\n  reason: String\r\n  airlinecode: String\r\n}\r\n\r\ntype Warning {\r\n  code: String\r\n  message: String\r\n}\r\n\r\ntype Warnings {\r\n  code: String\r\n  message: String\r\n}\r\n\r\nscalar _Any\r\n\r\nscalar _FieldSet\r\n\r\ntype _Service {\r\n  sdl: String\r\n}\r\n\r\ninput fareTypeInput {\r\n  cffcode: String\r\n  airlinecode: String\r\n  countrycode: String\r\n  farename: String\r\n}\r\n\r\ninput frequentflyerprogramsInput {\r\n  companycode: String\r\n  name: String\r\n  airlinecode: String\r\n}\r\n\r\ninput passengerTypesInput {\r\n  code: String\r\n  name: String\r\n  airlinecode: String\r\n  age_lower_bound: Int\r\n  age_upper_bound: Int\r\n}\r\n"
  depends_on = [
    azurerm_api_management_api.res-4
  ]
}
resource "azurerm_api_management_api" "res-8" {
  api_management_name   = "NevioServiceCenterAPIM"
  name                  = "checkout-confirm"
  resource_group_name   = "amedeusnevio_rg"
  revision              = "1"
  subscription_required = false
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_api_policy" "res-9" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "checkout-confirm"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api.res-8
  ]
}
resource "azurerm_api_management_api_schema" "res-10" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "checkout-confirm"
  content_type        = "application/vnd.ms-azure-apim.graphql.schema"
  resource_group_name = "amedeusnevio_rg"
  schema_id           = "graphql"
  value               = "directive @extends on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\ndirective @external(reason: String) on\r\n  | OBJECT\r\n  | FIELD_DEFINITION\r\n\r\ndirective @key(fields: _FieldSet!, resolvable: Boolean = true) on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\n# Indicates exactly one field must be supplied and this field must not be `null`.\r\ndirective @oneOf on\r\n  | INPUT_OBJECT\r\n\r\ndirective @provides(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\ndirective @requires(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\n# Exposes a URL that specifies the behavior of this scalar.\r\ndirective @specifiedBy(\r\n  # The URL that specifies the behavior of this scalar.\r\n  url: String!\r\n) on\r\n  | SCALAR\r\n\r\ndirective @tag(name: String!) on\r\n  | FIELD_DEFINITION\r\n  | OBJECT\r\n  | INTERFACE\r\n  | UNION\r\n  | ARGUMENT_DEFINITION\r\n  | SCALAR\r\n  | ENUM\r\n  | ENUM_VALUE\r\n  | INPUT_OBJECT\r\n  | INPUT_FIELD_DEFINITION\r\n\r\nschema {\r\n  query: Query\r\n  mutation: Mutation\r\n}\r\n\r\ntype AircraftData {\r\n  code: String\r\n  name: String\r\n}\r\n\r\ntype AirlineData {\r\n  code: String\r\n  name: String\r\n}\r\n\r\ntype AmadeusResponse {\r\n  id: ID!\r\n  creationDateTime: String\r\n  lastModificationDateTime: String\r\n  expirationDateTime: String\r\n  paymentTimeLimit: String\r\n  issuanceTimeLimit: String\r\n  isGroupBooking: Boolean\r\n  nonAirContent: Boolean\r\n  tags: String\r\n}\r\n\r\ninput CheckoutConfirmRequest {\r\n  checkoutID: String!\r\n}\r\n\r\ntype CheckoutConfirmResponse {\r\n  id: String\r\n  creationDateTime: String\r\n  paymentTimeLimit: String\r\n  expirationDateTime: String\r\n  air: air\r\n  passengers: [passengers]\r\n  services: [services]\r\n  remarks: [remarks]\r\n  eligibilities: eligibility\r\n  paymentInfo: [paymentInfo]\r\n  dataList: dataListJson\r\n}\r\n\r\ntype CountryData {\r\n  code: String\r\n  name: String\r\n}\r\n\r\ntype Error {\r\n  code: String!\r\n  message: String!\r\n  severity: String!\r\n}\r\n\r\ntype FlightData {\r\n  marketingAirlineCode: String\r\n  operatingAirlineCode: String\r\n  marketingFlightNumber: String\r\n  departure: FlightLocation\r\n  arrival: FlightLocation\r\n  aircraftCode: String\r\n  duration: Int\r\n  isOpenSegment: Boolean\r\n  isSecureFlight: Boolean\r\n}\r\n\r\ntype FlightLocation {\r\n  locationCode: String\r\n  dateTime: String\r\n  terminal: String\r\n}\r\n\r\ntype LocationData {\r\n  type: String\r\n  airportName: String\r\n  cityName: String\r\n  cityCode: String\r\n  countryCode: String\r\n  timeZone: String\r\n}\r\n\r\ntype MealData {\r\n  code: String\r\n  name: String\r\n}\r\n\r\ntype Mutation {\r\n  ConfirmCheckout(CheckoutConfirmRequest: CheckoutConfirmRequest): CheckoutConfirmResponse\r\n}\r\n\r\ntype Query {\r\n  _empty: String\r\n  _service: _Service!\r\n}\r\n\r\ntype Response {\r\n  warnings: [Error]\r\n  response: CheckoutConfirmResponse\r\n}\r\n\r\ntype TaxData {\r\n  code: String\r\n  name: String\r\n}\r\n\r\nscalar _Any\r\n\r\nscalar _FieldSet\r\n\r\ntype _Service {\r\n  sdl: String\r\n}\r\n\r\ntype acknowledge {\r\n  airBoundId: String\r\n  disruption: eligible\r\n  waitlistConfirmation: eligible\r\n  seats: eligible\r\n}\r\n\r\ntype address {\r\n  addressName: String\r\n  lines: [String!]!\r\n  zipCode: String\r\n  countryCode: String\r\n  cityName: String\r\n  stateCode: String\r\n  postalBox: String\r\n  purpose: String\r\n}\r\n\r\ntype air {\r\n  price: price\r\n  connections: [connections]\r\n}\r\n\r\ntype base {\r\n  value: Int\r\n  currencyCode: String\r\n}\r\n\r\ntype bookingStatusData {\r\n  name: String\r\n}\r\n\r\ntype cancel {\r\n  isEligible: Boolean\r\n}\r\n\r\ntype change {\r\n  airBoundId: String\r\n  flightIds: [String]\r\n  isEligible: Boolean\r\n  nonEligibilityReasons: [nonEligibilityReasons]\r\n  nonEligibilityReason: String\r\n  isPenaltyApplied: Boolean\r\n  isRouteChangeAllowed: Boolean\r\n  waiverCodes: [String]\r\n}\r\n\r\ntype connections {\r\n  originLocationCode: String\r\n  destinationLocationCode: String\r\n  flights: [flights]\r\n  duration: Int\r\n}\r\n\r\ntype contactDetails {\r\n  travelerIds: String\r\n  mobile: [mobile]\r\n  landline: [landline]\r\n  email: [email]\r\n  address: [address]\r\n}\r\n\r\ntype currencydata {\r\n  name: String\r\n  decimalPlaces: Int\r\n}\r\n\r\ntype dataList {\r\n  location: LocationData\r\n  flights: FlightData\r\n  currency: currencydata\r\n  bookingStatus: bookingStatusData\r\n  airline: AirlineData\r\n  country: CountryData\r\n  aircraft: AircraftData\r\n  tax: TaxData\r\n  meal: MealData\r\n}\r\n\r\nscalar dataListJson\r\n\r\ntype eligibility {\r\n  acknowledge: [acknowledge]\r\n  cancel: cancel\r\n  cancelAndRefund: eligible\r\n  change: [change]\r\n}\r\n\r\ntype eligible {\r\n  isEligible: Boolean\r\n  nonEligibilityReasons: [nonEligibilityReasons]\r\n}\r\n\r\ntype email {\r\n  emailAddress: String!\r\n  purpose: String!\r\n}\r\n\r\ntype emergencyContactDetails {\r\n  mobile: [mobile]\r\n  landline: [landline]\r\n}\r\n\r\ntype fees {\r\n  value: Int\r\n  currencyCode: String\r\n  nature: String\r\n}\r\n\r\ntype flights {\r\n  id: String\r\n  cabin: String\r\n  bookingClass: String\r\n  statusCode: String\r\n  connectionTime: Int\r\n  fareFamilyCode: String\r\n}\r\n\r\ntype identityDetails {\r\n  firstName: String\r\n  lastName: String\r\n  isPreferred: Boolean\r\n  title: String\r\n  dateOfBirth: String\r\n  nameType: String\r\n  accompanyingTravelerId: String\r\n}\r\n\r\ntype landline {\r\n  countryCode: String\r\n  number: String!\r\n  purpose: String!\r\n  countryPhoneExtension: String\r\n}\r\n\r\ntype mobile {\r\n  countryCode: String\r\n  number: String!\r\n  purpose: String!\r\n  countryPhoneExtension: String\r\n}\r\n\r\ntype nonEligibilityReasons {\r\n  code: String\r\n  title: String\r\n}\r\n\r\ntype parameters {\r\n  code: String\r\n  value: String\r\n}\r\n\r\ntype passengers {\r\n  id: String\r\n  passengerTypeCode: String\r\n  identityDetails: identityDetails\r\n  contactDetails: contactDetails\r\n  emergencyContactDetails: emergencyContactDetails\r\n}\r\n\r\ntype paymentInfo {\r\n  id: String\r\n  paymentType: String\r\n  cardNumber: String\r\n  holderName: String\r\n  amount: Int\r\n  currencyCode: String\r\n  status: String\r\n}\r\n\r\ntype price {\r\n  unitPrices: [unitPrices]\r\n  totalPrices: [prices]\r\n}\r\n\r\ntype prices {\r\n  base: base\r\n  total: total\r\n  taxes: [taxes]\r\n  totalTaxes: totalTaxes\r\n  totalRefundableTaxes: totalRefundableTaxes\r\n  fees: [fees]\r\n  totalFees: totalfees\r\n}\r\n\r\ntype remarks {\r\n  type: String\r\n  text: String\r\n}\r\n\r\ntype services {\r\n  name: String\r\n  code: String\r\n  quantity: Int\r\n  type: String\r\n  flightIds: [String]\r\n  statusCode: String\r\n  parameters: [parameters]\r\n  travelerId: String\r\n  isChargeable: Boolean\r\n}\r\n\r\ntype taxes {\r\n  value: Int\r\n  currencyCode: String\r\n  code: String\r\n}\r\n\r\ntype total {\r\n  value: Int\r\n  currencyCode: String\r\n}\r\n\r\ntype totalRefundableTaxes {\r\n  value: Int\r\n  currencyCode: String\r\n}\r\n\r\ntype totalTaxes {\r\n  value: Int\r\n  currencyCode: String\r\n}\r\n\r\ntype totalfees {\r\n  value: Int\r\n  currencyCode: String\r\n}\r\n\r\ntype unitPrices {\r\n  travelerIds: [String]\r\n  flightIds: [String]\r\n  prices: [prices]\r\n}\r\n"
  depends_on = [
    azurerm_api_management_api.res-8
  ]
}
resource "azurerm_api_management_api" "res-12" {
  api_management_name   = "NevioServiceCenterAPIM"
  name                  = "checkout-passengers"
  resource_group_name   = "amedeusnevio_rg"
  revision              = "1"
  subscription_required = false
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_api_policy" "res-13" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "checkout-passengers"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api.res-12
  ]
}
resource "azurerm_api_management_api_schema" "res-14" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "checkout-passengers"
  content_type        = "application/vnd.ms-azure-apim.graphql.schema"
  resource_group_name = "amedeusnevio_rg"
  schema_id           = "graphql"
  value               = "directive @extends on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\ndirective @external(reason: String) on\r\n  | OBJECT\r\n  | FIELD_DEFINITION\r\n\r\ndirective @key(fields: _FieldSet!, resolvable: Boolean = true) on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\n# Indicates exactly one field must be supplied and this field must not be `null`.\r\ndirective @oneOf on\r\n  | INPUT_OBJECT\r\n\r\ndirective @provides(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\ndirective @requires(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\n# Exposes a URL that specifies the behavior of this scalar.\r\ndirective @specifiedBy(\r\n  # The URL that specifies the behavior of this scalar.\r\n  url: String!\r\n) on\r\n  | SCALAR\r\n\r\ndirective @tag(name: String!) on\r\n  | FIELD_DEFINITION\r\n  | OBJECT\r\n  | INTERFACE\r\n  | UNION\r\n  | ARGUMENT_DEFINITION\r\n  | SCALAR\r\n  | ENUM\r\n  | ENUM_VALUE\r\n  | INPUT_OBJECT\r\n  | INPUT_FIELD_DEFINITION\r\n\r\nschema {\r\n  query: Query\r\n  mutation: Mutation\r\n}\r\n\r\ninput AddPassengerInput {\r\n  checkoutId: String!\r\n  passengers: [PassengerInput!]!\r\n}\r\n\r\ninput AddressContactInput {\r\n  isDefault: Boolean!\r\n  category: ContactCategoryInput!\r\n  addresseeName: String!\r\n  lines: [String!]!\r\n  countryCode: String!\r\n  stateCode: String!\r\n  cityName: String!\r\n  zipCode: String!\r\n  postalBox: String!\r\n  purposes: [AddressContactPurpose!]!\r\n}\r\n\r\nenum AddressContactPurpose {\r\n  billing\r\n  mailing\r\n}\r\n\r\nenum ContactCategoryInput {\r\n  personal\r\n  business\r\n  agency\r\n  other\r\n}\r\n\r\ninput ContactDetailsInput {\r\n  mobile: [PhoneContactInput!]\r\n  email: [EmailContactInput!]\r\n  landline: [PhoneContactInput!]\r\n  address: [AddressContactInput!]\r\n}\r\n\r\ninput EmailContactInput {\r\n  isDefault: Boolean!\r\n  category: ContactCategoryInput!\r\n  emailAddress: String!\r\n  purposes: [EmailContactPurpose!]!\r\n}\r\n\r\nenum EmailContactPurpose {\r\n  standard\r\n  notification\r\n  information\r\n  USCDCTracingContactEmail\r\n}\r\n\r\ninput EmergencyContactDetailsInput {\r\n  isDefault: Boolean!\r\n  category: ContactCategoryInput!\r\n  deviceType: EmergencyContactDeviceType!\r\n  number: String!\r\n  countryPhoneExtension: String!\r\n  areaCode: String!\r\n  countryCode: String!\r\n}\r\n\r\nenum EmergencyContactDeviceType {\r\n  mobile\r\n  landline\r\n}\r\n\r\nenum Gender {\r\n  male\r\n  female\r\n  unspecified\r\n  unknown\r\n}\r\n\r\ninput IdentityDetailsInput {\r\n  title: String!\r\n  firstName: String!\r\n  lastName: String!\r\n  nameType: NameType!\r\n  dateOfBirth: String!\r\n  gender: Gender!\r\n}\r\n\r\ntype Mutation {\r\n  updatePassengerInformation(passengerInput: AddPassengerInput!): SuccessResponse!\r\n}\r\n\r\nenum NameType {\r\n  universal\r\n  native\r\n  romanized\r\n}\r\n\r\ninput PassengerInput {\r\n  id: ID!\r\n  tid: ID\r\n  associatedPassengerId: String\r\n  passengerTypeCode: String!\r\n  identityDetails: IdentityDetailsInput!\r\n  contactDetails: ContactDetailsInput\r\n  emergencyContactDetails: EmergencyContactDetailsInput\r\n}\r\n\r\ninput PhoneContactInput {\r\n  isDefault: Boolean!\r\n  category: ContactCategoryInput!\r\n  number: String!\r\n  countryCode: String!\r\n  purposes: [PhoneContactPurpose!]!\r\n}\r\n\r\nenum PhoneContactPurpose {\r\n  standard\r\n  notification\r\n  information\r\n  emergency\r\n}\r\n\r\ntype Query {\r\n  _service: _Service!\r\n}\r\n\r\ntype SuccessResponse {\r\n  status: String!\r\n}\r\n\r\nscalar _Any\r\n\r\nscalar _FieldSet\r\n\r\ntype _Service {\r\n  sdl: String\r\n}\r\n"
  depends_on = [
    azurerm_api_management_api.res-12
  ]
}
resource "azurerm_api_management_api" "res-16" {
  api_management_name   = "NevioServiceCenterAPIM"
  name                  = "checkout-update"
  resource_group_name   = "amedeusnevio_rg"
  revision              = "1"
  subscription_required = false
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_api_policy" "res-17" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "checkout-update"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api.res-16
  ]
}
resource "azurerm_api_management_api_schema" "res-18" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "checkout-update"
  content_type        = "application/vnd.ms-azure-apim.graphql.schema"
  resource_group_name = "amedeusnevio_rg"
  schema_id           = "graphql"
  value               = "directive @extends on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\ndirective @external(reason: String) on\r\n  | OBJECT\r\n  | FIELD_DEFINITION\r\n\r\ndirective @key(fields: _FieldSet!, resolvable: Boolean = true) on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\n# Indicates exactly one field must be supplied and this field must not be `null`.\r\ndirective @oneOf on\r\n  | INPUT_OBJECT\r\n\r\ndirective @provides(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\ndirective @requires(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\n# Exposes a URL that specifies the behavior of this scalar.\r\ndirective @specifiedBy(\r\n  # The URL that specifies the behavior of this scalar.\r\n  url: String!\r\n) on\r\n  | SCALAR\r\n\r\ndirective @tag(name: String!) on\r\n  | FIELD_DEFINITION\r\n  | OBJECT\r\n  | INTERFACE\r\n  | UNION\r\n  | ARGUMENT_DEFINITION\r\n  | SCALAR\r\n  | ENUM\r\n  | ENUM_VALUE\r\n  | INPUT_OBJECT\r\n  | INPUT_FIELD_DEFINITION\r\n\r\nschema {\r\n  query: Query\r\n  mutation: Mutation\r\n}\r\n\r\ninput CheckoutUpdateRequest {\r\n  checkoutId: String\r\n  airboundId: [String!]!\r\n  airlineCode: String\r\n}\r\n\r\ntype CheckoutUpdateResponse {\r\n  cartId: String!\r\n  checkoutId: String!\r\n  airofferid: String!\r\n  airlinecode: String\r\n}\r\n\r\ntype Mutation {\r\n  UpdateCheckout(CheckoutUpdateRequest: CheckoutUpdateRequest): CheckoutUpdateResponse\r\n}\r\n\r\ntype Query {\r\n  _empty: String\r\n  _service: _Service!\r\n}\r\n\r\nscalar _Any\r\n\r\nscalar _FieldSet\r\n\r\ntype _Service {\r\n  sdl: String\r\n}\r\n"
  depends_on = [
    azurerm_api_management_api.res-16
  ]
}
resource "azurerm_api_management_api" "res-20" {
  api_management_name   = "NevioServiceCenterAPIM"
  name                  = "echo-api"
  resource_group_name   = "amedeusnevio_rg"
  revision              = "1"
  subscription_required = false
  oauth2_authorization {
    authorization_server_name = "testoauth"
  }
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_api_operation" "res-21" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "echo-api"
  description         = "A demonstration of a POST call based on the echo backend above. The request body is expected to contain JSON-formatted data (see example below). A policy is used to automatically transform any request sent in JSON directly to XML. In a real-world scenario this could be used to enable modern clients to speak to a legacy backend."
  display_name        = "Create resource"
  method              = "POST"
  operation_id        = "create-resource"
  resource_group_name = "amedeusnevio_rg"
  url_template        = "/resource"
  response {
    status_code = 200
  }
  depends_on = [
    azurerm_api_management_api.res-20
  ]
}
resource "azurerm_api_management_api_operation_policy" "res-22" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "echo-api"
  operation_id        = "create-resource"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api_operation.res-21
  ]
}
resource "azurerm_api_management_api_operation" "res-23" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "echo-api"
  description         = "A demonstration of a PUT call handled by the same \"echo\" backend as above. You can now specify a request body in addition to headers and it will be returned as well."
  display_name        = "Modify Resource"
  method              = "PUT"
  operation_id        = "modify-resource"
  resource_group_name = "amedeusnevio_rg"
  url_template        = "/resource"
  response {
    status_code = 200
  }
  depends_on = [
    azurerm_api_management_api.res-20
  ]
}
resource "azurerm_api_management_api_operation" "res-24" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "echo-api"
  description         = "A demonstration of a DELETE call which traditionally deletes the resource. It is based on the same \"echo\" backend as in all other operations so nothing is actually deleted."
  display_name        = "Remove resource"
  method              = "DELETE"
  operation_id        = "remove-resource"
  resource_group_name = "amedeusnevio_rg"
  url_template        = "/resource"
  response {
    status_code = 200
  }
  depends_on = [
    azurerm_api_management_api.res-20
  ]
}
resource "azurerm_api_management_api_operation" "res-25" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "echo-api"
  description         = "The HEAD operation returns only headers. In this demonstration a policy is used to set additional headers when the response is returned and to enable JSONP."
  display_name        = "Retrieve header only"
  method              = "HEAD"
  operation_id        = "retrieve-header-only"
  resource_group_name = "amedeusnevio_rg"
  url_template        = "/resource"
  response {
    status_code = 200
  }
  depends_on = [
    azurerm_api_management_api.res-20
  ]
}
resource "azurerm_api_management_api_operation_policy" "res-26" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "echo-api"
  operation_id        = "retrieve-header-only"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api_operation.res-25
  ]
}
resource "azurerm_api_management_api_operation" "res-27" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "echo-api"
  description         = "A demonstration of a GET call on a sample resource. It is handled by an \"echo\" backend which returns a response equal to the request (the supplied headers and body are being returned as received)."
  display_name        = "Retrieve resource"
  method              = "GET"
  operation_id        = "retrieve-resource"
  resource_group_name = "amedeusnevio_rg"
  url_template        = "/resource"
  response {
    description = "Returned in all cases."
    status_code = 200
  }
  depends_on = [
    azurerm_api_management_api.res-20
  ]
}
resource "azurerm_api_management_api_operation" "res-28" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "echo-api"
  description         = "A demonstration of a GET call with caching enabled on the same \"echo\" backend as above. Cache TTL is set to 1 hour. When you make the first request the headers you supplied will be cached. Subsequent calls will return the same headers as the first time even if you change them in your request."
  display_name        = "Retrieve resource (cached)"
  method              = "GET"
  operation_id        = "retrieve-resource-cached"
  resource_group_name = "amedeusnevio_rg"
  url_template        = "/resource-cached"
  response {
    status_code = 200
  }
  depends_on = [
    azurerm_api_management_api.res-20
  ]
}
resource "azurerm_api_management_api_operation_policy" "res-29" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "echo-api"
  operation_id        = "retrieve-resource-cached"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api_operation.res-28
  ]
}
resource "azurerm_api_management_api_policy" "res-30" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "echo-api"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api.res-20
  ]
}
resource "azurerm_api_management_api" "res-32" {
  api_management_name   = "NevioServiceCenterAPIM"
  name                  = "fare-conditions"
  resource_group_name   = "amedeusnevio_rg"
  revision              = "1"
  subscription_required = false
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_api_policy" "res-33" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "fare-conditions"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api.res-32
  ]
}
resource "azurerm_api_management_api_schema" "res-34" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "fare-conditions"
  content_type        = "application/vnd.ms-azure-apim.graphql.schema"
  resource_group_name = "amedeusnevio_rg"
  schema_id           = "graphql"
  value               = "directive @extends on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\ndirective @external(reason: String) on\r\n  | OBJECT\r\n  | FIELD_DEFINITION\r\n\r\ndirective @key(fields: _FieldSet!, resolvable: Boolean = true) on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\n# Indicates exactly one field must be supplied and this field must not be `null`.\r\ndirective @oneOf on\r\n  | INPUT_OBJECT\r\n\r\ndirective @provides(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\ndirective @requires(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\n# Exposes a URL that specifies the behavior of this scalar.\r\ndirective @specifiedBy(\r\n  # The URL that specifies the behavior of this scalar.\r\n  url: String!\r\n) on\r\n  | SCALAR\r\n\r\ndirective @tag(name: String!) on\r\n  | FIELD_DEFINITION\r\n  | OBJECT\r\n  | INTERFACE\r\n  | UNION\r\n  | ARGUMENT_DEFINITION\r\n  | SCALAR\r\n  | ENUM\r\n  | ENUM_VALUE\r\n  | INPUT_OBJECT\r\n  | INPUT_FIELD_DEFINITION\r\n\r\nschema {\r\n  query: Query\r\n}\r\n\r\ntype ChangeRefundItem {\r\n  situation: String\r\n  value: String\r\n  currencyCode: String\r\n  descriptionCode: String!\r\n}\r\n\r\ntype Error {\r\n  code: String\r\n  message: String\r\n}\r\n\r\ntype FareCondition {\r\n  flightbounds: [String!]!\r\n  passangerIds: [String!]!\r\n  advancePurchase: [SimpleItem!]!\r\n  minimumStay: [SimpleItem!]!\r\n  maximumStay: [SimpleItem!]!\r\n  change: [ChangeRefundItem!]!\r\n  refund: [ChangeRefundItem!]!\r\n}\r\n\r\ninput FareConditionRequest {\r\n  orderId: String\r\n  cartId: String\r\n  airOfferId: String\r\n  orderChangeId: String\r\n  travelDocumentId: String\r\n}\r\n\r\ntype FareConditionResponse {\r\n  error: [Error!]\r\n  warning: [Warning!]\r\n  response: FareConditionsResponse\r\n}\r\n\r\ntype FareConditionsResponse {\r\n  fareConditions: [FareCondition!]!\r\n}\r\n\r\ntype Query {\r\n  getFareConditions(request: FareConditionRequest!): FareConditionResponse!\r\n  _service: _Service!\r\n}\r\n\r\ntype SimpleItem {\r\n  descriptionCode: String!\r\n}\r\n\r\ntype Warning {\r\n  code: String\r\n  message: String\r\n}\r\n\r\nscalar _Any\r\n\r\nscalar _FieldSet\r\n\r\ntype _Service {\r\n  sdl: String\r\n}\r\n"
  depends_on = [
    azurerm_api_management_api.res-32
  ]
}
resource "azurerm_api_management_api" "res-36" {
  api_management_name   = "NevioServiceCenterAPIM"
  name                  = "fsa"
  resource_group_name   = "amedeusnevio_rg"
  revision              = "1"
  subscription_required = false
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_api_policy" "res-37" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "fsa"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api.res-36
  ]
}
resource "azurerm_api_management_api_schema" "res-38" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "fsa"
  content_type        = "application/vnd.ms-azure-apim.graphql.schema"
  resource_group_name = "amedeusnevio_rg"
  schema_id           = "graphql"
  value               = "directive @extends on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\ndirective @external on\r\n  | FIELD_DEFINITION\r\n\r\ndirective @key(fields: _FieldSet!) on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\n# Indicates exactly one field must be supplied and this field must not be `null`.\r\ndirective @oneOf on\r\n  | INPUT_OBJECT\r\n\r\ndirective @provides(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\ndirective @requires(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\n# Exposes a URL that specifies the behavior of this scalar.\r\ndirective @specifiedBy(\r\n  # The URL that specifies the behavior of this scalar.\r\n  url: String!\r\n) on\r\n  | SCALAR\r\n\r\nschema {\r\n  query: Query\r\n}\r\n\r\nenum BookingType {\r\n  REV\r\n  AWD\r\n}\r\n\r\nenum BoundType {\r\n  Outbound\r\n  InBound\r\n}\r\n\r\n# The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf).\r\nscalar CabinJSON\r\n\r\ntype CabinProductDefinition {\r\n  cabinClass: String!\r\n  productCode: String!\r\n  cabinBaggage: String\r\n  seatSelection: Boolean\r\n  mealSelection: Boolean\r\n  loungeAccess: Boolean\r\n}\r\n\r\ntype Connection {\r\n  origin: String!\r\n  destination: String!\r\n  departureDate: String!\r\n  flightProducts: [FlightProduct!]!\r\n  flights: FlightJSON\r\n}\r\n\r\ntype FarePerPassenger {\r\n  passengerType: PassengerType!\r\n  totalPrice: Float!\r\n  baseFare: Float!\r\n  totalTax: Float!\r\n  taxes: [Tax!]!\r\n}\r\n\r\ntype Flight {\r\n  flightId: ID!\r\n  departureTime: String!\r\n  departureAirportCode: String!\r\n  arrivalTime: String!\r\n  arrivalAirportCode: String!\r\n}\r\n\r\n# The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf).\r\nscalar FlightJSON\r\n\r\ntype FlightProduct {\r\n  duration: String!\r\n  segments: [Segment!]!\r\n  products: [Products!]!\r\n}\r\n\r\ninput OfferRequest {\r\n  bookingType: BookingType!\r\n  tripType: TripType!\r\n  isOutBound: Boolean\r\n  trips: [Trip!]!\r\n  paxDetails: [PassengerDetail!]!\r\n  promoCode: String\r\n  selectedFlightProductId: String\r\n}\r\n\r\ntype Offers {\r\n  connections: [Connection!]!\r\n  productDefinitions: CabinJSON\r\n}\r\n\r\ninput PassengerDetail {\r\n  paxType: PassengerType!\r\n  FFP: String\r\n  count: Int!\r\n}\r\n\r\nenum PassengerType {\r\n  ADT\r\n  CHD\r\n  INF\r\n}\r\n\r\ntype ProductDetails {\r\n  productId: ID!\r\n  isCorporateFare: Boolean!\r\n  isPromoFare: Boolean!\r\n  totalPrice: Float!\r\n  totalTaxes: Float!\r\n  taxes: [Tax!]!\r\n  farePerPax: [FarePerPassenger!]!\r\n}\r\n\r\ntype Products {\r\n  cabinClass: String!\r\n  productCode: String!\r\n  productName: String!\r\n  isLowestFare: Boolean!\r\n  productDetails: ProductDetails!\r\n}\r\n\r\ntype Query {\r\n  getOffers(OfferRequest: OfferRequest!): Offers!\r\n  _service: _Service!\r\n}\r\n\r\ntype Segment {\r\n  flightId: ID!\r\n}\r\n\r\ntype Tax {\r\n  taxCode: String!\r\n  value: Float!\r\n  isRefundable: Boolean!\r\n}\r\n\r\ninput Trip {\r\n  origin: String!\r\n  destination: String!\r\n  date: String!\r\n  boundType: BoundType\r\n}\r\n\r\nenum TripType {\r\n  OW\r\n  RT\r\n  OJ\r\n}\r\n\r\nscalar _Any\r\n\r\nscalar _FieldSet\r\n\r\ntype _Service {\r\n  sdl: String\r\n}\r\n"
  depends_on = [
    azurerm_api_management_api.res-36
  ]
}
resource "azurerm_api_management_api" "res-40" {
  api_management_name   = "NevioServiceCenterAPIM"
  name                  = "func-checkout-initiate"
  resource_group_name   = "amedeusnevio_rg"
  revision              = "1"
  subscription_required = false
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_api_policy" "res-41" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "func-checkout-initiate"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api.res-40
  ]
}
resource "azurerm_api_management_api_schema" "res-42" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "func-checkout-initiate"
  content_type        = "application/vnd.ms-azure-apim.graphql.schema"
  resource_group_name = "amedeusnevio_rg"
  schema_id           = "graphql"
  value               = "directive @extends on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\ndirective @external(reason: String) on\r\n  | OBJECT\r\n  | FIELD_DEFINITION\r\n\r\ndirective @key(fields: _FieldSet!, resolvable: Boolean = true) on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\n# Indicates exactly one field must be supplied and this field must not be `null`.\r\ndirective @oneOf on\r\n  | INPUT_OBJECT\r\n\r\ndirective @provides(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\ndirective @requires(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\n# Exposes a URL that specifies the behavior of this scalar.\r\ndirective @specifiedBy(\r\n  # The URL that specifies the behavior of this scalar.\r\n  url: String!\r\n) on\r\n  | SCALAR\r\n\r\ndirective @tag(name: String!) on\r\n  | FIELD_DEFINITION\r\n  | OBJECT\r\n  | INTERFACE\r\n  | UNION\r\n  | ARGUMENT_DEFINITION\r\n  | SCALAR\r\n  | ENUM\r\n  | ENUM_VALUE\r\n  | INPUT_OBJECT\r\n  | INPUT_FIELD_DEFINITION\r\n\r\nschema {\r\n  query: Query\r\n  mutation: Mutation\r\n}\r\n\r\ninput CheckoutRequest {\r\n  skuIds: [String!]!\r\n  agentId: String!\r\n  airlineId: String!\r\n}\r\n\r\ntype CheckoutResponse {\r\n  cartId: String!\r\n  checkoutId: String!\r\n  airofferid: String!\r\n  passengers: [Passengers]\r\n  airlinecode: String\r\n}\r\n\r\ntype Mutation {\r\n  InitateCheckout(CheckoutRequest: CheckoutRequest): CheckoutResponse\r\n}\r\n\r\ntype Passengers {\r\n  passengerTypeCode: String!\r\n  passengerId: String!\r\n}\r\n\r\ntype Query {\r\n  _empty: String\r\n  _service: _Service!\r\n}\r\n\r\nscalar _Any\r\n\r\nscalar _FieldSet\r\n\r\ntype _Service {\r\n  sdl: String\r\n}\r\n"
  depends_on = [
    azurerm_api_management_api.res-40
  ]
}
resource "azurerm_api_management_api" "res-44" {
  api_management_name   = "NevioServiceCenterAPIM"
  description           = "Import from \"func-token-dev-eus\" Function App"
  name                  = "func-token-dev-eus"
  resource_group_name   = "amedeusnevio_rg"
  revision              = "1"
  subscription_required = false
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_api_operation" "res-45" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "func-token-dev-eus"
  display_name        = "amadeusTokenHandler"
  method              = "POST"
  operation_id        = "post-amadeustokenhandler"
  resource_group_name = "amedeusnevio_rg"
  url_template        = "/token/amadeus"
  depends_on = [
    azurerm_api_management_api.res-44
  ]
}
resource "azurerm_api_management_api_operation_policy" "res-46" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "func-token-dev-eus"
  operation_id        = "post-amadeustokenhandler"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api_operation.res-45
  ]
}
resource "azurerm_api_management_api_operation" "res-47" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "func-token-dev-eus"
  display_name        = "tokenHandler"
  method              = "POST"
  operation_id        = "post-tokenhandler"
  resource_group_name = "amedeusnevio_rg"
  url_template        = "/token"
  depends_on = [
    azurerm_api_management_api.res-44
  ]
}
resource "azurerm_api_management_api_operation_policy" "res-48" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "func-token-dev-eus"
  operation_id        = "post-tokenhandler"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api_operation.res-47
  ]
}
resource "azurerm_api_management_api" "res-50" {
  api_management_name   = "NevioServiceCenterAPIM"
  name                  = "order-retrieve"
  resource_group_name   = "amedeusnevio_rg"
  revision              = "1"
  subscription_required = false
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_api_policy" "res-51" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "order-retrieve"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api.res-50
  ]
}
resource "azurerm_api_management_api_schema" "res-52" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "order-retrieve"
  content_type        = "application/vnd.ms-azure-apim.graphql.schema"
  resource_group_name = "amedeusnevio_rg"
  schema_id           = "graphql"
  value               = "directive @extends on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\ndirective @external(reason: String) on\r\n  | OBJECT\r\n  | FIELD_DEFINITION\r\n\r\ndirective @key(fields: _FieldSet!, resolvable: Boolean = true) on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\n# Indicates exactly one field must be supplied and this field must not be `null`.\r\ndirective @oneOf on\r\n  | INPUT_OBJECT\r\n\r\ndirective @provides(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\ndirective @requires(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\n# Exposes a URL that specifies the behavior of this scalar.\r\ndirective @specifiedBy(\r\n  # The URL that specifies the behavior of this scalar.\r\n  url: String!\r\n) on\r\n  | SCALAR\r\n\r\ndirective @tag(name: String!) on\r\n  | FIELD_DEFINITION\r\n  | OBJECT\r\n  | INTERFACE\r\n  | UNION\r\n  | ARGUMENT_DEFINITION\r\n  | SCALAR\r\n  | ENUM\r\n  | ENUM_VALUE\r\n  | INPUT_OBJECT\r\n  | INPUT_FIELD_DEFINITION\r\n\r\nschema {\r\n  query: Query\r\n}\r\n\r\ntype AircraftData {\r\n  code: String\r\n  name: String\r\n}\r\n\r\n# The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf).\r\nscalar AircraftJson\r\n\r\ntype AirlineData {\r\n  code: String\r\n  name: String\r\n}\r\n\r\n# The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf).\r\nscalar AirlineJson\r\n\r\n# The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf).\r\nscalar BookingStatusJson\r\n\r\ntype CardPayment implements Payment {\r\n  id: String!\r\n  paymentType: String!\r\n  amount: Int!\r\n  currencyCode: String\r\n  authorization: String\r\n  cardNumber: String\r\n  holderName: String\r\n}\r\n\r\ntype CashPayment implements Payment {\r\n  id: String!\r\n  paymentType: String!\r\n  amount: Int!\r\n  currencyCode: String\r\n}\r\n\r\ntype CountryData {\r\n  code: String\r\n  name: String\r\n}\r\n\r\n# The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf).\r\nscalar CountryJson\r\n\r\n# The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf).\r\nscalar CurrencyJson\r\n\r\ntype Error {\r\n  code: String!\r\n  message: String!\r\n  severity: String!\r\n}\r\n\r\ntype FlightData {\r\n  marketingAirlineCode: String\r\n  operatingAirlineCode: String\r\n  marketingFlightNumber: String\r\n  departure: FlightLocation\r\n  arrival: FlightLocation\r\n  aircraftCode: String\r\n  duration: Int\r\n  isOpenSegment: Boolean\r\n  isSecureFlight: Boolean\r\n}\r\n\r\n# The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf).\r\nscalar FlightJSON\r\n\r\ntype FlightLocation {\r\n  locationCode: String\r\n  dateTime: String\r\n  terminal: String\r\n}\r\n\r\nscalar JSON\r\n\r\ntype LocationData {\r\n  type: String\r\n  airportName: String\r\n  cityName: String\r\n  cityCode: String\r\n  CountryCode: String\r\n  timeZone: String\r\n}\r\n\r\n# The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf).\r\nscalar LocationJson\r\n\r\ntype MealData {\r\n  code: String\r\n  name: String\r\n}\r\n\r\n# The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf).\r\nscalar MealJson\r\n\r\ninterface Payment {\r\n  id: String!\r\n  paymentType: String!\r\n  amount: Int!\r\n  currencyCode: String\r\n}\r\n\r\ntype Query {\r\n  retrieveOrder(orderID: String): Response!\r\n  _service: _Service!\r\n}\r\n\r\ntype Response {\r\n  warnings: [Error]\r\n  response: RetrieveOrderResponse\r\n}\r\n\r\ntype RetrieveOrderResponse {\r\n  id: String!\r\n  creationDateTime: String!\r\n  paymentTimeLimit: String\r\n  expirationDateTime: String\r\n  air: air!\r\n  passengers: [passengers!]!\r\n  services: [services]\r\n  remarks: [remarks]\r\n  eligibilities: eligibility\r\n  paymentInfo: [Payment]\r\n  dataList: dataList!\r\n}\r\n\r\ntype TaxData {\r\n  code: String\r\n  name: String\r\n}\r\n\r\n# The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf).\r\nscalar TaxJson\r\n\r\nscalar _Any\r\n\r\nscalar _FieldSet\r\n\r\ntype _Service {\r\n  sdl: String\r\n}\r\n\r\ntype acknowledge {\r\n  airBoundId: String!\r\n  disruption: eligible!\r\n  waitlistConfirmation: eligible!\r\n  seats: eligible!\r\n}\r\n\r\ntype address {\r\n  addresseeName: String\r\n  lines: [String!]!\r\n  zipCode: String\r\n  countryCode: String\r\n  cityName: String\r\n  stateCode: String\r\n  postalBox: String\r\n  purpose: String\r\n}\r\n\r\ntype air {\r\n  price: price!\r\n  connections: [connections!]!\r\n}\r\n\r\ntype base {\r\n  value: Int!\r\n  currencyCode: String!\r\n}\r\n\r\ntype bookingStatusData {\r\n  name: String\r\n}\r\n\r\ntype cancel {\r\n  isEligible: Boolean!\r\n}\r\n\r\ntype change {\r\n  airBoundId: String!\r\n  flightIds: [String!]!\r\n  isEligible: Boolean!\r\n  nonEligibilityReasons: [nonEligibilityReasons]\r\n  nonEligibilityReason: String\r\n  isPenaltyApplied: Boolean\r\n  isRouteChangeAllowed: Boolean\r\n  waiverCodes: [String]\r\n}\r\n\r\ntype connections {\r\n  originLocationCode: String!\r\n  destinationLocationCode: String!\r\n  flights: [flights!]!\r\n  duration: Int!\r\n}\r\n\r\ntype contactDetails {\r\n  travelerIds: String\r\n  mobile: [mobile]\r\n  landline: [landline]\r\n  email: [email]\r\n  address: [address]\r\n}\r\n\r\ntype country {\r\n  name: String\r\n}\r\n\r\ntype currencydata {\r\n  name: String\r\n  decimalPlaces: Int\r\n}\r\n\r\ntype dataList {\r\n  location: LocationJson\r\n  flights: FlightJSON\r\n  currency: CurrencyJson\r\n  bookingStatus: BookingStatusJson\r\n  airline: AirlineJson\r\n  country: CountryJson\r\n  aircraft: AircraftJson\r\n  tax: TaxJson\r\n  meal: MealJson\r\n}\r\n\r\ntype eligibility {\r\n  acknowledge: [acknowledge!]!\r\n  cancel: cancel!\r\n  cancelAndRefund: eligible!\r\n  change: [change!]!\r\n}\r\n\r\ntype eligible {\r\n  isEligible: Boolean\r\n  nonEligibilityReasons: [nonEligibilityReasons]\r\n}\r\n\r\ntype email {\r\n  emailAddress: String!\r\n  purpose: String!\r\n}\r\n\r\ntype emergencyContactDetails {\r\n  mobile: [mobile]\r\n  landline: [landline]\r\n}\r\n\r\ntype fees {\r\n  value: Int!\r\n  currencyCode: String!\r\n  nature: String!\r\n}\r\n\r\ntype flights {\r\n  id: String!\r\n  cabin: String\r\n  bookingClass: String!\r\n  statusCode: String!\r\n  connectionTime: Int\r\n  fareFamilyCode: String!\r\n}\r\n\r\ntype identityDetails {\r\n  firstName: String!\r\n  lastName: String!\r\n  isPreferred: Boolean!\r\n  title: String!\r\n  dateOfBirth: String!\r\n  nameType: String!\r\n  accompanyingTravelerId: String\r\n}\r\n\r\ntype landline {\r\n  countryCode: String\r\n  number: String!\r\n  purpose: String!\r\n}\r\n\r\ntype location {\r\n  locationDetail: locationDetail\r\n}\r\n\r\ntype locationDetail {\r\n  locationCode: String\r\n}\r\n\r\ntype mobile {\r\n  countryCode: String\r\n  number: String!\r\n  purpose: String!\r\n}\r\n\r\ntype nonEligibilityReasons {\r\n  code: String\r\n  title: String\r\n}\r\n\r\ntype parameters {\r\n  code: String!\r\n  value: String!\r\n}\r\n\r\ntype passengers {\r\n  id: String!\r\n  passengerTypeCode: String!\r\n  identityDetails: identityDetails!\r\n  contactDetails: contactDetails\r\n  emergencyContactDetails: emergencyContactDetails\r\n}\r\n\r\ntype price {\r\n  unitPrices: [unitPrices]\r\n  totalPrices: [prices]\r\n}\r\n\r\ntype prices {\r\n  base: base!\r\n  total: total!\r\n  taxes: [taxes!]!\r\n  totalTaxes: totalTaxes!\r\n  totalRefundableTaxes: totalRefundableTaxes\r\n  fees: [fees!]!\r\n  totalFees: totalfees!\r\n}\r\n\r\ntype remarks {\r\n  type: String!\r\n  text: String!\r\n}\r\n\r\ntype services {\r\n  name: String!\r\n  code: String!\r\n  quantity: Int!\r\n  type: String\r\n  flightIds: [String!]!\r\n  statusCode: String!\r\n  parameters: [parameters!]!\r\n  travelerId: String!\r\n  isChargeable: Boolean!\r\n}\r\n\r\ntype taxes {\r\n  value: Int!\r\n  currencyCode: String!\r\n  code: String!\r\n}\r\n\r\ntype total {\r\n  value: Int!\r\n  currencyCode: String!\r\n}\r\n\r\ntype totalRefundableTaxes {\r\n  value: Int!\r\n  currencyCode: String!\r\n}\r\n\r\ntype totalTaxes {\r\n  value: Int!\r\n  currencyCode: String!\r\n}\r\n\r\ntype totalfees {\r\n  value: Int!\r\n  currencyCode: String!\r\n}\r\n\r\ntype unitPrices {\r\n  travelerIds: [String!]!\r\n  flightIds: [String!]!\r\n  prices: [prices!]!\r\n}\r\n"
  depends_on = [
    azurerm_api_management_api.res-50
  ]
}
resource "azurerm_api_management_api" "res-54" {
  api_management_name   = "NevioServiceCenterAPIM"
  name                  = "payment"
  resource_group_name   = "amedeusnevio_rg"
  revision              = "1"
  subscription_required = false
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_api_policy" "res-55" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "payment"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api.res-54
  ]
}
resource "azurerm_api_management_api_schema" "res-56" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "payment"
  content_type        = "application/vnd.ms-azure-apim.graphql.schema"
  resource_group_name = "amedeusnevio_rg"
  schema_id           = "graphql"
  value               = "directive @extends on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\ndirective @external(reason: String) on\r\n  | OBJECT\r\n  | FIELD_DEFINITION\r\n\r\ndirective @key(fields: _FieldSet!, resolvable: Boolean = true) on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\n# Indicates exactly one field must be supplied and this field must not be `null`.\r\ndirective @oneOf on\r\n  | INPUT_OBJECT\r\n\r\ndirective @provides(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\ndirective @requires(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\n# Exposes a URL that specifies the behavior of this scalar.\r\ndirective @specifiedBy(\r\n  # The URL that specifies the behavior of this scalar.\r\n  url: String!\r\n) on\r\n  | SCALAR\r\n\r\ndirective @tag(name: String!) on\r\n  | FIELD_DEFINITION\r\n  | OBJECT\r\n  | INTERFACE\r\n  | UNION\r\n  | ARGUMENT_DEFINITION\r\n  | SCALAR\r\n  | ENUM\r\n  | ENUM_VALUE\r\n  | INPUT_OBJECT\r\n  | INPUT_FIELD_DEFINITION\r\n\r\nschema {\r\n  query: Query\r\n  mutation: Mutation\r\n}\r\n\r\ninput Contact {\r\n  phonenumber: String!\r\n  email: String!\r\n}\r\n\r\ntype Error {\r\n  code: String\r\n  message: String\r\n}\r\n\r\ntype Mutation {\r\n  processPayment(input: PaymentRequest!): PaymentResponse!\r\n}\r\n\r\ninput Passenger {\r\n  country: String!\r\n  language: String!\r\n  Contact: Contact!\r\n}\r\n\r\ninput PaymentRequest {\r\n  orderid: String!\r\n  passenger: Passenger!\r\n  remark: String\r\n}\r\n\r\ntype PaymentResponse {\r\n  error: [Error!]\r\n  warning: [Warning!]\r\n  response: PaymentResponseData\r\n}\r\n\r\ntype PaymentResponseData {\r\n  message: String!\r\n}\r\n\r\ntype Query {\r\n  initiatePayment(input: PaymentRequest!): PaymentResponse!\r\n  _service: _Service!\r\n}\r\n\r\ntype Warning {\r\n  code: String\r\n  message: String\r\n}\r\n\r\nscalar _Any\r\n\r\nscalar _FieldSet\r\n\r\ntype _Service {\r\n  sdl: String\r\n}\r\n"
  depends_on = [
    azurerm_api_management_api.res-54
  ]
}
resource "azurerm_api_management_api" "res-58" {
  api_management_name   = "NevioServiceCenterAPIM"
  name                  = "role-permission"
  resource_group_name   = "amedeusnevio_rg"
  revision              = "1"
  subscription_required = false
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_api_policy" "res-59" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "role-permission"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api.res-58
  ]
}
resource "azurerm_api_management_api_schema" "res-60" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "role-permission"
  content_type        = "application/vnd.ms-azure-apim.graphql.schema"
  resource_group_name = "amedeusnevio_rg"
  schema_id           = "graphql"
  value               = "directive @extends on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\ndirective @external(reason: String) on\r\n  | OBJECT\r\n  | FIELD_DEFINITION\r\n\r\ndirective @key(fields: _FieldSet!, resolvable: Boolean = true) on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\n# Indicates exactly one field must be supplied and this field must not be `null`.\r\ndirective @oneOf on\r\n  | INPUT_OBJECT\r\n\r\ndirective @provides(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\ndirective @requires(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\n# Exposes a URL that specifies the behavior of this scalar.\r\ndirective @specifiedBy(\r\n  # The URL that specifies the behavior of this scalar.\r\n  url: String!\r\n) on\r\n  | SCALAR\r\n\r\ndirective @tag(name: String!) on\r\n  | FIELD_DEFINITION\r\n  | OBJECT\r\n  | INTERFACE\r\n  | UNION\r\n  | ARGUMENT_DEFINITION\r\n  | SCALAR\r\n  | ENUM\r\n  | ENUM_VALUE\r\n  | INPUT_OBJECT\r\n  | INPUT_FIELD_DEFINITION\r\n\r\nschema {\r\n  query: Query\r\n}\r\n\r\ntype Airline {\r\n  airlinecode: String\r\n}\r\n\r\ntype Error {\r\n  code: String\r\n  message: String\r\n  severity: Int\r\n}\r\n\r\ntype Permissions {\r\n  permission: String\r\n  description: String\r\n}\r\n\r\ntype Query {\r\n  getRolepermissions(input: RolePermissionQueryInput!): RolePermissionsResponse!\r\n  _service: _Service!\r\n}\r\n\r\ninput RolePermissionQueryInput {\r\n  role: String!\r\n  airlinecode: String!\r\n}\r\n\r\ntype RolePermissions {\r\n  role: Roles\r\n  permission: Permissions\r\n}\r\n\r\ntype RolePermissionsResponse {\r\n  warnings: [Warning]\r\n  response: [RolePermissions]\r\n}\r\n\r\ntype Roles {\r\n  role: String\r\n  details: String\r\n  airline: Airline\r\n}\r\n\r\ntype Warning {\r\n  message: String\r\n  code: String\r\n}\r\n\r\nscalar _Any\r\n\r\nscalar _FieldSet\r\n\r\ntype _Service {\r\n  sdl: String\r\n}\r\n"
  depends_on = [
    azurerm_api_management_api.res-58
  ]
}
resource "azurerm_api_management_api" "res-62" {
  api_management_name   = "NevioServiceCenterAPIM"
  name                  = "search-panel"
  resource_group_name   = "amedeusnevio_rg"
  revision              = "1"
  subscription_required = false
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_api_policy" "res-63" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "search-panel"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api.res-62
  ]
}
resource "azurerm_api_management_api_schema" "res-64" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "search-panel"
  content_type        = "application/vnd.ms-azure-apim.graphql.schema"
  resource_group_name = "amedeusnevio_rg"
  schema_id           = "graphql"
  value               = "directive @extends on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\ndirective @external(reason: String) on\r\n  | OBJECT\r\n  | FIELD_DEFINITION\r\n\r\ndirective @key(fields: _FieldSet!, resolvable: Boolean = true) on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\n# Indicates exactly one field must be supplied and this field must not be `null`.\r\ndirective @oneOf on\r\n  | INPUT_OBJECT\r\n\r\ndirective @provides(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\ndirective @requires(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\n# Exposes a URL that specifies the behavior of this scalar.\r\ndirective @specifiedBy(\r\n  # The URL that specifies the behavior of this scalar.\r\n  url: String!\r\n) on\r\n  | SCALAR\r\n\r\ndirective @tag(name: String!) on\r\n  | FIELD_DEFINITION\r\n  | OBJECT\r\n  | INTERFACE\r\n  | UNION\r\n  | ARGUMENT_DEFINITION\r\n  | SCALAR\r\n  | ENUM\r\n  | ENUM_VALUE\r\n  | INPUT_OBJECT\r\n  | INPUT_FIELD_DEFINITION\r\n\r\nschema {\r\n  query: Query\r\n}\r\n\r\ntype Airline {\r\n  name: String\r\n  airlinecode: String\r\n  id: Int\r\n}\r\n\r\ntype Airport {\r\n  id: Int\r\n  airportcode: String\r\n  airportname: String\r\n  cityid: Int\r\n  airlineid: Int\r\n}\r\n\r\ntype City {\r\n  citycode: String\r\n  cityname: String\r\n  id: Int\r\n  countryid: Int\r\n  airports: [Airport]\r\n}\r\n\r\ntype Country {\r\n  id: Int\r\n  countrycode: String\r\n  countryname: String\r\n  airlineid: Int\r\n  cities: [City]\r\n}\r\n\r\ntype Error {\r\n  code: String\r\n  severity: String\r\n  message: String\r\n}\r\n\r\ntype FareType {\r\n  id: Int\r\n  cffcode: String\r\n  farename: String\r\n  airlineid: Int\r\n  countryid: Int\r\n}\r\n\r\ntype FrequentFlyerPrograms {\r\n  id: Int\r\n  companycode: String\r\n  name: String\r\n  airlineid: Int\r\n}\r\n\r\ntype PassengerTypes {\r\n  id: Int\r\n  code: String\r\n  name: String\r\n  airlineid: Int\r\n  age: Int\r\n}\r\n\r\ntype PtcDiscountCodes {\r\n  id: Int\r\n  discountcode: String\r\n  name: String\r\n  airlineid: Int\r\n  passengertype: Int\r\n}\r\n\r\ntype Query {\r\n  getSearchPanelData(airlineid: Int): Response\r\n  _service: _Service!\r\n}\r\n\r\ntype Response {\r\n  errors: [Error]\r\n  data: SearchDetails\r\n}\r\n\r\ntype SearchDetails {\r\n  name: String\r\n  airlinecode: String\r\n  passengertypes: [PassengerTypes]\r\n  faretype: [FareType]\r\n  countries: [Country]\r\n  frequentflyerprograms: [FrequentFlyerPrograms]\r\n  ptcdiscountcodes: [PtcDiscountCodes]\r\n}\r\n\r\nscalar _Any\r\n\r\nscalar _FieldSet\r\n\r\ntype _Service {\r\n  sdl: String\r\n}\r\n"
  depends_on = [
    azurerm_api_management_api.res-62
  ]
}
resource "azurerm_api_management_api" "res-66" {
  api_management_name   = "NevioServiceCenterAPIM"
  name                  = "shop-offers"
  resource_group_name   = "amedeusnevio_rg"
  revision              = "1"
  subscription_required = false
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_api_policy" "res-67" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "shop-offers"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_api.res-66
  ]
}
resource "azurerm_api_management_api_schema" "res-68" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "shop-offers"
  content_type        = "application/vnd.ms-azure-apim.graphql.schema"
  resource_group_name = "amedeusnevio_rg"
  schema_id           = "graphql"
  value               = "directive @extends on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\ndirective @external(reason: String) on\r\n  | OBJECT\r\n  | FIELD_DEFINITION\r\n\r\ndirective @key(fields: _FieldSet!, resolvable: Boolean = true) on\r\n  | OBJECT\r\n  | INTERFACE\r\n\r\n# Indicates exactly one field must be supplied and this field must not be `null`.\r\ndirective @oneOf on\r\n  | INPUT_OBJECT\r\n\r\ndirective @provides(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\ndirective @requires(fields: _FieldSet!) on\r\n  | FIELD_DEFINITION\r\n\r\n# Exposes a URL that specifies the behavior of this scalar.\r\ndirective @specifiedBy(\r\n  # The URL that specifies the behavior of this scalar.\r\n  url: String!\r\n) on\r\n  | SCALAR\r\n\r\ndirective @tag(name: String!) on\r\n  | FIELD_DEFINITION\r\n  | OBJECT\r\n  | INTERFACE\r\n  | UNION\r\n  | ARGUMENT_DEFINITION\r\n  | SCALAR\r\n  | ENUM\r\n  | ENUM_VALUE\r\n  | INPUT_OBJECT\r\n  | INPUT_FIELD_DEFINITION\r\n\r\nschema {\r\n  query: Query\r\n}\r\n\r\ntype ConnectionData {\r\n  departureLocationCode: String!\r\n  arrivalLocationCode: String!\r\n  flightProducts: [FlightProductData!]!\r\n}\r\n\r\ntype DataLists {\r\n  cabins: Int!\r\n  flights: FlightJson\r\n  SKUDefinition: SKUDefinitionJson\r\n  services: [ServiceData]!\r\n  restrictions: [RestrictionData]!\r\n}\r\n\r\nscalar DataListsJson\r\n\r\ntype FlightData {\r\n  marketingAirlineCode: String!\r\n  operatingAirlineCode: String!\r\n  marketingFlightNumber: String!\r\n  departure: FlightLocation!\r\n  arrival: FlightLocation!\r\n  aircraftCode: String!\r\n  duration: Int!\r\n  isOpenSegment: Boolean!\r\n  isSecureFlight: Boolean!\r\n}\r\n\r\nscalar FlightJson\r\n\r\ntype FlightLocation {\r\n  locationCode: String!\r\n  dateTime: String!\r\n  terminal: String\r\n}\r\n\r\ntype FlightProductData {\r\n  ranking: Int!\r\n  duration: Int!\r\n  segments: [FlightSegment!]!\r\n  flightSKUs: [FlightSKU!]!\r\n}\r\n\r\ntype FlightSKU {\r\n  SKUId: String!\r\n  SKUCode: String!\r\n  SKUName: String!\r\n  cabinClass: String!\r\n  seatsLeft: Int!\r\n  prices: SKUPrices!\r\n  services: [SKUService!]!\r\n  restrictions: [String]!\r\n}\r\n\r\ntype FlightSegment {\r\n  flightId: String!\r\n  connectionTime: Int\r\n}\r\n\r\nscalar JSON\r\n\r\ninput OfferRequest {\r\n  tripType: TripType!\r\n  trips: [Trip!]!\r\n  passengers: [Passenger!]!\r\n  selectedFlightProductId: String\r\n  fareTypes: [String!]\r\n}\r\n\r\ntype Offers {\r\n  warnings: [JSON!]!\r\n  response: OffersResponse!\r\n}\r\n\r\ntype OffersResponse {\r\n  dataLists: DataListsJson!\r\n  connections: [ConnectionData!]!\r\n}\r\n\r\ninput Passenger {\r\n  passengerTypeCode: PassengerType!\r\n  frequentFlyer: String\r\n  discountCode: String\r\n}\r\n\r\nenum PassengerType {\r\n  ADT\r\n  CHD\r\n  INF\r\n  SRC\r\n}\r\n\r\ntype Query {\r\n  getOffers(OfferRequest: OfferRequest!): Offers!\r\n  _service: _Service!\r\n}\r\n\r\ntype RestrictionData {\r\n  restrictionCode: String!\r\n  restrictionDescription: String!\r\n}\r\n\r\ntype SKUDefinition {\r\n  services: [SKUServiceDefinition!]!\r\n}\r\n\r\n# The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf).\r\nscalar SKUDefinitionJson\r\n\r\ntype SKUPriceDetail {\r\n  baseAmount: Float!\r\n  totalAmount: Float!\r\n  curCode: String!\r\n  totalTaxAmount: Float!\r\n  taxSummary: [TaxSummary!]!\r\n}\r\n\r\ntype SKUPrices {\r\n  unitPrices: [SKUUnitPrice!]!\r\n  totalPrices: [SKUTotalPrice!]!\r\n}\r\n\r\ntype SKUService {\r\n  serviceCode: String!\r\n  flightIds: [String!]!\r\n}\r\n\r\ntype SKUServiceDefinition {\r\n  serviceCode: String!\r\n  applicability: String!\r\n}\r\n\r\ntype SKUTotalPrice {\r\n  baseAmount: Float!\r\n  totalAmount: Float!\r\n  curCode: String!\r\n  totalTaxAmount: Float!\r\n  taxSummary: [TaxSummary!]!\r\n}\r\n\r\ntype SKUUnitPrice {\r\n  paxID: [String]!\r\n  prices: SKUPriceDetail!\r\n}\r\n\r\ntype ServiceData {\r\n  serviceCode: String!\r\n  serviceDescription: String!\r\n}\r\n\r\ntype TaxSummary {\r\n  amount: Float!\r\n  taxCode: String!\r\n  taxName: String!\r\n}\r\n\r\ninput Trip {\r\n  departureLocationCode: String!\r\n  arrivalLocationCode: String!\r\n  departureDateTime: String!\r\n  isRequestedBound: Boolean!\r\n}\r\n\r\nenum TripType {\r\n  OW\r\n  RT\r\n  MC\r\n}\r\n\r\nscalar _Any\r\n\r\nscalar _FieldSet\r\n\r\ntype _Service {\r\n  sdl: String\r\n}\r\n"
  depends_on = [
    azurerm_api_management_api.res-66
  ]
}
resource "azurerm_api_management_authorization_server" "res-70" {
  api_management_name          = "NevioServiceCenterAPIM"
  authorization_endpoint       = "https://login.microsoftonline.com/9bea73bd-2106-45da-a98b-33352e3784a3/oauth2/v2.0/authorize"
  authorization_methods        = ["GET"]
  bearer_token_sending_methods = ["authorizationHeader"]
  client_authentication_method = ["Body"]
  client_id                    = "2942a92c-5b06-49b3-b9c5-dae77d84fac4"
  client_registration_endpoint = "http://localhost"
  display_name                 = "NevioAuth"
  grant_types                  = ["authorizationCode", "clientCredentials"]
  name                         = "nevioauth"
  resource_group_name          = "amedeusnevio_rg"
  token_endpoint               = "https://login.microsoftonline.com/9bea73bd-2106-45da-a98b-33352e3784a3/oauth2/v2.0/token"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_authorization_server" "res-71" {
  api_management_name          = "NevioServiceCenterAPIM"
  authorization_endpoint       = "https://login.microsoftonline.com/9bea73bd-2106-45da-a98b-33352e3784a3/oauth2/v2.0/authorize"
  authorization_methods        = ["GET", "POST"]
  bearer_token_sending_methods = ["authorizationHeader"]
  client_authentication_method = ["Body"]
  client_id                    = "888de15f-7092-4ea2-93cf-c53db530fedd"
  client_registration_endpoint = "http://localhost"
  default_scope                = "api://e75f929e-0297-43f1-b9b0-c246c346b442/functionapp.default"
  display_name                 = "testOAuth"
  grant_types                  = ["authorizationCode"]
  name                         = "testoauth"
  resource_group_name          = "amedeusnevio_rg"
  token_endpoint               = "https://login.microsoftonline.com/9bea73bd-2106-45da-a98b-33352e3784a3/oauth2/v2.0/token"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_backend" "res-72" {
  api_management_name = "NevioServiceCenterAPIM"
  description         = "func-shop-offer-dev-eus"
  name                = "func-shop-offer-dev-eus"
  protocol            = "http"
  resource_group_name = "amedeusnevio_rg"
  resource_id         = "https://management.azure.com/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Web/sites/func-shop-offer-dev-eus"
  url                 = "https://func-shop-offer-dev-eus-fcb0gydkbfggethp.eastus-01.azurewebsites.net"
  credentials {
    header = {
      x-functions-key = "{{func-shop-offer-dev-eus-key}}"
    }
  }
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_backend" "res-73" {
  api_management_name = "NevioServiceCenterAPIM"
  description         = "func-token-dev-eus"
  name                = "func-token-dev-eus"
  protocol            = "http"
  resource_group_name = "amedeusnevio_rg"
  resource_id         = "https://management.azure.com/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Web/sites/func-token-dev-eus"
  url                 = "https://func-token-dev-eus-a2heagh0gzhma6ct.eastus-01.azurewebsites.net"
  credentials {
    header = {
      x-functions-key = "{{func-token-dev-eus-key}}"
    }
  }
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_backend" "res-74" {
  api_management_name = "NevioServiceCenterAPIM"
  description         = "testing-function-app-mock"
  name                = "testing-function-app-mock"
  protocol            = "http"
  resource_group_name = "amedeusnevio_rg"
  resource_id         = "https://management.azure.com/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Web/sites/testing-function-app-mock"
  url                 = "https://testing-function-app-mock.azurewebsites.net"
  credentials {
    header = {
      x-functions-key = "{{testing-function-app-mock-key}}"
    }
  }
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_group" "res-75" {
  api_management_name = "NevioServiceCenterAPIM"
  description         = "Administrators is a built-in group containing the admin email account provided at the time of service creation. Its membership is managed by the system."
  display_name        = "Administrators"
  name                = "administrators"
  resource_group_name = "amedeusnevio_rg"
  type                = "system"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_group_user" "res-76" {
  api_management_name = "NevioServiceCenterAPIM"
  group_name          = "administrators"
  resource_group_name = "amedeusnevio_rg"
  user_id             = "1"
  depends_on = [
    azurerm_api_management_group.res-75
  ]
}
resource "azurerm_api_management_group" "res-77" {
  api_management_name = "NevioServiceCenterAPIM"
  description         = "Developers is a built-in group. Its membership is managed by the system. Signed-in users fall into this group."
  display_name        = "Developers"
  name                = "developers"
  resource_group_name = "amedeusnevio_rg"
  type                = "system"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_group_user" "res-78" {
  api_management_name = "NevioServiceCenterAPIM"
  group_name          = "developers"
  resource_group_name = "amedeusnevio_rg"
  user_id             = "1"
  depends_on = [
    azurerm_api_management_group.res-77
  ]
}
resource "azurerm_api_management_group" "res-79" {
  api_management_name = "NevioServiceCenterAPIM"
  description         = "Guests is a built-in group. Its membership is managed by the system. Unauthenticated users visiting the developer portal fall into this group."
  display_name        = "Guests"
  name                = "guests"
  resource_group_name = "amedeusnevio_rg"
  type                = "system"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_named_value" "res-80" {
  api_management_name = "NevioServiceCenterAPIM"
  display_name        = "func-shop-offer-dev-eus-key"
  name                = "func-shop-offer-dev-eus-key"
  resource_group_name = "amedeusnevio_rg"
  secret              = true
  tags                = ["key", "function", "auto"]
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_named_value" "res-81" {
  api_management_name = "NevioServiceCenterAPIM"
  display_name        = "func-token-dev-eus-key"
  name                = "func-token-dev-eus-key"
  resource_group_name = "amedeusnevio_rg"
  secret              = true
  tags                = ["key", "function", "auto"]
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_named_value" "res-82" {
  api_management_name = "NevioServiceCenterAPIM"
  display_name        = "testing-function-app-mock-key"
  name                = "testing-function-app-mock-key"
  resource_group_name = "amedeusnevio_rg"
  secret              = true
  tags                = ["key", "function", "auto"]
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_policy" "res-90" {
  api_management_id = azurerm_api_management.res-1.id
  xml_content       = "<!--\r\n    IMPORTANT:\r\n    - Policy elements can appear only within the <inbound>, <outbound>, <backend> section elements.\r\n    - Only the <forward-request> policy element can appear within the <backend> section element.\r\n    - To apply a policy to the incoming request (before it is forwarded to the backend service), place a corresponding policy element within the <inbound> section element.\r\n    - To apply a policy to the outgoing response (before it is sent back to the caller), place a corresponding policy element within the <outbound> section element.\r\n    - To add a policy position the cursor at the desired insertion point and click on the round button associated with the policy.\r\n    - To remove a policy, delete the corresponding policy statement from the policy document.\r\n    - Policies are applied in the order of their appearance, from the top down.\r\n-->\r\n<policies>\r\n\t<inbound>\r\n\t\t<cors allow-credentials=\"true\" terminate-unmatched-request=\"false\">\r\n\t\t\t<allowed-origins>\r\n\t\t\t\t<origin>https://nevioservicecenterapim.developer.azure-api.net</origin>\r\n\t\t\t\t<origin>https://sc-ui-archive-hub6d4hedsfjdkgg.eastus2-01.azurewebsites.net</origin>\r\n\t\t\t\t<origin>http://localhost:3000</origin>\r\n\t\t\t\t<origin>http://localhost:3001</origin>\r\n\t\t\t\t<origin>http://localhost:3002</origin>\r\n\t\t\t\t<origin>http://localhost:3005</origin>\r\n\t\t\t\t<origin>http://localhost:3006</origin>\r\n\t\t\t</allowed-origins>\r\n\t\t\t<allowed-methods preflight-result-max-age=\"300\">\r\n\t\t\t\t<method>*</method>\r\n\t\t\t</allowed-methods>\r\n\t\t\t<allowed-headers>\r\n\t\t\t\t<header>*</header>\r\n\t\t\t</allowed-headers>\r\n\t\t\t<expose-headers>\r\n\t\t\t\t<header>*</header>\r\n\t\t\t</expose-headers>\r\n\t\t</cors>\r\n\t</inbound>\r\n\t<backend>\r\n\t\t<forward-request />\r\n\t</backend>\r\n\t<outbound />\r\n\t<on-error />\r\n</policies>"
}
resource "azurerm_api_management_product" "res-99" {
  api_management_name = "NevioServiceCenterAPIM"
  description         = "Subscribers will be able to run 5 calls/minute up to a maximum of 100 calls/week."
  display_name        = "Starter"
  product_id          = "starter"
  published           = true
  resource_group_name = "amedeusnevio_rg"
  subscriptions_limit = 1
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_product_api" "res-101" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "echo-api"
  product_id          = "starter"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_product.res-99
  ]
}
resource "azurerm_api_management_product_group" "res-105" {
  api_management_name = "NevioServiceCenterAPIM"
  group_name          = "administrators"
  product_id          = "starter"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_product.res-99
  ]
}
resource "azurerm_api_management_product_group" "res-106" {
  api_management_name = "NevioServiceCenterAPIM"
  group_name          = "developers"
  product_id          = "starter"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_product.res-99
  ]
}
resource "azurerm_api_management_product_group" "res-107" {
  api_management_name = "NevioServiceCenterAPIM"
  group_name          = "guests"
  product_id          = "starter"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_product.res-99
  ]
}
resource "azurerm_api_management_product_policy" "res-108" {
  api_management_name = "NevioServiceCenterAPIM"
  product_id          = "starter"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_product.res-99
  ]
}
resource "azurerm_api_management_product" "res-110" {
  api_management_name = "NevioServiceCenterAPIM"
  approval_required   = true
  description         = "Subscribers have completely unlimited access to the API. Administrator approval is required."
  display_name        = "Unlimited"
  product_id          = "unlimited"
  published           = true
  resource_group_name = "amedeusnevio_rg"
  subscriptions_limit = 1
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_product_api" "res-112" {
  api_management_name = "NevioServiceCenterAPIM"
  api_name            = "echo-api"
  product_id          = "unlimited"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_product.res-110
  ]
}
resource "azurerm_api_management_product_group" "res-116" {
  api_management_name = "NevioServiceCenterAPIM"
  group_name          = "administrators"
  product_id          = "unlimited"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_product.res-110
  ]
}
resource "azurerm_api_management_product_group" "res-117" {
  api_management_name = "NevioServiceCenterAPIM"
  group_name          = "developers"
  product_id          = "unlimited"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_product.res-110
  ]
}
resource "azurerm_api_management_product_group" "res-118" {
  api_management_name = "NevioServiceCenterAPIM"
  group_name          = "guests"
  product_id          = "unlimited"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_api_management_product.res-110
  ]
}
resource "azurerm_api_management_subscription" "res-123" {
  allow_tracing       = false
  api_management_name = "NevioServiceCenterAPIM"
  display_name        = ""
  product_id          = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.ApiManagement/service/NevioServiceCenterAPIM/products/starter"
  resource_group_name = "amedeusnevio_rg"
  state               = "active"
  user_id             = azurerm_api_management_user.res-144.id
  depends_on = [
    # One of azurerm_api_management_product.res-99,azurerm_api_management_product_policy.res-108 (can't auto-resolve as their ids are identical)
  ]
}
resource "azurerm_api_management_subscription" "res-124" {
  allow_tracing       = false
  api_management_name = "NevioServiceCenterAPIM"
  display_name        = ""
  product_id          = azurerm_api_management_product.res-110.id
  resource_group_name = "amedeusnevio_rg"
  state               = "active"
  user_id             = azurerm_api_management_user.res-144.id
}
resource "azurerm_api_management_tag" "res-126" {
  api_management_id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.ApiManagement/service/NevioServiceCenterAPIM"
  name              = "passenger-6881b334ff145ef7e3bf1062"
  depends_on = [
    azurerm_api_management.res-1
    # One of azurerm_api_management.res-1,azurerm_api_management_policy.res-90 (can't auto-resolve as their ids are identical)
  ]
}
resource "azurerm_api_management_tag" "res-127" {
  api_management_id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.ApiManagement/service/NevioServiceCenterAPIM"
  name              = "pet"
  depends_on = [
    azurerm_api_management.res-1
    # One of azurerm_api_management.res-1,azurerm_api_management_policy.res-90 (can't auto-resolve as their ids are identical)
  ]
}
resource "azurerm_api_management_tag" "res-128" {
  api_management_id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.ApiManagement/service/NevioServiceCenterAPIM"
  name              = "store"
  depends_on = [
    azurerm_api_management.res-1
    # One of azurerm_api_management.res-1,azurerm_api_management_policy.res-90 (can't auto-resolve as their ids are identical)
  ]
}
resource "azurerm_api_management_tag" "res-129" {
  api_management_id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.ApiManagement/service/NevioServiceCenterAPIM"
  name              = "user"
  depends_on = [
    azurerm_api_management.res-1
    # One of azurerm_api_management.res-1,azurerm_api_management_policy.res-90 (can't auto-resolve as their ids are identical)
  ]
}
resource "azurerm_api_management_email_template" "res-130" {
  api_management_name = "NevioServiceCenterAPIM"
  body                = "<!DOCTYPE html >\r\n<html>\r\n  <head />\r\n  <body>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Dear $DevFirstName $DevLastName,</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n          On behalf of $OrganizationName and our customers we thank you for giving us a try. Your $OrganizationName API account is now closed.\r\n        </p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Thank you,</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Your $OrganizationName Team</p>\r\n    <a href=\"$DevPortalUrl\">$DevPortalUrl</a>\r\n    <p />\r\n  </body>\r\n</html>"
  resource_group_name = "amedeusnevio_rg"
  subject             = "Thank you for using the $OrganizationName API!"
  template_name       = "AccountClosedDeveloper"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_email_template" "res-131" {
  api_management_name = "NevioServiceCenterAPIM"
  body                = "<!DOCTYPE html >\r\n<html>\r\n  <head />\r\n  <body>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Dear $DevFirstName $DevLastName,</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n          We are happy to let you know that your request to publish the $AppName application in the application gallery has been approved. Your application has been published and can be viewed <a href=\"http://$DevPortalUrl/Applications/Details/$AppId\">here</a>.\r\n        </p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Best,</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">The $OrganizationName API Team</p>\r\n  </body>\r\n</html>"
  resource_group_name = "amedeusnevio_rg"
  subject             = "Your application $AppName is published in the application gallery"
  template_name       = "ApplicationApprovedNotificationMessage"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_email_template" "res-132" {
  api_management_name = "NevioServiceCenterAPIM"
  body                = "<!DOCTYPE html >\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\" />\r\n    <title>Letter</title>\r\n  </head>\r\n  <body>\r\n    <table width=\"100%\">\r\n      <tr>\r\n        <td>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">Dear $DevFirstName $DevLastName,</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\"></p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">Thank you for joining the $OrganizationName API program! We host a growing number of cool APIs and strive to provide an awesome experience for API developers.</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">First order of business is to activate your account and get you going. To that end, please click on the following link:</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n            <a id=\"confirmUrl\" href=\"$ConfirmUrl\" style=\"text-decoration:none\">\r\n              <strong>$ConfirmUrl</strong>\r\n            </a>\r\n          </p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">If clicking the link does not work, please copy-and-paste or re-type it into your browser's address bar and hit \"Enter\".</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">Thank you,</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">$OrganizationName API Team</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n            <a href=\"$DevPortalUrl\">$DevPortalUrl</a>\r\n          </p>\r\n        </td>\r\n      </tr>\r\n    </table>\r\n  </body>\r\n</html>"
  resource_group_name = "amedeusnevio_rg"
  subject             = "Please confirm your new $OrganizationName API account"
  template_name       = "ConfirmSignUpIdentityDefault"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_email_template" "res-133" {
  api_management_name = "NevioServiceCenterAPIM"
  body                = "<!DOCTYPE html >\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\" />\r\n    <title>Letter</title>\r\n  </head>\r\n  <body>\r\n    <table width=\"100%\">\r\n      <tr>\r\n        <td>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">Dear $DevFirstName $DevLastName,</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\"></p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">You are receiving this email because you made a change to the email address on your $OrganizationName API account.</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">Please click on the following link to confirm the change:</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n            <a id=\"confirmUrl\" href=\"$ConfirmUrl\" style=\"text-decoration:none\">\r\n              <strong>$ConfirmUrl</strong>\r\n            </a>\r\n          </p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">If clicking the link does not work, please copy-and-paste or re-type it into your browser's address bar and hit \"Enter\".</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">Thank you,</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">$OrganizationName API Team</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n            <a href=\"$DevPortalUrl\">$DevPortalUrl</a>\r\n          </p>\r\n        </td>\r\n      </tr>\r\n    </table>\r\n  </body>\r\n</html>"
  resource_group_name = "amedeusnevio_rg"
  subject             = "Please confirm the new email associated with your $OrganizationName API account"
  template_name       = "EmailChangeIdentityDefault"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_email_template" "res-134" {
  api_management_name = "NevioServiceCenterAPIM"
  body                = "<!DOCTYPE html >\r\n<html>\r\n  <head />\r\n  <body>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Dear $DevFirstName $DevLastName,</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n          Your account has been created. Please follow the link below to visit the $OrganizationName developer portal and claim it:\r\n        </p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n      <a href=\"$ConfirmUrl\">$ConfirmUrl</a>\r\n    </p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Best,</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">The $OrganizationName API Team</p>\r\n  </body>\r\n</html>"
  resource_group_name = "amedeusnevio_rg"
  subject             = "You are invited to join the $OrganizationName developer network"
  template_name       = "InviteUserNotificationMessage"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_email_template" "res-135" {
  api_management_name = "NevioServiceCenterAPIM"
  body                = "<!DOCTYPE html >\r\n<html>\r\n  <head />\r\n  <body>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Dear $DevFirstName $DevLastName,</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">This is a brief note to let you know that $CommenterFirstName $CommenterLastName made the following comment on the issue $IssueName you created:</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">$CommentText</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n          To view the issue on the developer portal click <a href=\"http://$DevPortalUrl/issues/$IssueId\">here</a>.\r\n        </p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Best,</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">The $OrganizationName API Team</p>\r\n  </body>\r\n</html>"
  resource_group_name = "amedeusnevio_rg"
  subject             = "$IssueName issue has a new comment"
  template_name       = "NewCommentNotificationMessage"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_email_template" "res-136" {
  api_management_name = "NevioServiceCenterAPIM"
  body                = "<!DOCTYPE html >\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\" />\r\n    <title>Letter</title>\r\n  </head>\r\n  <body>\r\n    <h1 style=\"color:#000505;font-size:18pt;font-family:'Segoe UI'\">\r\n          Welcome to <span style=\"color:#003363\">$OrganizationName API!</span></h1>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Dear $DevFirstName $DevLastName,</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Your $OrganizationName API program registration is completed and we are thrilled to have you as a customer. Here are a few important bits of information for your reference:</p>\r\n    <table width=\"100%\" style=\"margin:20px 0\">\r\n      <tr>\r\n            #if ($IdentityProvider == \"Basic\")\r\n            <td width=\"50%\" style=\"height:40px;vertical-align:top;font-family:'Segoe UI';font-size:12pt\">\r\n              Please use the following <strong>username</strong> when signing into any of the $${OrganizationName}-hosted developer portals:\r\n            </td><td style=\"vertical-align:top;font-family:'Segoe UI';font-size:12pt\"><strong>$DevUsername</strong></td>\r\n            #else\r\n            <td width=\"50%\" style=\"height:40px;vertical-align:top;font-family:'Segoe UI';font-size:12pt\">\r\n              Please use the following <strong>$IdentityProvider account</strong> when signing into any of the $${OrganizationName}-hosted developer portals:\r\n            </td><td style=\"vertical-align:top;font-family:'Segoe UI';font-size:12pt\"><strong>$DevUsername</strong></td>            \r\n            #end\r\n          </tr>\r\n      <tr>\r\n        <td style=\"height:40px;vertical-align:top;font-family:'Segoe UI';font-size:12pt\">\r\n              We will direct all communications to the following <strong>email address</strong>:\r\n            </td>\r\n        <td style=\"vertical-align:top;font-family:'Segoe UI';font-size:12pt\">\r\n          <a href=\"mailto:$DevEmail\" style=\"text-decoration:none\">\r\n            <strong>$DevEmail</strong>\r\n          </a>\r\n        </td>\r\n      </tr>\r\n    </table>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Best of luck in your API pursuits!</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">$OrganizationName API Team</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n      <a href=\"http://$DevPortalUrl\">$DevPortalUrl</a>\r\n    </p>\r\n  </body>\r\n</html>"
  resource_group_name = "amedeusnevio_rg"
  subject             = "Welcome to the $OrganizationName API!"
  template_name       = "NewDeveloperNotificationMessage"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_email_template" "res-137" {
  api_management_name = "NevioServiceCenterAPIM"
  body                = "<!DOCTYPE html >\r\n<html>\r\n  <head />\r\n  <body>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Dear $DevFirstName $DevLastName,</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Thank you for contacting us. Our API team will review your issue and get back to you soon.</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n          Click this <a href=\"http://$DevPortalUrl/issues/$IssueId\">link</a> to view or edit your request.\r\n        </p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Best,</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">The $OrganizationName API Team</p>\r\n  </body>\r\n</html>"
  resource_group_name = "amedeusnevio_rg"
  subject             = "Your request $IssueName was received"
  template_name       = "NewIssueNotificationMessage"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_email_template" "res-138" {
  api_management_name = "NevioServiceCenterAPIM"
  body                = "<!DOCTYPE html >\r\n<html>\r\n  <head />\r\n  <body>\r\n    <table width=\"100%\">\r\n      <tr>\r\n        <td>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">Dear $DevFirstName $DevLastName,</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\"></p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">The password of your $OrganizationName API account has been reset, per your request.</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n                Your new password is: <strong>$DevPassword</strong></p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">Please make sure to change it next time you sign in.</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">Thank you,</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">$OrganizationName API Team</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n            <a href=\"$DevPortalUrl\">$DevPortalUrl</a>\r\n          </p>\r\n        </td>\r\n      </tr>\r\n    </table>\r\n  </body>\r\n</html>"
  resource_group_name = "amedeusnevio_rg"
  subject             = "Your password was reset"
  template_name       = "PasswordResetByAdminNotificationMessage"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_email_template" "res-139" {
  api_management_name = "NevioServiceCenterAPIM"
  body                = "<!DOCTYPE html >\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\" />\r\n    <title>Letter</title>\r\n  </head>\r\n  <body>\r\n    <table width=\"100%\">\r\n      <tr>\r\n        <td>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">Dear $DevFirstName $DevLastName,</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\"></p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">You are receiving this email because you requested to change the password on your $OrganizationName API account.</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">Please click on the link below and follow instructions to create your new password:</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n            <a id=\"resetUrl\" href=\"$ConfirmUrl\" style=\"text-decoration:none\">\r\n              <strong>$ConfirmUrl</strong>\r\n            </a>\r\n          </p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">If clicking the link does not work, please copy-and-paste or re-type it into your browser's address bar and hit \"Enter\".</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">Thank you,</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">$OrganizationName API Team</p>\r\n          <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n            <a href=\"$DevPortalUrl\">$DevPortalUrl</a>\r\n          </p>\r\n        </td>\r\n      </tr>\r\n    </table>\r\n  </body>\r\n</html>"
  resource_group_name = "amedeusnevio_rg"
  subject             = "Your password change request"
  template_name       = "PasswordResetIdentityDefault"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_email_template" "res-140" {
  api_management_name = "NevioServiceCenterAPIM"
  body                = "<!DOCTYPE html >\r\n<html>\r\n  <head />\r\n  <body>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Greetings $DevFirstName $DevLastName!</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n          Thank you for subscribing to the <a href=\"http://$DevPortalUrl/products/$ProdId\"><strong>$ProdName</strong></a> and welcome to the $OrganizationName developer community. We are delighted to have you as part of the team and are looking forward to the amazing applications you will build using our API!\r\n        </p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Below are a few subscription details for your reference:</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n      <ul>\r\n            #if ($SubStartDate != \"\")\r\n            <li style=\"font-size:12pt;font-family:'Segoe UI'\">Start date: $SubStartDate</li>\r\n            #end\r\n            \r\n            #if ($SubTerm != \"\")\r\n            <li style=\"font-size:12pt;font-family:'Segoe UI'\">Subscription term: $SubTerm</li>\r\n            #end\r\n          </ul>\r\n    </p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n            Visit the developer <a href=\"http://$DevPortalUrl/developer\">profile area</a> to manage your subscription and subscription keys\r\n        </p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">A couple of pointers to help get you started:</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n      <strong>\r\n        <a href=\"http://$DevPortalUrl/docs/services?product=$ProdId\">Learn about the API</a>\r\n      </strong>\r\n    </p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">The API documentation provides all information necessary to make a request and to process a response. Code samples are provided per API operation in a variety of languages. Moreover, an interactive console allows making API calls directly from the developer portal without writing any code.</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n      <strong>\r\n        <a href=\"http://$DevPortalUrl/applications\">Feature your app in the app gallery</a>\r\n      </strong>\r\n    </p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">You can publish your application on our gallery for increased visibility to potential new users.</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n      <strong>\r\n        <a href=\"http://$DevPortalUrl/issues\">Stay in touch</a>\r\n      </strong>\r\n    </p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n          If you have an issue, a question, a suggestion, a request, or if you just want to tell us something, go to the <a href=\"http://$DevPortalUrl/issues\">Issues</a> page on the developer portal and create a new topic.\r\n        </p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Happy hacking,</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">The $OrganizationName API Team</p>\r\n    <a style=\"font-size:12pt;font-family:'Segoe UI'\" href=\"http://$DevPortalUrl\">$DevPortalUrl</a>\r\n  </body>\r\n</html>"
  resource_group_name = "amedeusnevio_rg"
  subject             = "Your subscription to the $ProdName"
  template_name       = "PurchaseDeveloperNotificationMessage"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_email_template" "res-141" {
  api_management_name = "NevioServiceCenterAPIM"
  body                = "<!DOCTYPE html >\r\n<html>\r\n  <head>\r\n    <style>\r\n          body {font-size:12pt; font-family:\"Segoe UI\",\"Segoe WP\",\"Tahoma\",\"Arial\",\"sans-serif\";}\r\n          .alert { color: red; }\r\n          .child1 { padding-left: 20px; }\r\n          .child2 { padding-left: 40px; }\r\n          .number { text-align: right; }\r\n          .text { text-align: left; }\r\n          th, td { padding: 4px 10px; min-width: 100px; }\r\n          th { background-color: #DDDDDD;}\r\n        </style>\r\n  </head>\r\n  <body>\r\n    <p>Greetings $DevFirstName $DevLastName!</p>\r\n    <p>\r\n          You are approaching the quota limit on you subscription to the <strong>$ProdName</strong> product (primary key $SubPrimaryKey).\r\n          #if ($QuotaResetDate != \"\")\r\n          This quota will be renewed on $QuotaResetDate.\r\n          #else\r\n          This quota will not be renewed.\r\n          #end\r\n        </p>\r\n    <p>Below are details on quota usage for the subscription:</p>\r\n    <p>\r\n      <table>\r\n        <thead>\r\n          <th class=\"text\">Quota Scope</th>\r\n          <th class=\"number\">Calls</th>\r\n          <th class=\"number\">Call Quota</th>\r\n          <th class=\"number\">Bandwidth</th>\r\n          <th class=\"number\">Bandwidth Quota</th>\r\n        </thead>\r\n        <tbody>\r\n          <tr>\r\n            <td class=\"text\">Subscription</td>\r\n            <td class=\"number\">\r\n                  #if ($CallsAlert == true)\r\n                  <span class=\"alert\">$Calls</span>\r\n                  #else\r\n                  $Calls\r\n                  #end\r\n                </td>\r\n            <td class=\"number\">$CallQuota</td>\r\n            <td class=\"number\">\r\n                  #if ($BandwidthAlert == true)\r\n                  <span class=\"alert\">$Bandwidth</span>\r\n                  #else\r\n                  $Bandwidth\r\n                  #end\r\n                </td>\r\n            <td class=\"number\">$BandwidthQuota</td>\r\n          </tr>\r\n              #foreach ($api in $Apis)\r\n              <tr><td class=\"child1 text\">API: $api.Name</td><td class=\"number\">\r\n                  #if ($api.CallsAlert == true)\r\n                  <span class=\"alert\">$api.Calls</span>\r\n                  #else\r\n                  $api.Calls\r\n                  #end\r\n                </td><td class=\"number\">$api.CallQuota</td><td class=\"number\">\r\n                  #if ($api.BandwidthAlert == true)\r\n                  <span class=\"alert\">$api.Bandwidth</span>\r\n                  #else\r\n                  $api.Bandwidth\r\n                  #end\r\n                </td><td class=\"number\">$api.BandwidthQuota</td></tr>\r\n              #foreach ($operation in $api.Operations)\r\n              <tr><td class=\"child2 text\">Operation: $operation.Name</td><td class=\"number\">\r\n                  #if ($operation.CallsAlert == true)\r\n                  <span class=\"alert\">$operation.Calls</span>\r\n                  #else\r\n                  $operation.Calls\r\n                  #end\r\n                </td><td class=\"number\">$operation.CallQuota</td><td class=\"number\">\r\n                  #if ($operation.BandwidthAlert == true)\r\n                  <span class=\"alert\">$operation.Bandwidth</span>\r\n                  #else\r\n                  $operation.Bandwidth\r\n                  #end\r\n                </td><td class=\"number\">$operation.BandwidthQuota</td></tr>\r\n              #end\r\n              #end\r\n            </tbody>\r\n      </table>\r\n    </p>\r\n    <p>Thank you,</p>\r\n    <p>$OrganizationName API Team</p>\r\n    <a href=\"$DevPortalUrl\">$DevPortalUrl</a>\r\n    <p />\r\n  </body>\r\n</html>"
  resource_group_name = "amedeusnevio_rg"
  subject             = "You are approaching an API quota limit"
  template_name       = "QuotaLimitApproachingDeveloperNotificationMessage"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_email_template" "res-142" {
  api_management_name = "NevioServiceCenterAPIM"
  body                = "<!DOCTYPE html >\r\n<html>\r\n  <head />\r\n  <body>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Dear $DevFirstName $DevLastName,</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n          We would like to inform you that we reviewed your subscription request for the <strong>$ProdName</strong>.\r\n        </p>\r\n        #if ($SubDeclineReason == \"\")\r\n        <p style=\"font-size:12pt;font-family:'Segoe UI'\">Regretfully, we were unable to approve it, as subscriptions are temporarily suspended at this time.</p>\r\n        #else\r\n        <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n          Regretfully, we were unable to approve it at this time for the following reason:\r\n          <div style=\"margin-left: 1.5em;\"> $SubDeclineReason </div></p>\r\n        #end\r\n        <p style=\"font-size:12pt;font-family:'Segoe UI'\"> We truly appreciate your interest. </p><p style=\"font-size:12pt;font-family:'Segoe UI'\">All the best,</p><p style=\"font-size:12pt;font-family:'Segoe UI'\">The $OrganizationName API Team</p><a style=\"font-size:12pt;font-family:'Segoe UI'\" href=\"http://$DevPortalUrl\">$DevPortalUrl</a></body>\r\n</html>"
  resource_group_name = "amedeusnevio_rg"
  subject             = "Your subscription request for the $ProdName"
  template_name       = "RejectDeveloperNotificationMessage"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_email_template" "res-143" {
  api_management_name = "NevioServiceCenterAPIM"
  body                = "<!DOCTYPE html >\r\n<html>\r\n  <head />\r\n  <body>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Dear $DevFirstName $DevLastName,</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n          Thank you for your interest in our <strong>$ProdName</strong> API product!\r\n        </p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">\r\n          We were delighted to receive your subscription request. We will promptly review it and get back to you at <strong>$DevEmail</strong>.\r\n        </p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">Thank you,</p>\r\n    <p style=\"font-size:12pt;font-family:'Segoe UI'\">The $OrganizationName API Team</p>\r\n    <a style=\"font-size:12pt;font-family:'Segoe UI'\" href=\"http://$DevPortalUrl\">$DevPortalUrl</a>\r\n  </body>\r\n</html>"
  resource_group_name = "amedeusnevio_rg"
  subject             = "Your subscription request for the $ProdName"
  template_name       = "RequestDeveloperNotificationMessage"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_api_management_user" "res-144" {
  api_management_name = "NevioServiceCenterAPIM"
  email               = "savitha.ekambaram@tcs.com"
  first_name          = "Administrator"
  last_name           = ""
  resource_group_name = "amedeusnevio_rg"
  user_id             = "1"
  depends_on = [
    azurerm_api_management.res-1
  ]
}
resource "azurerm_app_configuration" "res-145" {
  location                   = "eastus"
  name                       = "NevioAppConfig"
  resource_group_name        = "amedeusnevio_rg"
  soft_delete_retention_days = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_automation_account" "res-146" {
  location            = "eastus"
  name                = "amedeusnevio-Automation"
  resource_group_name = "amedeusnevio_rg"
  sku_name            = "Basic"
  identity {
    type = "SystemAssigned"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_automation_connection_type" "res-147" {
  automation_account_name = "amedeusnevio-Automation"
  is_global               = true
  name                    = "Azure"
  resource_group_name     = "amedeusnevio_rg"
  field {
    name = "AutomationCertificateName"
    type = "System.String"
  }
  field {
    name = "SubscriptionID"
    type = "System.String"
  }
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_connection_type" "res-148" {
  automation_account_name = "amedeusnevio-Automation"
  is_global               = true
  name                    = "AzureClassicCertificate"
  resource_group_name     = "amedeusnevio_rg"
  field {
    name = "SubscriptionName"
    type = "System.String"
  }
  field {
    name = "SubscriptionId"
    type = "System.String"
  }
  field {
    name = "CertificateAssetName"
    type = "System.String"
  }
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_connection_type" "res-149" {
  automation_account_name = "amedeusnevio-Automation"
  is_global               = true
  name                    = "AzureServicePrincipal"
  resource_group_name     = "amedeusnevio_rg"
  field {
    name = "ApplicationId"
    type = "System.String"
  }
  field {
    name = "TenantId"
    type = "System.String"
  }
  field {
    name = "CertificateThumbprint"
    type = "System.String"
  }
  field {
    name = "SubscriptionId"
    type = "System.String"
  }
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_job_schedule" "res-269" {
  automation_account_name = "amedeusnevio-Automation"
  resource_group_name     = "amedeusnevio_rg"
  runbook_name            = "Test-env"
  schedule_name           = "Postgres-db"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_job_schedule" "res-270" {
  automation_account_name = "amedeusnevio-Automation"
  resource_group_name     = "amedeusnevio_rg"
  runbook_name            = "Functionapps"
  schedule_name           = "AzureFunctionApps"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_job_schedule" "res-271" {
  automation_account_name = "amedeusnevio-Automation"
  resource_group_name     = "amedeusnevio_rg"
  runbook_name            = "AzureDatabaseforPostgreSQLflexibleservers-nevioscuidb"
  schedule_name           = "Postgres-db"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_job_schedule" "res-272" {
  automation_account_name = "amedeusnevio-Automation"
  resource_group_name     = "amedeusnevio_rg"
  runbook_name            = "Test-env"
  schedule_name           = "Appservice"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_job_schedule" "res-273" {
  automation_account_name = "amedeusnevio-Automation"
  resource_group_name     = "amedeusnevio_rg"
  runbook_name            = "sample"
  schedule_name           = "sample"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-274" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "AuditPolicyDsc"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-275" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-276" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Accounts"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-277" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Advisor"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-278" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Aks"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-279" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.AnalysisServices"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-280" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.ApiManagement"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-281" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.App"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-282" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.AppConfiguration"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-283" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.ApplicationInsights"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-284" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.ArcResourceBridge"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-285" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Attestation"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-286" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Automanage"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-287" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Automation"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-288" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Batch"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-289" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Billing"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-290" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Cdn"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-291" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.CloudService"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-292" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.CognitiveServices"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-293" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Compute"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-294" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.ConfidentialLedger"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-295" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.ContainerInstance"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-296" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.ContainerRegistry"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-297" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.CosmosDB"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-298" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.DataBoxEdge"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-299" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.DataFactory"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-300" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.DataLakeAnalytics"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-301" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.DataLakeStore"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-302" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.DataProtection"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-303" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.DataShare"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-304" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Databricks"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-305" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.DeploymentManager"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-306" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.DesktopVirtualization"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-307" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.DevCenter"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-308" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.DevTestLabs"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-309" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Dns"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-310" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.EventGrid"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-311" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.EventHub"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-312" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.FrontDoor"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-313" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Functions"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-314" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.HDInsight"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-315" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.HealthcareApis"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-316" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.IotHub"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-317" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.KeyVault"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-318" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Kusto"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-319" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.LoadTesting"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-320" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.LogicApp"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-321" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.MachineLearning"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-322" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.MachineLearningServices"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-323" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Maintenance"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-324" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.ManagedServiceIdentity"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-325" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.ManagedServices"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-326" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.MarketplaceOrdering"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-327" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Media"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-328" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Migrate"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-329" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Monitor"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-330" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.MySql"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-331" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Network"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-332" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.NetworkCloud"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-333" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.NotificationHubs"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-334" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.OperationalInsights"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-335" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.PolicyInsights"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-336" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.PostgreSql"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-337" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.PowerBIEmbedded"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-338" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.PrivateDns"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-339" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.RecoveryServices"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-340" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.RedisCache"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-341" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.RedisEnterpriseCache"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-342" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Relay"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-343" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.ResourceMover"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-344" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Resources"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-345" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Security"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-346" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.SecurityInsights"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-347" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.ServiceBus"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-348" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.ServiceFabric"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-349" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.SignalR"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-350" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Sql"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-351" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.SqlVirtualMachine"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-352" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.StackHCI"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-353" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Storage"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-354" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.StorageMover"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-355" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.StorageSync"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-356" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.StreamAnalytics"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-357" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Support"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-358" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Synapse"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-359" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.TrafficManager"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-360" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Az.Websites"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-361" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Azure"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-362" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Azure.Storage"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-363" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "AzureRM.Automation"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-364" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "AzureRM.Compute"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-365" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "AzureRM.Profile"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-366" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "AzureRM.Resources"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-367" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "AzureRM.Sql"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-368" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "AzureRM.Storage"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-369" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "ComputerManagementDsc"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-370" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "GPRegistryPolicyParser"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-371" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Microsoft.PowerShell.Core"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-372" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Microsoft.PowerShell.Diagnostics"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-373" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Microsoft.PowerShell.Management"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-374" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Microsoft.PowerShell.Security"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-375" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Microsoft.PowerShell.Utility"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-376" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Microsoft.WSMan.Management"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-377" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "Orchestrator.AssetManagement.Cmdlets"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-378" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "PSDscResources"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-379" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "SecurityPolicyDsc"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-380" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "StateConfigCompositeResources"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-381" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "xDSCDomainjoin"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-382" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "xPowerShellExecutionPolicy"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_module" "res-383" {
  automation_account_name = "amedeusnevio-Automation"
  name                    = "xRemoteDesktopAdmin"
  resource_group_name     = "amedeusnevio_rg"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_powershell72_module" "res-384" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az"
}
resource "azurerm_automation_powershell72_module" "res-385" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Accounts"
}
resource "azurerm_automation_powershell72_module" "res-386" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Advisor"
}
resource "azurerm_automation_powershell72_module" "res-387" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Aks"
}
resource "azurerm_automation_powershell72_module" "res-388" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.AnalysisServices"
}
resource "azurerm_automation_powershell72_module" "res-389" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.ApiManagement"
}
resource "azurerm_automation_powershell72_module" "res-390" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.App"
}
resource "azurerm_automation_powershell72_module" "res-391" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.AppConfiguration"
}
resource "azurerm_automation_powershell72_module" "res-392" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.ApplicationInsights"
}
resource "azurerm_automation_powershell72_module" "res-393" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.ArcResourceBridge"
}
resource "azurerm_automation_powershell72_module" "res-394" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Attestation"
}
resource "azurerm_automation_powershell72_module" "res-395" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Automanage"
}
resource "azurerm_automation_powershell72_module" "res-396" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Automation"
}
resource "azurerm_automation_powershell72_module" "res-397" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Batch"
}
resource "azurerm_automation_powershell72_module" "res-398" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Billing"
}
resource "azurerm_automation_powershell72_module" "res-399" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Cdn"
}
resource "azurerm_automation_powershell72_module" "res-400" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.CloudService"
}
resource "azurerm_automation_powershell72_module" "res-401" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.CognitiveServices"
}
resource "azurerm_automation_powershell72_module" "res-402" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Compute"
}
resource "azurerm_automation_powershell72_module" "res-403" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.ConfidentialLedger"
}
resource "azurerm_automation_powershell72_module" "res-404" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.ContainerInstance"
}
resource "azurerm_automation_powershell72_module" "res-405" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.ContainerRegistry"
}
resource "azurerm_automation_powershell72_module" "res-406" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.CosmosDB"
}
resource "azurerm_automation_powershell72_module" "res-407" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.DataBoxEdge"
}
resource "azurerm_automation_powershell72_module" "res-408" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.DataFactory"
}
resource "azurerm_automation_powershell72_module" "res-409" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.DataLakeAnalytics"
}
resource "azurerm_automation_powershell72_module" "res-410" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.DataLakeStore"
}
resource "azurerm_automation_powershell72_module" "res-411" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.DataProtection"
}
resource "azurerm_automation_powershell72_module" "res-412" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.DataShare"
}
resource "azurerm_automation_powershell72_module" "res-413" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Databricks"
}
resource "azurerm_automation_powershell72_module" "res-414" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.DeploymentManager"
}
resource "azurerm_automation_powershell72_module" "res-415" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.DesktopVirtualization"
}
resource "azurerm_automation_powershell72_module" "res-416" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.DevCenter"
}
resource "azurerm_automation_powershell72_module" "res-417" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.DevTestLabs"
}
resource "azurerm_automation_powershell72_module" "res-418" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Dns"
}
resource "azurerm_automation_powershell72_module" "res-419" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.EventGrid"
}
resource "azurerm_automation_powershell72_module" "res-420" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.EventHub"
}
resource "azurerm_automation_powershell72_module" "res-421" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.FrontDoor"
}
resource "azurerm_automation_powershell72_module" "res-422" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Functions"
}
resource "azurerm_automation_powershell72_module" "res-423" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.HDInsight"
}
resource "azurerm_automation_powershell72_module" "res-424" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.HealthcareApis"
}
resource "azurerm_automation_powershell72_module" "res-425" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.IotHub"
}
resource "azurerm_automation_powershell72_module" "res-426" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.KeyVault"
}
resource "azurerm_automation_powershell72_module" "res-427" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Kusto"
}
resource "azurerm_automation_powershell72_module" "res-428" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.LoadTesting"
}
resource "azurerm_automation_powershell72_module" "res-429" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.LogicApp"
}
resource "azurerm_automation_powershell72_module" "res-430" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.MachineLearning"
}
resource "azurerm_automation_powershell72_module" "res-431" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.MachineLearningServices"
}
resource "azurerm_automation_powershell72_module" "res-432" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Maintenance"
}
resource "azurerm_automation_powershell72_module" "res-433" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.ManagedServiceIdentity"
}
resource "azurerm_automation_powershell72_module" "res-434" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.ManagedServices"
}
resource "azurerm_automation_powershell72_module" "res-435" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.MarketplaceOrdering"
}
resource "azurerm_automation_powershell72_module" "res-436" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Media"
}
resource "azurerm_automation_powershell72_module" "res-437" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Migrate"
}
resource "azurerm_automation_powershell72_module" "res-438" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Monitor"
}
resource "azurerm_automation_powershell72_module" "res-439" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.MySql"
}
resource "azurerm_automation_powershell72_module" "res-440" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Network"
}
resource "azurerm_automation_powershell72_module" "res-441" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.NetworkCloud"
}
resource "azurerm_automation_powershell72_module" "res-442" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.NotificationHubs"
}
resource "azurerm_automation_powershell72_module" "res-443" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.OperationalInsights"
}
resource "azurerm_automation_powershell72_module" "res-444" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.PolicyInsights"
}
resource "azurerm_automation_powershell72_module" "res-445" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.PostgreSql"
}
resource "azurerm_automation_powershell72_module" "res-446" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.PowerBIEmbedded"
}
resource "azurerm_automation_powershell72_module" "res-447" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.PrivateDns"
}
resource "azurerm_automation_powershell72_module" "res-448" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.RecoveryServices"
}
resource "azurerm_automation_powershell72_module" "res-449" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.RedisCache"
}
resource "azurerm_automation_powershell72_module" "res-450" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.RedisEnterpriseCache"
}
resource "azurerm_automation_powershell72_module" "res-451" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Relay"
}
resource "azurerm_automation_powershell72_module" "res-452" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.ResourceMover"
}
resource "azurerm_automation_powershell72_module" "res-453" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Resources"
}
resource "azurerm_automation_powershell72_module" "res-454" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Security"
}
resource "azurerm_automation_powershell72_module" "res-455" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.SecurityInsights"
}
resource "azurerm_automation_powershell72_module" "res-456" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.ServiceBus"
}
resource "azurerm_automation_powershell72_module" "res-457" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.ServiceFabric"
}
resource "azurerm_automation_powershell72_module" "res-458" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.SignalR"
}
resource "azurerm_automation_powershell72_module" "res-459" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Sql"
}
resource "azurerm_automation_powershell72_module" "res-460" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.SqlVirtualMachine"
}
resource "azurerm_automation_powershell72_module" "res-461" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.StackHCI"
}
resource "azurerm_automation_powershell72_module" "res-462" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Storage"
}
resource "azurerm_automation_powershell72_module" "res-463" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.StorageMover"
}
resource "azurerm_automation_powershell72_module" "res-464" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.StorageSync"
}
resource "azurerm_automation_powershell72_module" "res-465" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.StreamAnalytics"
}
resource "azurerm_automation_powershell72_module" "res-466" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Support"
}
resource "azurerm_automation_powershell72_module" "res-467" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Synapse"
}
resource "azurerm_automation_powershell72_module" "res-468" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.TrafficManager"
}
resource "azurerm_automation_powershell72_module" "res-469" {
  automation_account_id = azurerm_automation_account.res-146.id
  name                  = "Az.Websites"
}
resource "azurerm_automation_schedule" "res-501" {
  automation_account_name = "amedeusnevio-Automation"
  frequency               = "OneTime"
  name                    = "Appservice"
  resource_group_name     = "amedeusnevio_rg"
  timezone                = "Asia/Kolkata"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_schedule" "res-502" {
  automation_account_name = "amedeusnevio-Automation"
  frequency               = "Day"
  name                    = "AzureAppServices"
  resource_group_name     = "amedeusnevio_rg"
  timezone                = "Asia/Kolkata"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_schedule" "res-503" {
  automation_account_name = "amedeusnevio-Automation"
  description             = "turn off all the function apps at 7:00pm"
  frequency               = "Day"
  name                    = "AzureFunctionApps"
  resource_group_name     = "amedeusnevio_rg"
  timezone                = "Asia/Kolkata"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_schedule" "res-504" {
  automation_account_name = "amedeusnevio-Automation"
  description             = "Amadeus-nevio"
  frequency               = "Day"
  name                    = "Postgres-db"
  resource_group_name     = "amedeusnevio_rg"
  timezone                = "Asia/Kolkata"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_schedule" "res-505" {
  automation_account_name = "amedeusnevio-Automation"
  frequency               = "Day"
  name                    = "Test"
  resource_group_name     = "amedeusnevio_rg"
  timezone                = "Asia/Kolkata"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_schedule" "res-506" {
  automation_account_name = "amedeusnevio-Automation"
  frequency               = "OneTime"
  name                    = "mysql-db"
  resource_group_name     = "amedeusnevio_rg"
  timezone                = "Asia/Kolkata"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_schedule" "res-507" {
  automation_account_name = "amedeusnevio-Automation"
  description             = "To stop all the web app and the function apps"
  frequency               = "Day"
  name                    = "sample"
  resource_group_name     = "amedeusnevio_rg"
  timezone                = "Asia/Kolkata"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_runbook" "res-508" {
  automation_account_name = "amedeusnevio-Automation"
  content                 = "# Authenticate with Azure using Managed Identity\r\nConnect-AzAccount -Identity\r\n \r\n# Optionally filter by Resource Group\r\n$resourceGroup = \"amedeusnevio_rg\" # Or leave empty for all\r\n \r\nif ($resourceGroup) {\r\n    $webApps = Get-AzWebApp -ResourceGroupName $resourceGroup\r\n} else {\r\n    $webApps = Get-AzWebApp\r\n}\r\n \r\nforeach ($app in $webApps) {\r\n    Write-Output \"Stopping App Service: $($app.Name)\"\r\n    Stop-AzWebApp -Name $app.Name -ResourceGroupName $app.ResourceGroup\r\n}"
  description             = "Turn Off all the app services and function apps"
  location                = "eastus"
  log_progress            = false
  log_verbose             = false
  name                    = "AppServices"
  resource_group_name     = "amedeusnevio_rg"
  runbook_type            = "PowerShell72"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_runbook" "res-509" {
  automation_account_name = "amedeusnevio-Automation"
  content                 = "<#\n    .DESCRIPTION\n        An example runbook which gets all the ARM resources using the Managed Identity\n\n    .NOTES\n        AUTHOR: Azure Automation Team\n        LASTEDIT: Oct 26, 2021\n#>\n\n\"Please enable appropriate RBAC permissions to the system identity of this automation account. Otherwise, the runbook may fail...\"\n\ntry\n{\n    \"Logging in to Azure...\"\n    Connect-AzAccount -Identity\n}\ncatch {\n    Write-Error -Message $_.Exception\n    throw $_.Exception\n}\n\n#Get all ARM resources from all resource groups\n$ResourceGroups = Get-AzResourceGroup\n\nforeach ($ResourceGroup in $ResourceGroups)\n{    \n    Write-Output (\"Showing resources in resource group \" + $ResourceGroup.ResourceGroupName)\n    $Resources = Get-AzResource -ResourceGroupName $ResourceGroup.ResourceGroupName\n    foreach ($Resource in $Resources)\n    {\n        Write-Output ($Resource.Name + \" of type \" +  $Resource.ResourceType)\n    }\n    Write-Output (\"\")\n}"
  description             = " An example runbook which gets all the ARM resources using the Managed Identity."
  location                = "eastus"
  log_progress            = false
  log_verbose             = false
  name                    = "AzureAutomationTutorialWithIdentity"
  resource_group_name     = "amedeusnevio_rg"
  runbook_type            = "PowerShell"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_runbook" "res-510" {
  automation_account_name = "amedeusnevio-Automation"
  content = jsonencode({
    RunbookDefinition = "AAEAAAD/////AQAAAAAAAAAMAgAAAGJPcmNoZXN0cmF0b3IuR3JhcGhSdW5ib29rLk1vZGVsLCBWZXJzaW9uPTcuMy4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49MzFiZjM4NTZhZDM2NGUzNQUBAAAALE9yY2hlc3RyYXRvci5HcmFwaFJ1bmJvb2suTW9kZWwuR3JhcGhSdW5ib29rBQAAAApwYXJhbWV0ZXJzCmFjdGl2aXRpZXMFbGlua3MIY29tbWVudHMLb3V0cHV0VHlwZXMDAwMDA7IBU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuTGlzdGAxW1tPcmNoZXN0cmF0b3IuR3JhcGhSdW5ib29rLk1vZGVsLlBhcmFtZXRlciwgT3JjaGVzdHJhdG9yLkdyYXBoUnVuYm9vay5Nb2RlbCwgVmVyc2lvbj03LjMuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPTMxYmYzODU2YWQzNjRlMzVdXbEBU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuTGlzdGAxW1tPcmNoZXN0cmF0b3IuR3JhcGhSdW5ib29rLk1vZGVsLkFjdGl2aXR5LCBPcmNoZXN0cmF0b3IuR3JhcGhSdW5ib29rLk1vZGVsLCBWZXJzaW9uPTcuMy4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49MzFiZjM4NTZhZDM2NGUzNV1drQFTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5MaXN0YDFbW09yY2hlc3RyYXRvci5HcmFwaFJ1bmJvb2suTW9kZWwuTGluaywgT3JjaGVzdHJhdG9yLkdyYXBoUnVuYm9vay5Nb2RlbCwgVmVyc2lvbj03LjMuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPTMxYmYzODU2YWQzNjRlMzVdXbABU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuTGlzdGAxW1tPcmNoZXN0cmF0b3IuR3JhcGhSdW5ib29rLk1vZGVsLkNvbW1lbnQsIE9yY2hlc3RyYXRvci5HcmFwaFJ1bmJvb2suTW9kZWwsIFZlcnNpb249Ny4zLjAuMCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj0zMWJmMzg1NmFkMzY0ZTM1XV1/U3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuTGlzdGAxW1tTeXN0ZW0uU3RyaW5nLCBtc2NvcmxpYiwgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODldXQIAAAAJAwAAAAkEAAAACQUAAAAJBgAAAAkHAAAABAMAAACyAVN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLkxpc3RgMVtbT3JjaGVzdHJhdG9yLkdyYXBoUnVuYm9vay5Nb2RlbC5QYXJhbWV0ZXIsIE9yY2hlc3RyYXRvci5HcmFwaFJ1bmJvb2suTW9kZWwsIFZlcnNpb249Ny4zLjAuMCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj0zMWJmMzg1NmFkMzY0ZTM1XV0DAAAABl9pdGVtcwVfc2l6ZQhfdmVyc2lvbgQAACtPcmNoZXN0cmF0b3IuR3JhcGhSdW5ib29rLk1vZGVsLlBhcmFtZXRlcltdAgAAAAgICQgAAAAAAAAAAAAAAAQEAAAAsQFTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5MaXN0YDFbW09yY2hlc3RyYXRvci5HcmFwaFJ1bmJvb2suTW9kZWwuQWN0aXZpdHksIE9yY2hlc3RyYXRvci5HcmFwaFJ1bmJvb2suTW9kZWwsIFZlcnNpb249Ny4zLjAuMCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj0zMWJmMzg1NmFkMzY0ZTM1XV0DAAAABl9pdGVtcwVfc2l6ZQhfdmVyc2lvbgQAACpPcmNoZXN0cmF0b3IuR3JhcGhSdW5ib29rLk1vZGVsLkFjdGl2aXR5W10CAAAACAgJCQAAAAIAAAACAAAABAUAAACtAVN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLkxpc3RgMVtbT3JjaGVzdHJhdG9yLkdyYXBoUnVuYm9vay5Nb2RlbC5MaW5rLCBPcmNoZXN0cmF0b3IuR3JhcGhSdW5ib29rLk1vZGVsLCBWZXJzaW9uPTcuMy4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49MzFiZjM4NTZhZDM2NGUzNV1dAwAAAAZfaXRlbXMFX3NpemUIX3ZlcnNpb24EAAAmT3JjaGVzdHJhdG9yLkdyYXBoUnVuYm9vay5Nb2RlbC5MaW5rW10CAAAACAgJCgAAAAEAAAABAAAABAYAAACwAVN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLkxpc3RgMVtbT3JjaGVzdHJhdG9yLkdyYXBoUnVuYm9vay5Nb2RlbC5Db21tZW50LCBPcmNoZXN0cmF0b3IuR3JhcGhSdW5ib29rLk1vZGVsLCBWZXJzaW9uPTcuMy4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49MzFiZjM4NTZhZDM2NGUzNV1dAwAAAAZfaXRlbXMFX3NpemUIX3ZlcnNpb24EAAApT3JjaGVzdHJhdG9yLkdyYXBoUnVuYm9vay5Nb2RlbC5Db21tZW50W10CAAAACAgJCwAAAAAAAAAAAAAABAcAAAB/U3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuTGlzdGAxW1tTeXN0ZW0uU3RyaW5nLCBtc2NvcmxpYiwgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODldXQMAAAAGX2l0ZW1zBV9zaXplCF92ZXJzaW9uBgAACAgJDAAAAAAAAAAAAAAABwgAAAAAAQAAAAAAAAAEKU9yY2hlc3RyYXRvci5HcmFwaFJ1bmJvb2suTW9kZWwuUGFyYW1ldGVyAgAAAAcJAAAAAAEAAAAEAAAABChPcmNoZXN0cmF0b3IuR3JhcGhSdW5ib29rLk1vZGVsLkFjdGl2aXR5AgAAAAkNAAAACQ4AAAANAgcKAAAAAAEAAAAEAAAABCRPcmNoZXN0cmF0b3IuR3JhcGhSdW5ib29rLk1vZGVsLkxpbmsCAAAACQ8AAAANAwcLAAAAAAEAAAAAAAAABCdPcmNoZXN0cmF0b3IuR3JhcGhSdW5ib29rLk1vZGVsLkNvbW1lbnQCAAAAEQwAAAAAAAAABQ0AAAA2T3JjaGVzdHJhdG9yLkdyYXBoUnVuYm9vay5Nb2RlbC5Xb3JrZmxvd1NjcmlwdEFjdGl2aXR5DQAAABY8QmVnaW4+a19fQmFja2luZ0ZpZWxkGDxQcm9jZXNzPmtfX0JhY2tpbmdGaWVsZBQ8RW5kPmtfX0JhY2tpbmdGaWVsZCA8Q2hlY2twb2ludEFmdGVyPmtfX0JhY2tpbmdGaWVsZCM8RXhjZXB0aW9uc1RvRXJyb3JzPmtfX0JhY2tpbmdGaWVsZCA8T3V0cHV0VHlwZU5hbWVzPmtfX0JhY2tpbmdGaWVsZCJMb29wYWJsZUFjdGl2aXR5K2xvb3BFeGl0Q29uZGl0aW9uK0xvb3BhYmxlQWN0aXZpdHkrPExvb3BEZWxheT5rX19CYWNraW5nRmllbGQeQWN0aXZpdHkrPE5hbWU+a19fQmFja2luZ0ZpZWxkIkFjdGl2aXR5KzxFbnRpdHlJZD5rX19CYWNraW5nRmllbGQjQWN0aXZpdHkrPFBvc2l0aW9uWD5rX19CYWNraW5nRmllbGQjQWN0aXZpdHkrPFBvc2l0aW9uWT5rX19CYWNraW5nRmllbGQlQWN0aXZpdHkrPERlc2NyaXB0aW9uPmtfX0JhY2tpbmdGaWVsZAEBAQAAAwQEBAEAAAEBAX9TeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5MaXN0YDFbW1N5c3RlbS5TdHJpbmcsIG1zY29ybGliLCBWZXJzaW9uPTQuMC4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49Yjc3YTVjNTYxOTM0ZTA4OV1dKU9yY2hlc3RyYXRvci5HcmFwaFJ1bmJvb2suTW9kZWwuQ29uZGl0aW9uAgAAADdPcmNoZXN0cmF0b3IuR3JhcGhSdW5ib29rLk1vZGVsLkNvbnN0YW50VmFsdWVEZXNjcmlwdG9yAgAAADtPcmNoZXN0cmF0b3IuR3JhcGhSdW5ib29rLk1vZGVsLkV4ZWN1dGFibGVWaWV3LkFjdGl2aXR5TmFtZQIAAAAICAIAAAAGEAAAAAAGEQAAAJoBdHJ5CnsKICAgIFdyaXRlLU91dHB1dCAoIkxvZ2dpbmcgaW4gdG8gQXp1cmUuLi4iKQogICAgQ29ubmVjdC1BekFjY291bnQgLUlkZW50aXR5Cn0KY2F0Y2ggewogICAgV3JpdGUtRXJyb3IgLU1lc3NhZ2UgJF8uRXhjZXB0aW9uCiAgICB0aHJvdyAkXy5FeGNlcHRpb24KfQkQAAAAAAAJEwAAAAkUAAAACRUAAAAJFgAAAAYXAAAAJDRjZjhkNzU4LTlmOTAtNGFkOC1hZTVkLTY2ZmE3YjM1MzU3YdYBAABkAAAABhgAAAAoQ29ubmVjdHMgdG8gYXp1cmUgdXNpbmcgTWFuYWdlZCBJZGVudGl0eQEOAAAADQAAAAkQAAAABhoAAADlBCNHZXQgYWxsIEFSTSByZXNvdXJjZXMgZnJvbSBhbGwgcmVzb3VyY2UgZ3JvdXBzCldyaXRlLU91dHB1dCAoIlBsZWFzZSBlbmFibGUgYXBwcm9wcmlhdGUgUkJBQyBwZXJtaXNzaW9ucyB0byB0aGUgc3lzdGVtIGlkZW50aXR5IG9mIHRoaXMgYXV0b21hdGlvbiBhY2NvdW50LiBPdGhlcndpc2UsIHRoZSBydW5ib29rIG1heSBmYWlsLi4uIikKCiRSZXNvdXJjZUdyb3VwcyA9IEdldC1BelJlc291cmNlR3JvdXAgCgpmb3JlYWNoICgkUmVzb3VyY2VHcm91cCBpbiAkUmVzb3VyY2VHcm91cHMpCnsgICAgCiAgICBXcml0ZS1PdXRwdXQgKCJTaG93aW5nIHJlc291cmNlcyBpbiByZXNvdXJjZSBncm91cCAiICsgJFJlc291cmNlR3JvdXAuUmVzb3VyY2VHcm91cE5hbWUpCiAgICAkUmVzb3VyY2VzID0gR2V0LUF6UmVzb3VyY2UgLVJlc291cmNlR3JvdXBOYW1lICRSZXNvdXJjZUdyb3VwLlJlc291cmNlR3JvdXBOYW1lCiAgICBmb3JlYWNoICgkUmVzb3VyY2UgaW4gJFJlc291cmNlcykKICAgIHsKICAgICAgICBXcml0ZS1PdXRwdXQgKCRSZXNvdXJjZS5OYW1lICsgIiBvZiB0eXBlICIgKyAgJFJlc291cmNlLlJlc291cmNlVHlwZSkKICAgIH0KICAgIFdyaXRlLU91dHB1dCAoIiIpCn0JEAAAAAAACRwAAAAJHQAAAAkeAAAACR8AAAAGIAAAACQ1NDAwOTQ0NS05ODU4LTQxNmUtYjMxNi1hOTM1NDNjYjEzOWbWAQAA3AAAAAYhAAAAPEdldHMgYWxsIHRoZSBBUk0gcmVzb3VyY2VzIHdoaWNoIHRoZSBpZGVudGl0eSBoYXMgYWNjZXNzIHRvLgUPAAAAJE9yY2hlc3RyYXRvci5HcmFwaFJ1bmJvb2suTW9kZWwuTGluawYAAAAObGlua1N0cmVhbVR5cGUJY29uZGl0aW9uHDxEZXNjcmlwdGlvbj5rX19CYWNraW5nRmllbGQsPERlc3RpbmF0aW9uQWN0aXZpdHlFbnRpdHlJZD5rX19CYWNraW5nRmllbGQZPExpbmtUeXBlPmtfX0JhY2tpbmdGaWVsZCc8U291cmNlQWN0aXZpdHlFbnRpdHlJZD5rX19CYWNraW5nRmllbGQDBAEBBAEMU3lzdGVtLkludDMyKU9yY2hlc3RyYXRvci5HcmFwaFJ1bmJvb2suTW9kZWwuQ29uZGl0aW9uAgAAADdPcmNoZXN0cmF0b3IuR3JhcGhSdW5ib29rLk1vZGVsLkV4ZWN1dGFibGVWaWV3LkxpbmtUeXBlAgAAAAIAAAAICAAAAAAJIgAAAAkQAAAABiQAAAAkNTQwMDk0NDUtOTg1OC00MTZlLWIzMTYtYTkzNTQzY2IxMzlmBdv///83T3JjaGVzdHJhdG9yLkdyYXBoUnVuYm9vay5Nb2RlbC5FeGVjdXRhYmxlVmlldy5MaW5rVHlwZQEAAAAHdmFsdWVfXwAIAgAAAAEAAAAGJgAAACQ0Y2Y4ZDc1OC05ZjkwLTRhZDgtYWU1ZC02NmZhN2IzNTM1N2EBEwAAAAcAAAAJJwAAAAEAAAABAAAABRQAAAApT3JjaGVzdHJhdG9yLkdyYXBoUnVuYm9vay5Nb2RlbC5Db25kaXRpb24CAAAACmV4cHJlc3Npb24VPE1vZGU+a19fQmFja2luZ0ZpZWxkAQQtT3JjaGVzdHJhdG9yLkdyYXBoUnVuYm9vay5Nb2RlbC5Db25kaXRpb25Nb2RlAgAAAAIAAAAJEAAAAAXX////LU9yY2hlc3RyYXRvci5HcmFwaFJ1bmJvb2suTW9kZWwuQ29uZGl0aW9uTW9kZQEAAAAHdmFsdWVfXwAIAgAAAAEAAAAFFQAAADdPcmNoZXN0cmF0b3IuR3JhcGhSdW5ib29rLk1vZGVsLkNvbnN0YW50VmFsdWVEZXNjcmlwdG9yAQAAABY8VmFsdWU+a19fQmFja2luZ0ZpZWxkAgIAAAAIDAAAAAAAAAAABRYAAAA7T3JjaGVzdHJhdG9yLkdyYXBoUnVuYm9vay5Nb2RlbC5FeGVjdXRhYmxlVmlldy5BY3Rpdml0eU5hbWUBAAAAGkNhc2VJbnNlbnNpdGl2ZU5hbWVgMStuYW1lAQIAAAAGKgAAABFDb25uZWN0IEF6QWNjb3VudAEcAAAABwAAAAkrAAAAAQAAAAEAAAABHQAAABQAAAAJEAAAAAHT////1////wEAAAABHgAAABUAAAAIDAAAAAAAAAAAAR8AAAAWAAAABi4AAAARR2V0IEFsbCBSZXNvdXJjZXMBIgAAABQAAAAJEAAAAAHQ////1////wEAAAARJwAAAAQAAAAJEAAAAA0DESsAAAAEAAAACRAAAAANAwsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
    RunbookType       = "GraphPowerShell"
    SchemaVersion     = "1.10"
  })
  description         = " An example runbook which gets all the ARM resources using the Managed Identity."
  location            = "eastus"
  log_progress        = false
  log_verbose         = false
  name                = "AzureAutomationTutorialWithIdentityGraphical"
  resource_group_name = "amedeusnevio_rg"
  runbook_type        = "GraphPowerShell"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_runbook" "res-511" {
  automation_account_name = "amedeusnevio-Automation"
  content                 = "#Requires -Module Az.Accounts\r\n#Requires -Module Az.PostgreSql\r\n \r\nparam()\r\n \r\n$subscriptionId = \"6894432a-17c6-42c4-8118-d547be97aca4\"  # Replace with your actual subscription ID\r\n$resourceGroupName = \"amedeusnevio_rg\"\r\n$serverName = \"nevioscuidb\"\r\n \r\nWrite-Output \"Logging in using Managed Identity...\"\r\n \r\ntry {\r\n    Connect-AzAccount -Identity | Out-Null\r\n    Set-AzContext -SubscriptionId $subscriptionId | Out-Null\r\n    Write-Output \"Context set to subscription: $subscriptionId\"\r\n} catch {\r\n    Write-Error \"Authentication or context setup failed: $_\"\r\n    exit\r\n}\r\n \r\nWrite-Output \"Stopping PostgreSQL Flexible Server '$serverName' in resource group '$resourceGroupName'...\"\r\n \r\ntry {\r\n    Stop-AzPostgreSqlFlexibleServer -ResourceGroupName $resourceGroupName -Name $serverName\r\n    Write-Output \"Server stopped successfully.\"\r\n} catch {\r\n    Write-Error \"Error while stopping the server: $_\"\r\n}"
  location                = "eastus"
  log_progress            = false
  log_verbose             = false
  name                    = "AzureDatabaseforPostgreSQLflexibleservers-nevioscuidb"
  resource_group_name     = "amedeusnevio_rg"
  runbook_type            = "PowerShell72"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_runbook" "res-512" {
  automation_account_name = "amedeusnevio-Automation"
  content                 = "# Authenticate with Azure using Managed Identity\r\nConnect-AzAccount -Identity\r\n \r\n# Optional: Specify a resource group or leave blank to fetch from entire subscription\r\n$resourceGroup = \"amedeusnevio_rg\"  # e.g., \"my-resource-group\"\r\n# Get all Function Apps (they are technically Web Apps with kind \"functionapp\")\r\nif ($resourceGroup) {\r\n    $functionApps = Get-AzWebApp -ResourceGroupName $resourceGroup | Where-Object { $_.Kind -like \"*functionapp*\" }\r\n} else {\r\n    $functionApps = Get-AzWebApp | Where-Object { $_.Kind -like \"*functionapp*\" }\r\n}\r\n\r\n \r\n# Stop each Function App\r\nforeach ($func in $functionApps) {\r\n    Write-Output \"Stopping Function App: $($func.Name)\"\r\n    Stop-AzWebApp -Name $func.Name -ResourceGroupName $func.ResourceGroup\r\n}"
  description             = "Turn off all the functionapps"
  location                = "eastus"
  log_progress            = false
  log_verbose             = false
  name                    = "Functionapps"
  resource_group_name     = "amedeusnevio_rg"
  runbook_type            = "PowerShell72"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_runbook" "res-513" {
  automation_account_name = "amedeusnevio-Automation"
  content                 = "# Login using Managed Identity\r\nConnect-AzAccount -Identity\r\n \r\n# Optional: Specify a resource group\r\n# Leave empty to target all resource groups in the subscription\r\n$targetResourceGroup = \"amedeusnevio_rg\"\r\n \r\n# Fetch all MySQL Flexible Servers\r\nif ([string]::IsNullOrEmpty($targetResourceGroup)) {\r\n    $servers = Get-AzMySqlFlexibleServer\r\n} else {\r\n    $servers = Get-AzMySqlFlexibleServer -ResourceGroupName $targetResourceGroup\r\n}\r\n \r\nif ($servers.Count -eq 0) {\r\n    Write-Output \"No MySQL Flexible Servers found.\"\r\n    return\r\n}\r\n \r\n# Loop and stop each server\r\nforeach ($server in $servers) {\r\n    try {\r\n        Write-Output \"Stopping server: $($server.Name) in resource group: $($server.ResourceGroupName)\"\r\n        Stop-AzMySqlFlexibleServer -Name $server.Name -ResourceGroupName $server.ResourceGroupName -Force\r\n        Write-Output \"Successfully stopped: $($server.Name)\"\r\n    } catch {\r\n        Write-Output \"Failed to stop $($server.Name): $_\"\r\n    }\r\n}"
  location                = "eastus"
  log_progress            = false
  log_verbose             = false
  name                    = "MicrosoftMySQLFlexibleServer"
  resource_group_name     = "amedeusnevio_rg"
  runbook_type            = "PowerShell72"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_runbook" "res-514" {
  automation_account_name  = "amedeusnevio-Automation"
  content                  = "# Authenticate with Azure using Managed Identity\r\nConnect-AzAccount -Identity\r\n \r\n# Optionally filter by Resource Group\r\n$resourceGroup = \"rg-test-shared-fra-sc\" # Or leave empty for all\r\n \r\nif ($resourceGroup) {\r\n    $webApps = Get-AzWebApp -ResourceGroupName $resourceGroup\r\n} else {\r\n    $webApps = Get-AzWebApp\r\n}\r\n \r\nforeach ($app in $webApps) {\r\n    Write-Output \"Stopping App Service: $($app.Name)\"\r\n    Stop-AzWebApp -Name $app.Name -ResourceGroupName $app.ResourceGroup\r\n}"
  description              = "To stop test env"
  location                 = "eastus"
  log_activity_trace_level = 9
  log_progress             = false
  log_verbose              = false
  name                     = "Test-env"
  resource_group_name      = "amedeusnevio_rg"
  runbook_type             = "PowerShell72"
  tags = {
    environment = "test"
  }
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_automation_runbook" "res-515" {
  automation_account_name = "amedeusnevio-Automation"
  content                 = "# Authenticate with Azure using Managed Identity\r\nConnect-AzAccount -Identity\r\n \r\n# Optionally filter by Resource Group\r\n$resourceGroup = \"amedeusnevio_rg\" # Or leave empty for all\r\n \r\nif ($resourceGroup) {\r\n    $webApps = Get-AzWebApp -ResourceGroupName $resourceGroup\r\n} else {\r\n    $webApps = Get-AzWebApp\r\n}\r\n \r\nforeach ($app in $webApps) {\r\n    Write-Output \"Stopping App Service: $($app.Name)\"\r\n    Stop-AzWebApp -Name $app.Name -ResourceGroupName $app.ResourceGroup\r\n}"
  location                = "eastus"
  log_progress            = false
  log_verbose             = false
  name                    = "sample"
  resource_group_name     = "amedeusnevio_rg"
  runbook_type            = "PowerShell72"
  depends_on = [
    azurerm_automation_account.res-146
  ]
}
resource "azurerm_redis_cache" "res-516" {
  access_keys_authentication_enabled = false
  capacity                           = 1
  family                             = "C"
  location                           = "eastus"
  name                               = "amadeus-rc"
  redis_version                      = "6.0"
  resource_group_name                = "amedeusnevio_rg"
  sku_name                           = "Standard"
  tags = {
    application = "amadeus"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_redis_cache_access_policy" "res-517" {
  name           = "Data Contributor"
  permissions    = "+@all -@dangerous +cluster|info +cluster|nodes +cluster|slots allkeys"
  redis_cache_id = azurerm_redis_cache.res-516.id
}
resource "azurerm_redis_cache_access_policy" "res-518" {
  name           = "Data Owner"
  permissions    = "+@all allkeys"
  redis_cache_id = azurerm_redis_cache.res-516.id
}
resource "azurerm_redis_cache_access_policy" "res-519" {
  name           = "Data Reader"
  permissions    = "+@read +@connection +cluster|info +cluster|nodes +cluster|slots allkeys"
  redis_cache_id = azurerm_redis_cache.res-516.id
}
resource "azurerm_redis_cache_access_policy_assignment" "res-520" {
  access_policy_name = "Data Owner"
  name               = "f883459e-fa95-475d-b011-7c183625e701"
  object_id          = "f883459e-fa95-475d-b011-7c183625e701"
  object_id_alias    = "redis-client-sp"
  redis_cache_id     = azurerm_redis_cache.res-516.id
}
resource "azurerm_ssh_public_key" "res-521" {
  location            = "centralus"
  name                = "nevio_backstage"
  public_key          = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDFOaGnt7JLJtickrO23ZULXFag6REJezv8Cn2qw4ToRgS93p2BnsVHZXEDUZFTkoDKdEWQdno2PlM/hxguzTcIh+43n5QL0haSIXCM4zbWlzFsR3Ib0jmP7hmNZ6kHYX9FC6CuJZ730LYqxxRb9J0COFIQP2NJki+7Ql189rEdUjG95f5APY0FoGOXh60/bRGAbF5FqpGkptB9ihdMMCzOFPjt9P5NNObQtb3k27gquVQH2MmPJyF8eAT1kQ3VbZF5NppymMY0mvMpyCDCIQYDdb80v3iMK9gaSS1Pg4ZLMpoYoMy7kOBpJHpRx88GDBMdoWRuVMfuor0pAcxkuYU9I0dcBSLTUoRbwbEx/CERHs+4qsF1Y4ngTN20AKE8WIMPGIELpCPaV//6WROjOWJWXqr8RX4i+jsCFf+Zo55icS4mQQGEvv/fY3VeGLypW4lA0RH8uRoF2+fzTStz84NYZh1UCJUMoz44JyHGDBfTWaxOd73/fhXFVTgdw//E++0= generated-by-azure"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_windows_virtual_machine" "res-522" {
  admin_password        = "ignored-as-imported"
  admin_username        = "amadeus"
  hotpatching_enabled   = true
  location              = "centralus"
  name                  = "UICodeBaseGeneration"
  network_interface_ids = [azurerm_network_interface.res-1182.id]
  patch_mode            = "AutomaticByPlatform"
  reboot_setting        = "IfRequired"
  resource_group_name   = "amedeusnevio_rg"
  secure_boot_enabled   = true
  size                  = "Standard_B2ls_v2"
  tags = {
    environment = "development"
  }
  vtpm_enabled = true
  zone         = "1"
  additional_capabilities {
  }
  boot_diagnostics {
  }
  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "StandardSSD_LRS"
  }
  source_image_reference {
    offer     = "WindowsServer"
    publisher = "MicrosoftWindowsServer"
    sku       = "2022-datacenter-azure-edition-hotpatch"
    version   = "latest"
  }
}
resource "azurerm_linux_virtual_machine" "res-523" {
  admin_password                  = "ignored-as-imported"
  admin_username                  = "amadeus"
  disable_password_authentication = false
  location                        = "centralus"
  name                            = "amadeus-vm-strapi.io"
  network_interface_ids           = [azurerm_network_interface.res-1168.id]
  patch_mode                      = "AutomaticByPlatform"
  reboot_setting                  = "IfRequired"
  resource_group_name             = "amedeusnevio_rg"
  size                            = "Standard_B2als_v2"
  zone                            = "3"
  additional_capabilities {
  }
  boot_diagnostics {
  }
  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }
  source_image_reference {
    offer     = "0001-com-ubuntu-server-jammy"
    publisher = "canonical"
    sku       = "22_04-lts-gen2"
    version   = "latest"
  }
}
resource "azurerm_linux_virtual_machine" "res-524" {
  admin_password                  = "ignored-as-imported"
  admin_username                  = "amedeus"
  disable_password_authentication = false
  location                        = "centralus"
  name                            = "amedeus-vm"
  network_interface_ids           = [azurerm_network_interface.res-1172.id, azurerm_network_interface.res-1180.id]
  patch_mode                      = "AutomaticByPlatform"
  reboot_setting                  = "IfRequired"
  resource_group_name             = "amedeusnevio_rg"
  secure_boot_enabled             = true
  size                            = "Standard_D2ls_v5"
  vtpm_enabled                    = true
  zone                            = "1"
  additional_capabilities {
  }
  boot_diagnostics {
  }
  identity {
    type = "SystemAssigned"
  }
  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "StandardSSD_LRS"
  }
  source_image_reference {
    offer     = "0001-com-ubuntu-server-jammy"
    publisher = "canonical"
    sku       = "22_04-lts-gen2"
    version   = "latest"
  }
}
resource "azurerm_linux_virtual_machine" "res-525" {
  admin_password                  = "ignored-as-imported"
  admin_username                  = "amedeus"
  disable_password_authentication = false
  location                        = "centralus"
  name                            = "amedeus-vm-backstage"
  network_interface_ids           = [azurerm_network_interface.res-1170.id, azurerm_network_interface.res-1176.id]
  patch_mode                      = "AutomaticByPlatform"
  reboot_setting                  = "IfRequired"
  resource_group_name             = "amedeusnevio_rg"
  size                            = "Standard_D2s_v3"
  zone                            = "1"
  additional_capabilities {
  }
  boot_diagnostics {
  }
  identity {
    type = "SystemAssigned"
  }
  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "StandardSSD_LRS"
  }
  source_image_reference {
    offer     = "0001-com-ubuntu-server-jammy"
    publisher = "canonical"
    sku       = "22_04-lts-gen2"
    version   = "latest"
  }
}
resource "azurerm_virtual_machine_extension" "res-526" {
  auto_upgrade_minor_version = true
  name                       = "AADSSHLoginForLinux"
  publisher                  = "Microsoft.Azure.ActiveDirectory"
  type                       = "AADSSHLoginForLinux"
  type_handler_version       = "1.0"
  virtual_machine_id         = azurerm_linux_virtual_machine.res-525.id
}
resource "azurerm_virtual_machine_extension" "res-527" {
  auto_upgrade_minor_version = true
  name                       = "enablevmAccess"
  publisher                  = "Microsoft.OSTCExtensions"
  type                       = "VMAccessForLinux"
  type_handler_version       = "1.5"
  virtual_machine_id         = azurerm_linux_virtual_machine.res-525.id
}
resource "azurerm_virtual_machine_extension" "res-528" {
  auto_upgrade_minor_version = true
  name                       = "AADSSHLoginForLinux"
  publisher                  = "Microsoft.Azure.ActiveDirectory"
  type                       = "AADSSHLoginForLinux"
  type_handler_version       = "1.0"
  virtual_machine_id         = azurerm_linux_virtual_machine.res-524.id
}
resource "azurerm_linux_virtual_machine" "res-529" {
  admin_password                  = "ignored-as-imported"
  admin_username                  = "amedeus"
  disable_password_authentication = false
  location                        = "eastus"
  name                            = "postgresdb"
  network_interface_ids           = [azurerm_network_interface.res-1178.id]
  resource_group_name             = "amedeusnevio_rg"
  secure_boot_enabled             = true
  size                            = "Standard_B2ats_v2"
  vtpm_enabled                    = true
  zone                            = "3"
  additional_capabilities {
  }
  boot_diagnostics {
  }
  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "StandardSSD_LRS"
  }
  source_image_reference {
    offer     = "ubuntu-24_04-lts"
    publisher = "canonical"
    sku       = "server"
    version   = "latest"
  }
}
resource "azurerm_mysql_flexible_server" "res-530" {
  location            = "centralus"
  name                = "nevioscuisqldba"
  resource_group_name = "amedeusnevio_rg"
  tags = {
    application = "amadeus"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_mysql_flexible_server_firewall_rule" "res-532" {
  end_ip_address      = "0.0.0.0"
  name                = "AllowAllAzureServicesAndResourcesWithinAzureIps_2025-8-4_17-54-43"
  resource_group_name = "amedeusnevio_rg"
  server_name         = "nevioscuisqldba"
  start_ip_address    = "0.0.0.0"
  depends_on = [
    azurerm_mysql_flexible_server.res-530
  ]
}
resource "azurerm_mysql_flexible_server_firewall_rule" "res-533" {
  end_ip_address      = "0.0.0.0"
  name                = "AllowAllAzureServicesAndResourcesWithinAzureIps_2025-8-4_17-55-46"
  resource_group_name = "amedeusnevio_rg"
  server_name         = "nevioscuisqldba"
  start_ip_address    = "0.0.0.0"
  depends_on = [
    azurerm_mysql_flexible_server.res-530
  ]
}
resource "azurerm_mysql_flexible_server_firewall_rule" "res-534" {
  end_ip_address      = "255.255.255.255"
  name                = "AllowAll_2025-5-6_12-28-29"
  resource_group_name = "amedeusnevio_rg"
  server_name         = "nevioscuisqldba"
  start_ip_address    = "0.0.0.0"
  depends_on = [
    azurerm_mysql_flexible_server.res-530
  ]
}
resource "azurerm_mysql_flexible_server_firewall_rule" "res-535" {
  end_ip_address      = "255.255.255.255"
  name                = "Grafana-Access"
  resource_group_name = "amedeusnevio_rg"
  server_name         = "nevioscuisqldba"
  start_ip_address    = "0.0.0.0"
  depends_on = [
    azurerm_mysql_flexible_server.res-530
  ]
}
resource "azurerm_postgresql_flexible_server" "res-536" {
  location            = "germanywestcentral"
  name                = "neviodb"
  resource_group_name = "amedeusnevio_rg"
  tags = {
    environment = "dev"
  }
  zone = "1"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_postgresql_flexible_server_firewall_rule" "res-541" {
  end_ip_address   = "255.255.255.255"
  name             = "AllowALL"
  server_id        = azurerm_postgresql_flexible_server.res-536.id
  start_ip_address = "0.0.0.0"
}
resource "azurerm_postgresql_flexible_server" "res-543" {
  location            = "eastus"
  name                = "nevioscdb"
  resource_group_name = "amedeusnevio_rg"
  tags = {
    application = "amadeus"
  }
  zone = "2"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_postgresql_flexible_server_configuration" "res-552" {
  name      = "DateStyle"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "ISO, MDY"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-553" {
  name      = "IntervalStyle"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "postgres"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-554" {
  name      = "TimeZone"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "UTC"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-555" {
  name      = "age.enable_containment"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-556" {
  name      = "allow_in_place_tablespaces"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-557" {
  name      = "allow_system_table_mods"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-558" {
  name      = "anon.algorithm"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "sha256"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-559" {
  name      = "anon.k_anonymity_provider"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "k_anonymity"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-560" {
  name      = "anon.masking_policies"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "anon"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-561" {
  name      = "anon.maskschema"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "mask"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-562" {
  name      = "anon.privacy_by_default"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-563" {
  name      = "anon.restrict_to_trusted_schemas"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-564" {
  name      = "anon.salt"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-565" {
  name      = "anon.sourceschema"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "public"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-566" {
  name      = "anon.strict_mode"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-567" {
  name      = "anon.transparent_dynamic_masking"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-568" {
  name      = "application_name"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-569" {
  name      = "archive_cleanup_command"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-570" {
  name      = "archive_command"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "BlobLogUpload.sh %f %p"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-571" {
  name      = "archive_library"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-572" {
  name      = "archive_mode"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "always"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-573" {
  name      = "archive_timeout"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "300"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-574" {
  name      = "array_nulls"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-575" {
  name      = "authentication_timeout"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "30"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-576" {
  name      = "auto_explain.log_analyze"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-577" {
  name      = "auto_explain.log_buffers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-578" {
  name      = "auto_explain.log_format"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "text"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-579" {
  name      = "auto_explain.log_level"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "log"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-580" {
  name      = "auto_explain.log_min_duration"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "-1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-581" {
  name      = "auto_explain.log_nested_statements"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-582" {
  name      = "auto_explain.log_parameter_max_length"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "-1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-583" {
  name      = "auto_explain.log_settings"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-584" {
  name      = "auto_explain.log_timing"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-585" {
  name      = "auto_explain.log_triggers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-586" {
  name      = "auto_explain.log_verbose"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-587" {
  name      = "auto_explain.log_wal"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-588" {
  name      = "auto_explain.sample_rate"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1.0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-589" {
  name      = "autovacuum"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-590" {
  name      = "autovacuum_analyze_scale_factor"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0.1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-591" {
  name      = "autovacuum_analyze_threshold"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "50"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-592" {
  name      = "autovacuum_freeze_max_age"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "200000000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-593" {
  name      = "autovacuum_max_workers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "3"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-594" {
  name      = "autovacuum_multixact_freeze_max_age"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "400000000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-595" {
  name      = "autovacuum_naptime"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "60"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-596" {
  name      = "autovacuum_vacuum_cost_delay"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "2"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-597" {
  name      = "autovacuum_vacuum_cost_limit"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "-1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-598" {
  name      = "autovacuum_vacuum_insert_scale_factor"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0.2"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-599" {
  name      = "autovacuum_vacuum_insert_threshold"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-600" {
  name      = "autovacuum_vacuum_scale_factor"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0.2"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-601" {
  name      = "autovacuum_vacuum_threshold"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "50"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-602" {
  name      = "autovacuum_work_mem"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "-1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-603" {
  name      = "azure.accepted_password_auth_method"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "md5,scram-sha-256"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-604" {
  name      = "azure.enable_temp_tablespaces_on_local_ssd"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-605" {
  name      = "azure.extensions"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-606" {
  name      = "azure.migration_copy_with_binary"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-607" {
  name      = "azure.migration_skip_analyze"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-608" {
  name      = "azure.migration_skip_extensions"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-609" {
  name      = "azure.migration_skip_large_objects"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-610" {
  name      = "azure.migration_skip_role_user"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-611" {
  name      = "azure.migration_table_split_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "20480"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-612" {
  name      = "azure.service_principal_id"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-613" {
  name      = "azure.service_principal_tenant_id"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-614" {
  name      = "azure.single_to_flex_migration"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-615" {
  name      = "azure_cdc.change_batch_buffer_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "16"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-616" {
  name      = "azure_cdc.change_batch_export_timeout"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "30"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-617" {
  name      = "azure_cdc.max_fabric_mirrors"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "3"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-618" {
  name      = "azure_cdc.max_snapshot_workers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "3"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-619" {
  name      = "azure_cdc.onelake_buffer_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "100"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-620" {
  name      = "azure_cdc.parquet_compression"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "zstd"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-621" {
  name      = "azure_cdc.snapshot_buffer_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-622" {
  name      = "azure_cdc.snapshot_export_timeout"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "180"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-623" {
  name      = "azure_storage.allow_network_access"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-624" {
  name      = "azure_storage.blob_block_size_mb"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "128"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-625" {
  name      = "azure_storage.log_level"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "log"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-626" {
  name      = "azure_storage.public_account_access"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-627" {
  name      = "backend_flush_after"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "256"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-628" {
  name      = "backslash_quote"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "safe_encoding"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-629" {
  name      = "backtrace_functions"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-630" {
  name      = "bgwriter_delay"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "20"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-631" {
  name      = "bgwriter_flush_after"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "64"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-632" {
  name      = "bgwriter_lru_maxpages"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "100"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-633" {
  name      = "bgwriter_lru_multiplier"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "2"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-634" {
  name      = "block_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "8192"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-635" {
  name      = "bonjour"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-636" {
  name      = "bonjour_name"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-637" {
  name      = "bytea_output"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "hex"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-638" {
  name      = "check_function_bodies"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-639" {
  name      = "checkpoint_completion_target"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0.9"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-640" {
  name      = "checkpoint_flush_after"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "32"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-641" {
  name      = "checkpoint_timeout"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "600"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-642" {
  name      = "checkpoint_warning"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "30"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-643" {
  name      = "client_connection_check_interval"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-644" {
  name      = "client_encoding"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "UTF8"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-645" {
  name      = "client_min_messages"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "notice"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-646" {
  name      = "cluster_name"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-647" {
  name      = "commit_delay"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-648" {
  name      = "commit_siblings"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "5"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-649" {
  name      = "compute_query_id"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "auto"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-650" {
  name      = "config_file"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "/datadrive/pg/data/postgresql.conf"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-651" {
  name      = "connection_throttle.bucket_limit"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "2000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-652" {
  name      = "connection_throttle.enable"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-653" {
  name      = "connection_throttle.factor_bias"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0.8"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-654" {
  name      = "connection_throttle.hash_entries_max"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "500"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-655" {
  name      = "connection_throttle.reset_time"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "120"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-656" {
  name      = "connection_throttle.restore_factor"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "2"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-657" {
  name      = "connection_throttle.update_time"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "20"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-658" {
  name      = "constraint_exclusion"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "partition"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-659" {
  name      = "cpu_index_tuple_cost"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0.005"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-660" {
  name      = "cpu_operator_cost"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0.0025"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-661" {
  name      = "cpu_tuple_cost"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0.01"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-662" {
  name      = "createrole_self_grant"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-663" {
  name      = "credcheck.auth_delay_ms"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-664" {
  name      = "credcheck.auth_failure_cache_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1024"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-665" {
  name      = "credcheck.encrypted_password_allowed"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-666" {
  name      = "credcheck.history_max_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "65535"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-667" {
  name      = "credcheck.max_auth_failure"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-668" {
  name      = "credcheck.no_password_logging"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-669" {
  name      = "credcheck.password_contain"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-670" {
  name      = "credcheck.password_contain_username"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-671" {
  name      = "credcheck.password_ignore_case"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-672" {
  name      = "credcheck.password_min_digit"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-673" {
  name      = "credcheck.password_min_length"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-674" {
  name      = "credcheck.password_min_lower"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-675" {
  name      = "credcheck.password_min_repeat"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-676" {
  name      = "credcheck.password_min_special"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-677" {
  name      = "credcheck.password_min_upper"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-678" {
  name      = "credcheck.password_not_contain"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-679" {
  name      = "credcheck.password_reuse_history"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-680" {
  name      = "credcheck.password_reuse_interval"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-681" {
  name      = "credcheck.password_valid_max"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-682" {
  name      = "credcheck.password_valid_until"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-683" {
  name      = "credcheck.reset_superuser"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-684" {
  name      = "credcheck.username_contain"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-685" {
  name      = "credcheck.username_contain_password"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-686" {
  name      = "credcheck.username_ignore_case"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-687" {
  name      = "credcheck.username_min_digit"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-688" {
  name      = "credcheck.username_min_length"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-689" {
  name      = "credcheck.username_min_lower"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-690" {
  name      = "credcheck.username_min_repeat"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-691" {
  name      = "credcheck.username_min_special"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-692" {
  name      = "credcheck.username_min_upper"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-693" {
  name      = "credcheck.username_not_contain"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-694" {
  name      = "credcheck.whitelist"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-695" {
  name      = "credcheck.whitelist_auth_failure"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-696" {
  name      = "cron.database_name"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "postgres"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-697" {
  name      = "cron.enable_superuser_jobs"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-698" {
  name      = "cron.host"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "/tmp"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-699" {
  name      = "cron.launch_active_jobs"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-700" {
  name      = "cron.log_min_messages"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "warning"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-701" {
  name      = "cron.log_run"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-702" {
  name      = "cron.log_statement"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-703" {
  name      = "cron.max_running_jobs"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "32"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-704" {
  name      = "cron.timezone"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "GMT"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-705" {
  name      = "cron.use_background_workers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-706" {
  name      = "cursor_tuple_fraction"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0.1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-707" {
  name      = "data_checksums"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-708" {
  name      = "data_directory"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "/datadrive/pg/data"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-709" {
  name      = "data_directory_mode"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0700"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-710" {
  name      = "data_sync_retry"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-711" {
  name      = "db_user_namespace"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-712" {
  name      = "deadlock_timeout"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-713" {
  name      = "debug_assertions"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-714" {
  name      = "debug_discard_caches"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-715" {
  name      = "debug_io_direct"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-716" {
  name      = "debug_logical_replication_streaming"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "buffered"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-717" {
  name      = "debug_parallel_query"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-718" {
  name      = "debug_pretty_print"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-719" {
  name      = "debug_print_parse"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-720" {
  name      = "debug_print_plan"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-721" {
  name      = "debug_print_rewritten"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-722" {
  name      = "default_statistics_target"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "100"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-723" {
  name      = "default_table_access_method"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "heap"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-724" {
  name      = "default_tablespace"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-725" {
  name      = "default_text_search_config"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "pg_catalog.english"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-726" {
  name      = "default_toast_compression"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "pglz"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-727" {
  name      = "default_transaction_deferrable"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-728" {
  name      = "default_transaction_isolation"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "read committed"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-729" {
  name      = "default_transaction_read_only"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-730" {
  name      = "duckdb.allow_community_extensions"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-731" {
  name      = "duckdb.allow_unsigned_extensions"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-732" {
  name      = "duckdb.autoinstall_known_extensions"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-733" {
  name      = "duckdb.autoload_known_extensions"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-734" {
  name      = "duckdb.disabled_filesystems"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "LocalFileSystem"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-735" {
  name      = "duckdb.enable_external_access"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-736" {
  name      = "duckdb.force_execution"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-737" {
  name      = "duckdb.max_memory"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1024"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-738" {
  name      = "duckdb.max_workers_per_postgres_scan"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "2"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-739" {
  name      = "duckdb.memory_limit"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1024"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-740" {
  name      = "duckdb.postgres_role"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "azure_pg_duckdb_admin"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-741" {
  name      = "duckdb.threads"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "-1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-742" {
  name      = "duckdb.worker_threads"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "-1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-743" {
  name      = "dynamic_library_path"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "$libdir"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-744" {
  name      = "dynamic_shared_memory_type"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "posix"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-745" {
  name      = "effective_cache_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "393216"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-746" {
  name      = "effective_io_concurrency"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-747" {
  name      = "enable_async_append"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-748" {
  name      = "enable_bitmapscan"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-749" {
  name      = "enable_gathermerge"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-750" {
  name      = "enable_hashagg"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-751" {
  name      = "enable_hashjoin"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-752" {
  name      = "enable_incremental_sort"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-753" {
  name      = "enable_indexonlyscan"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-754" {
  name      = "enable_indexscan"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-755" {
  name      = "enable_material"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-756" {
  name      = "enable_memoize"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-757" {
  name      = "enable_mergejoin"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-758" {
  name      = "enable_nestloop"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-759" {
  name      = "enable_parallel_append"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-760" {
  name      = "enable_parallel_hash"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-761" {
  name      = "enable_partition_pruning"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-762" {
  name      = "enable_partitionwise_aggregate"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-763" {
  name      = "enable_partitionwise_join"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-764" {
  name      = "enable_presorted_aggregate"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-765" {
  name      = "enable_seqscan"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-766" {
  name      = "enable_sort"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-767" {
  name      = "enable_tidscan"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-768" {
  name      = "escape_string_warning"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-769" {
  name      = "event_source"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "PostgreSQL"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-770" {
  name      = "exit_on_error"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-771" {
  name      = "external_pid_file"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-772" {
  name      = "extra_float_digits"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-773" {
  name      = "from_collapse_limit"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "8"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-774" {
  name      = "fsync"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-775" {
  name      = "full_page_writes"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-776" {
  name      = "geqo"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-777" {
  name      = "geqo_effort"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "5"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-778" {
  name      = "geqo_generations"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-779" {
  name      = "geqo_pool_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-780" {
  name      = "geqo_seed"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-781" {
  name      = "geqo_selection_bias"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "2"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-782" {
  name      = "geqo_threshold"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "12"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-783" {
  name      = "gin_fuzzy_search_limit"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-784" {
  name      = "gin_pending_list_limit"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "4096"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-785" {
  name      = "gss_accept_delegation"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-786" {
  name      = "hash_mem_multiplier"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "2"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-787" {
  name      = "hba_file"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "/datadrive/pg/data/pg_hba.conf"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-788" {
  name      = "hot_standby"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-789" {
  name      = "hot_standby_feedback"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-790" {
  name      = "huge_page_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-791" {
  name      = "huge_pages"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "try"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-792" {
  name      = "icu_validation_level"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "warning"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-793" {
  name      = "ident_file"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "/datadrive/pg/data/pg_ident.conf"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-794" {
  name      = "idle_in_transaction_session_timeout"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-795" {
  name      = "idle_session_timeout"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-796" {
  name      = "ignore_checksum_failure"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-797" {
  name      = "ignore_invalid_pages"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-798" {
  name      = "ignore_system_indexes"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-799" {
  name      = "in_hot_standby"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-800" {
  name      = "integer_datetimes"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-801" {
  name      = "intelligent_tuning"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-802" {
  name      = "intelligent_tuning.metric_targets"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "none"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-803" {
  name      = "jit"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-804" {
  name      = "jit_above_cost"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "100000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-805" {
  name      = "jit_debugging_support"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-806" {
  name      = "jit_dump_bitcode"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-807" {
  name      = "jit_expressions"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-808" {
  name      = "jit_inline_above_cost"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "500000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-809" {
  name      = "jit_optimize_above_cost"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "500000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-810" {
  name      = "jit_profiling_support"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-811" {
  name      = "jit_provider"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "llvmjit"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-812" {
  name      = "jit_tuple_deforming"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-813" {
  name      = "join_collapse_limit"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "8"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-814" {
  name      = "krb_caseins_users"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-815" {
  name      = "krb_server_keyfile"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-816" {
  name      = "lc_messages"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "en_US.utf8"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-817" {
  name      = "lc_monetary"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "en_US.utf-8"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-818" {
  name      = "lc_numeric"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "en_US.utf-8"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-819" {
  name      = "lc_time"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "en_US.utf8"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-820" {
  name      = "listen_addresses"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "*"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-821" {
  name      = "lo_compat_privileges"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-822" {
  name      = "local_preload_libraries"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-823" {
  name      = "lock_timeout"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-824" {
  name      = "log_autovacuum_min_duration"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "600000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-825" {
  name      = "log_checkpoints"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-826" {
  name      = "log_connections"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-827" {
  name      = "log_destination"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "stderr"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-828" {
  name      = "log_directory"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "log"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-829" {
  name      = "log_disconnections"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-830" {
  name      = "log_duration"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-831" {
  name      = "log_error_verbosity"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "default"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-832" {
  name      = "log_executor_stats"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-833" {
  name      = "log_file_mode"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0600"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-834" {
  name      = "log_filename"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "postgresql-%Y-%m-%d_%H%M%S.log"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-835" {
  name      = "log_hostname"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-836" {
  name      = "log_line_prefix"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "%t-%c-"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-837" {
  name      = "log_lock_waits"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-838" {
  name      = "log_min_duration_sample"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "-1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-839" {
  name      = "log_min_duration_statement"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "-1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-840" {
  name      = "log_min_error_statement"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "error"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-841" {
  name      = "log_min_messages"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "warning"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-842" {
  name      = "log_parameter_max_length"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "-1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-843" {
  name      = "log_parameter_max_length_on_error"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-844" {
  name      = "log_parser_stats"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-845" {
  name      = "log_planner_stats"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-846" {
  name      = "log_recovery_conflict_waits"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-847" {
  name      = "log_replication_commands"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-848" {
  name      = "log_rotation_age"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "60"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-849" {
  name      = "log_rotation_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "102400"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-850" {
  name      = "log_startup_progress_interval"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "10000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-851" {
  name      = "log_statement"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "none"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-852" {
  name      = "log_statement_sample_rate"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-853" {
  name      = "log_statement_stats"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-854" {
  name      = "log_temp_files"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "-1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-855" {
  name      = "log_timezone"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "UTC"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-856" {
  name      = "log_transaction_sample_rate"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-857" {
  name      = "log_truncate_on_rotation"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-858" {
  name      = "logfiles.download_enable"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-859" {
  name      = "logfiles.retention_days"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "3"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-860" {
  name      = "logging_collector"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-861" {
  name      = "logical_decoding_work_mem"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "65536"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-862" {
  name      = "maintenance_io_concurrency"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "10"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-863" {
  name      = "maintenance_work_mem"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "157696"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-864" {
  name      = "max_connections"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "429"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-865" {
  name      = "max_files_per_process"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-866" {
  name      = "max_function_args"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "100"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-867" {
  name      = "max_identifier_length"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "63"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-868" {
  name      = "max_index_keys"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "32"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-869" {
  name      = "max_locks_per_transaction"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "64"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-870" {
  name      = "max_logical_replication_workers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "4"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-871" {
  name      = "max_parallel_apply_workers_per_subscription"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "2"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-872" {
  name      = "max_parallel_maintenance_workers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "2"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-873" {
  name      = "max_parallel_workers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "8"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-874" {
  name      = "max_parallel_workers_per_gather"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "2"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-875" {
  name      = "max_pred_locks_per_page"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "2"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-876" {
  name      = "max_pred_locks_per_relation"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "-2"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-877" {
  name      = "max_pred_locks_per_transaction"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "64"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-878" {
  name      = "max_prepared_transactions"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-879" {
  name      = "max_replication_slots"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "10"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-880" {
  name      = "max_slot_wal_keep_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "-1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-881" {
  name      = "max_stack_depth"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "2048"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-882" {
  name      = "max_standby_archive_delay"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "30000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-883" {
  name      = "max_standby_streaming_delay"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "30000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-884" {
  name      = "max_sync_workers_per_subscription"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "2"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-885" {
  name      = "max_wal_senders"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "10"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-886" {
  name      = "max_wal_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "4096"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-887" {
  name      = "max_worker_processes"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "8"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-888" {
  name      = "metrics.autovacuum_diagnostics"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-889" {
  name      = "metrics.collector_database_activity"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-890" {
  name      = "metrics.pgbouncer_diagnostics"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-891" {
  name      = "min_dynamic_shared_memory"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-892" {
  name      = "min_parallel_index_scan_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "64"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-893" {
  name      = "min_parallel_table_scan_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1024"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-894" {
  name      = "min_wal_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "80"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-895" {
  name      = "old_snapshot_threshold"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "-1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-896" {
  name      = "parallel_leader_participation"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-897" {
  name      = "parallel_setup_cost"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-898" {
  name      = "parallel_tuple_cost"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0.1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-899" {
  name      = "password_encryption"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "scram-sha-256"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-900" {
  name      = "pg_failover_slots.drop_extra_slots"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-901" {
  name      = "pg_failover_slots.primary_dsn"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-902" {
  name      = "pg_failover_slots.standby_slot_names"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "azure_standby_, wal_replica_"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-903" {
  name      = "pg_failover_slots.standby_slots_min_confirmed"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-904" {
  name      = "pg_failover_slots.synchronize_slot_names"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "name_like:%%"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-905" {
  name      = "pg_failover_slots.version"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1.0.1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-906" {
  name      = "pg_failover_slots.wait_for_inactive_slots"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-907" {
  name      = "pg_hint_plan.debug_print"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-908" {
  name      = "pg_hint_plan.enable_hint"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-909" {
  name      = "pg_hint_plan.enable_hint_table"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-910" {
  name      = "pg_hint_plan.hints_anywhere"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-911" {
  name      = "pg_hint_plan.message_level"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "log"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-912" {
  name      = "pg_hint_plan.parse_messages"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "info"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-913" {
  name      = "pg_partman_bgw.analyze"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-914" {
  name      = "pg_partman_bgw.dbname"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-915" {
  name      = "pg_partman_bgw.interval"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "3600"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-916" {
  name      = "pg_partman_bgw.jobmon"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-917" {
  name      = "pg_partman_bgw.maintenance_wait"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-918" {
  name      = "pg_partman_bgw.role"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-919" {
  name      = "pg_prewarm.autoprewarm"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-920" {
  name      = "pg_prewarm.autoprewarm_interval"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "300"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-921" {
  name      = "pg_qs.interval_length_minutes"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "15"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-922" {
  name      = "pg_qs.is_enabled_fs"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-923" {
  name      = "pg_qs.max_captured_queries"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "500"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-924" {
  name      = "pg_qs.max_plan_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "7500"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-925" {
  name      = "pg_qs.max_query_text_length"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "6000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-926" {
  name      = "pg_qs.parameters_capture_mode"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "capture_parameterless_only"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-927" {
  name      = "pg_qs.query_capture_mode"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "none"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-928" {
  name      = "pg_qs.retention_period_in_days"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "7"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-929" {
  name      = "pg_qs.store_query_plans"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-930" {
  name      = "pg_qs.track_utility"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-931" {
  name      = "pg_stat_statements.max"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "5000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-932" {
  name      = "pg_stat_statements.save"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-933" {
  name      = "pg_stat_statements.track"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "none"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-934" {
  name      = "pg_stat_statements.track_planning"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-935" {
  name      = "pg_stat_statements.track_utility"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-936" {
  name      = "pgaadauth.enable_group_sync"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-937" {
  name      = "pgaudit.log"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "none"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-938" {
  name      = "pgaudit.log_catalog"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-939" {
  name      = "pgaudit.log_client"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-940" {
  name      = "pgaudit.log_level"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "log"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-941" {
  name      = "pgaudit.log_parameter"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-942" {
  name      = "pgaudit.log_parameter_max_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-943" {
  name      = "pgaudit.log_relation"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-944" {
  name      = "pgaudit.log_rows"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-945" {
  name      = "pgaudit.log_statement"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-946" {
  name      = "pgaudit.log_statement_once"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-947" {
  name      = "pgaudit.role"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-948" {
  name      = "pglogical.batch_inserts"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-949" {
  name      = "pglogical.conflict_log_level"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "log"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-950" {
  name      = "pglogical.conflict_resolution"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "apply_remote"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-951" {
  name      = "pglogical.extra_connection_options"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-952" {
  name      = "pglogical.synchronous_commit"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-953" {
  name      = "pglogical.temp_directory"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-954" {
  name      = "pglogical.use_spi"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-955" {
  name      = "pgms_stats.is_enabled_fs"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-956" {
  name      = "pgms_wait_sampling.history_period"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "100"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-957" {
  name      = "pgms_wait_sampling.is_enabled_fs"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-958" {
  name      = "pgms_wait_sampling.query_capture_mode"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "none"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-959" {
  name      = "plan_cache_mode"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "auto"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-960" {
  name      = "port"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "5432"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-961" {
  name      = "post_auth_delay"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-962" {
  name      = "postgis.gdal_enabled_drivers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "DISABLE_ALL"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-963" {
  name      = "pre_auth_delay"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-964" {
  name      = "primary_conninfo"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-965" {
  name      = "primary_slot_name"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-966" {
  name      = "quote_all_identifiers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-967" {
  name      = "random_page_cost"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "2"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-968" {
  name      = "recovery_end_command"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-969" {
  name      = "recovery_init_sync_method"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "fsync"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-970" {
  name      = "recovery_min_apply_delay"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-971" {
  name      = "recovery_prefetch"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "try"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-972" {
  name      = "recovery_target"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-973" {
  name      = "recovery_target_action"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "pause"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-974" {
  name      = "recovery_target_inclusive"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-975" {
  name      = "recovery_target_lsn"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-976" {
  name      = "recovery_target_name"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-977" {
  name      = "recovery_target_time"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-978" {
  name      = "recovery_target_timeline"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "latest"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-979" {
  name      = "recovery_target_xid"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-980" {
  name      = "recursive_worktable_factor"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "10"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-981" {
  name      = "remove_temp_files_after_crash"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-982" {
  name      = "require_secure_transport"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-983" {
  name      = "reserved_connections"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "5"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-984" {
  name      = "restart_after_crash"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-985" {
  name      = "restore_command"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-986" {
  name      = "restrict_nonsystem_relation_kind"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-987" {
  name      = "row_security"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-988" {
  name      = "scram_iterations"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "4096"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-989" {
  name      = "search_path"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "\"$user\", public"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-990" {
  name      = "segment_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "131072"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-991" {
  name      = "send_abort_for_crash"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-992" {
  name      = "send_abort_for_kill"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-993" {
  name      = "seq_page_cost"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-994" {
  name      = "server_encoding"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "UTF8"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-995" {
  name      = "server_version"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "16.10"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-996" {
  name      = "server_version_num"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "160010"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-997" {
  name      = "session_preload_libraries"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-998" {
  name      = "session_replication_role"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "origin"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-999" {
  name      = "shared_buffers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "131072"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1000" {
  name      = "shared_memory_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1121"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1001" {
  name      = "shared_memory_size_in_huge_pages"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "561"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1002" {
  name      = "shared_memory_type"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "mmap"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1003" {
  name      = "shared_preload_libraries"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "pg_cron,pg_stat_statements"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1004" {
  name      = "squeeze.max_xlock_time"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1005" {
  name      = "squeeze.worker_autostart"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1006" {
  name      = "squeeze.worker_role"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1007" {
  name      = "squeeze.workers_per_database"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1008" {
  name      = "ssl"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1009" {
  name      = "ssl_ca_file"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "/datadrive/certs/ca.pem"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1010" {
  name      = "ssl_cert_file"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "/datadrive/certs/cert.pem"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1011" {
  name      = "ssl_ciphers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1012" {
  name      = "ssl_crl_dir"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1013" {
  name      = "ssl_crl_file"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1014" {
  name      = "ssl_dh_params_file"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1015" {
  name      = "ssl_ecdh_curve"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "prime256v1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1016" {
  name      = "ssl_key_file"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "/datadrive/certs/key.pem"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1017" {
  name      = "ssl_library"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "OpenSSL"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1018" {
  name      = "ssl_max_protocol_version"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1019" {
  name      = "ssl_min_protocol_version"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "TLSv1.2"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1020" {
  name      = "ssl_passphrase_command"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1021" {
  name      = "ssl_passphrase_command_supports_reload"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1022" {
  name      = "ssl_prefer_server_ciphers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1023" {
  name      = "standard_conforming_strings"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1024" {
  name      = "statement_timeout"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1025" {
  name      = "stats_fetch_consistency"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "cache"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1026" {
  name      = "superuser_reserved_connections"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "10"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1027" {
  name      = "synchronize_seqscans"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1028" {
  name      = "synchronous_commit"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1029" {
  name      = "synchronous_standby_names"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1030" {
  name      = "syslog_facility"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "local0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1031" {
  name      = "syslog_ident"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "postgres"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1032" {
  name      = "syslog_sequence_numbers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1033" {
  name      = "syslog_split_messages"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1034" {
  name      = "tcp_keepalives_count"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "9"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1035" {
  name      = "tcp_keepalives_idle"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "120"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1036" {
  name      = "tcp_keepalives_interval"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "30"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1037" {
  name      = "tcp_user_timeout"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1038" {
  name      = "temp_buffers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1024"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1039" {
  name      = "temp_file_limit"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "-1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1040" {
  name      = "temp_tablespaces"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1041" {
  name      = "timescaledb.bgw_launcher_poll_time"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "60000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1042" {
  name      = "timescaledb.disable_load"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1043" {
  name      = "timescaledb.max_background_workers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "16"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1044" {
  name      = "timescaledb_osm.disable_load"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1045" {
  name      = "timezone_abbreviations"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "Default"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1046" {
  name      = "trace_notify"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1047" {
  name      = "trace_recovery_messages"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "log"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1048" {
  name      = "trace_sort"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1049" {
  name      = "track_activities"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1050" {
  name      = "track_activity_query_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1024"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1051" {
  name      = "track_commit_timestamp"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1052" {
  name      = "track_counts"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1053" {
  name      = "track_functions"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "none"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1054" {
  name      = "track_io_timing"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1055" {
  name      = "track_wal_io_timing"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1056" {
  name      = "transaction_deferrable"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1057" {
  name      = "transaction_isolation"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "read committed"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1058" {
  name      = "transaction_read_only"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1059" {
  name      = "transform_null_equals"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1060" {
  name      = "unix_socket_directories"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "/tmp,/tmp/tuning_sockets"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1061" {
  name      = "unix_socket_group"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1062" {
  name      = "unix_socket_permissions"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0777"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1063" {
  name      = "update_process_title"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1064" {
  name      = "vacuum_buffer_usage_limit"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "256"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1065" {
  name      = "vacuum_cost_delay"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "0"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1066" {
  name      = "vacuum_cost_limit"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "200"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1067" {
  name      = "vacuum_cost_page_dirty"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "20"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1068" {
  name      = "vacuum_cost_page_hit"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1069" {
  name      = "vacuum_cost_page_miss"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "10"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1070" {
  name      = "vacuum_failsafe_age"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1600000000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1071" {
  name      = "vacuum_freeze_min_age"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "50000000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1072" {
  name      = "vacuum_freeze_table_age"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "150000000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1073" {
  name      = "vacuum_multixact_failsafe_age"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "1600000000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1074" {
  name      = "vacuum_multixact_freeze_min_age"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "5000000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1075" {
  name      = "vacuum_multixact_freeze_table_age"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "150000000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1076" {
  name      = "wal_block_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "8192"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1077" {
  name      = "wal_buffers"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "2048"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1078" {
  name      = "wal_compression"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1079" {
  name      = "wal_consistency_checking"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = ""
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1080" {
  name      = "wal_decode_buffer_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "524288"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1081" {
  name      = "wal_init_zero"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1082" {
  name      = "wal_keep_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "400"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1083" {
  name      = "wal_level"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "replica"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1084" {
  name      = "wal_log_hints"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1085" {
  name      = "wal_receiver_create_temp_slot"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1086" {
  name      = "wal_receiver_status_interval"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "10"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1087" {
  name      = "wal_receiver_timeout"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "60000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1088" {
  name      = "wal_recycle"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "on"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1089" {
  name      = "wal_retrieve_retry_interval"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "5000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1090" {
  name      = "wal_segment_size"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "16777216"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1091" {
  name      = "wal_sender_timeout"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "60000"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1092" {
  name      = "wal_skip_threshold"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "2048"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1093" {
  name      = "wal_sync_method"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "fdatasync"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1094" {
  name      = "wal_writer_delay"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "200"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1095" {
  name      = "wal_writer_flush_after"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "128"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1096" {
  name      = "work_mem"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "4096"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1097" {
  name      = "xmlbinary"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "base64"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1098" {
  name      = "xmloption"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "content"
}
resource "azurerm_postgresql_flexible_server_configuration" "res-1099" {
  name      = "zero_damaged_pages"
  server_id = azurerm_postgresql_flexible_server.res-543.id
  value     = "off"
}
resource "azurerm_postgresql_flexible_server_database" "res-1100" {
  name      = "azure_maintenance"
  server_id = azurerm_postgresql_flexible_server.res-543.id
}
resource "azurerm_postgresql_flexible_server_database" "res-1101" {
  name      = "azure_sys"
  server_id = azurerm_postgresql_flexible_server.res-543.id
}
resource "azurerm_postgresql_flexible_server_database" "res-1102" {
  name      = "backstage-db"
  server_id = azurerm_postgresql_flexible_server.res-543.id
}
resource "azurerm_postgresql_flexible_server_database" "res-1103" {
  name      = "backstage_db_2"
  server_id = azurerm_postgresql_flexible_server.res-543.id
}
resource "azurerm_postgresql_flexible_server_database" "res-1104" {
  name      = "backstage_plugin_auth"
  server_id = azurerm_postgresql_flexible_server.res-543.id
}
resource "azurerm_postgresql_flexible_server_database" "res-1105" {
  name      = "backstage_plugin_coves-dashboard"
  server_id = azurerm_postgresql_flexible_server.res-543.id
}
resource "azurerm_postgresql_flexible_server_database" "res-1106" {
  name      = "coves_db"
  server_id = azurerm_postgresql_flexible_server.res-543.id
}
resource "azurerm_postgresql_flexible_server_database" "res-1107" {
  name      = "postgres"
  server_id = azurerm_postgresql_flexible_server.res-543.id
}
resource "azurerm_postgresql_flexible_server_database" "res-1108" {
  name      = "prisma_migrate_shadow_db_d4ad3bd0-461d-46a5-8d43-4589ef2216fb"
  server_id = azurerm_postgresql_flexible_server.res-543.id
}
resource "azurerm_postgresql_flexible_server_database" "res-1109" {
  name      = "prisma_migrate_shadow_db_eb28a94f-e15a-49d3-b0e2-5718b0f72a1e"
  server_id = azurerm_postgresql_flexible_server.res-543.id
}
resource "azurerm_postgresql_flexible_server_database" "res-1110" {
  name      = "sample"
  server_id = azurerm_postgresql_flexible_server.res-543.id
}
resource "azurerm_postgresql_flexible_server_database" "res-1111" {
  name      = "sample_db"
  server_id = azurerm_postgresql_flexible_server.res-543.id
}
resource "azurerm_postgresql_flexible_server_database" "res-1112" {
  name      = "strapi_db"
  server_id = azurerm_postgresql_flexible_server.res-543.id
}
resource "azurerm_postgresql_flexible_server_database" "res-1113" {
  name      = "test"
  server_id = azurerm_postgresql_flexible_server.res-543.id
}
resource "azurerm_postgresql_flexible_server_database" "res-1114" {
  name      = "testdb"
  server_id = azurerm_postgresql_flexible_server.res-543.id
}
resource "azurerm_postgresql_flexible_server_firewall_rule" "res-1115" {
  end_ip_address   = "255.255.255.255"
  name             = "AllowAll_2025-9-29_15-22-50"
  server_id        = azurerm_postgresql_flexible_server.res-543.id
  start_ip_address = "0.0.0.0"
}
resource "azurerm_dev_test_global_vm_shutdown_schedule" "res-1117" {
  daily_recurrence_time = "1900"
  location              = "centralus"
  tags = {
    environment = "development"
  }
  timezone           = "India Standard Time"
  virtual_machine_id = azurerm_windows_virtual_machine.res-522.id
  notification_settings {
    email   = "m.kumaran3@tcs.com"
    enabled = true
  }
}
resource "azurerm_dev_test_global_vm_shutdown_schedule" "res-1118" {
  daily_recurrence_time = "1900"
  location              = "centralus"
  timezone              = "India Standard Time"
  virtual_machine_id    = azurerm_linux_virtual_machine.res-523.id
  notification_settings {
    email   = "dinesh.sharma9@tcs.com"
    enabled = true
  }
}
resource "azurerm_dev_test_global_vm_shutdown_schedule" "res-1119" {
  daily_recurrence_time = "1900"
  location              = "centralus"
  timezone              = "India Standard Time"
  virtual_machine_id    = azurerm_linux_virtual_machine.res-524.id
  notification_settings {
    email   = "dinesh.sharma9@tcs.com"
    enabled = true
  }
}
resource "azurerm_dev_test_global_vm_shutdown_schedule" "res-1120" {
  daily_recurrence_time = "2000"
  location              = "centralus"
  timezone              = "India Standard Time"
  virtual_machine_id    = azurerm_linux_virtual_machine.res-525.id
  notification_settings {
    email   = "dinesh.sharma9@tcs.com"
    enabled = true
  }
}
resource "azurerm_dev_test_global_vm_shutdown_schedule" "res-1121" {
  daily_recurrence_time = "1900"
  location              = "eastus"
  timezone              = "India Standard Time"
  virtual_machine_id    = azurerm_linux_virtual_machine.res-529.id
  notification_settings {
    email   = "dinesh.sharma9@tcs.com"
    enabled = true
  }
}
resource "azurerm_user_assigned_identity" "res-1133" {
  location            = "eastus"
  name                = "Amadeus"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_federated_identity_credential" "res-1134" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "NevioServiceCenter-SearchPanelAPI-8d11"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SearchPanel_API:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1135" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "SC-API-AppConfig-API"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-API-App-Config:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1136" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "SC-API-Baggage-Policies"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-API-Baggage-Policies:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1137" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "SC-API-Checkout-Confirm"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-API-Checkout-Confirm:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1138" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "SC-API-Checkout-Initiate"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-API-Checkout-Initiate:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1139" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "SC-API-Checkout-Passengers"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-API-Checkout-Passengers:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1140" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "SC-API-Checkout-Update"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-API-Checkout-Update:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1141" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "SC-API-FareConditions"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-API-Fare-Condition:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1142" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "SC-API-Order-Retrieve"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-API-Order-Retrieve:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1143" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "SC-API-Payment"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-API-Payment:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1144" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "SC-API-RolePermissions"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-API-RolePermissions:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1145" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "SC-API-SearchPanel"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-API-SearchPanel:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1146" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "SC-API-Seat-Map"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-API-Seat-Map:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1147" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "SC-UI-ServiceCenterMain"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-UI-ServiceCenterMain:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1148" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "SC-UI-Shell-SeviceCenter"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-UI-Shell-SeviceCenter:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1149" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "SC-test-infra-platform"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-test-infra-platform:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1150" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "SearchPanel-cred"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-API-SearchPanel:environment:Production"
}
resource "azurerm_federated_identity_credential" "res-1151" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "Shop-Offer"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-API-Flight-Search:ref:refs/heads/main"
}
resource "azurerm_federated_identity_credential" "res-1152" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "func-rbac-dev-eus"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/RolePermissionsAPI:environment:Production"
}
resource "azurerm_federated_identity_credential" "res-1153" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "sc-api-token"
  parent_id           = azurerm_user_assigned_identity.res-1133.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/SC-API-Token:environment:Production"
}
resource "azurerm_user_assigned_identity" "res-1154" {
  location            = "eastus"
  name                = "NextjsDemo-id-917c"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_federated_identity_credential" "res-1155" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "cylq6ygx2rfdc"
  parent_id           = azurerm_user_assigned_identity.res-1154.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/NextjsSample:environment:Production"
}
resource "azurerm_user_assigned_identity" "res-1156" {
  location            = "eastus"
  name                = "testing-function-id-94c8"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_federated_identity_credential" "res-1157" {
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://token.actions.githubusercontent.com"
  name                = "NevioServiceCenter-Shop-Offer-b5b5"
  parent_id           = azurerm_user_assigned_identity.res-1156.id
  resource_group_name = "amedeusnevio_rg"
  subject             = "repo:NevioServiceCenter/Shop-Offer:ref:refs/heads/main"
}
resource "azurerm_bastion_host" "res-1158" {
  location            = "centralus"
  name                = "amedeus-test-vnet-bastion"
  resource_group_name = "amedeusnevio_rg"
  sku                 = "Developer"
  virtual_network_id  = azurerm_virtual_network.res-1296.id
}
resource "azurerm_dns_zone" "res-1159" {
  name                = "amadeusnevio.com"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_dns_a_record" "res-1160" {
  name                = "backstage"
  records             = ["20.118.202.38"]
  resource_group_name = "amedeusnevio_rg"
  ttl                 = 3600
  zone_name           = "amadeusnevio.com"
  depends_on = [
    azurerm_dns_zone.res-1159
  ]
}
resource "azurerm_dns_a_record" "res-1161" {
  name                = "sc-idp"
  records             = ["20.118.202.38"]
  resource_group_name = "amedeusnevio_rg"
  ttl                 = 3600
  zone_name           = "amadeusnevio.com"
  depends_on = [
    azurerm_dns_zone.res-1159
  ]
}
resource "azurerm_dns_a_record" "res-1162" {
  name                = "se-backstage"
  records             = ["20.118.202.38"]
  resource_group_name = "amedeusnevio_rg"
  ttl                 = 3600
  zone_name           = "amadeusnevio.com"
  depends_on = [
    azurerm_dns_zone.res-1159
  ]
}
resource "azurerm_dns_ns_record" "res-1163" {
  name                = "@"
  records             = ["ns1-05.azure-dns.com.", "ns2-05.azure-dns.net.", "ns3-05.azure-dns.org.", "ns4-05.azure-dns.info."]
  resource_group_name = "amedeusnevio_rg"
  ttl                 = 172800
  zone_name           = "amadeusnevio.com"
  depends_on = [
    azurerm_dns_zone.res-1159
  ]
}
resource "azurerm_network_interface" "res-1165" {
  location            = "eastus"
  name                = "Backstage-DB"
  resource_group_name = "amedeusnevio_rg"
  tags = {
    application = "amadeus"
  }
  ip_configuration {
    name                          = "Ipv4config"
    private_ip_address_allocation = "Dynamic"
    subnet_id                     = azurerm_subnet.res-1291.id
  }
}
resource "azurerm_network_interface" "res-1166" {
  accelerated_networking_enabled = true
  location                       = "centralus"
  name                           = "amadeus-vm-backstage176_z1"
  resource_group_name            = "amedeusnevio_rg"
  ip_configuration {
    name                          = "ipconfig1"
    private_ip_address_allocation = "Dynamic"
    public_ip_address_id          = azurerm_public_ip.res-1271.id
    subnet_id                     = azurerm_subnet.res-1298.id
  }
}
resource "azurerm_network_interface_security_group_association" "res-1167" {
  network_interface_id      = azurerm_network_interface.res-1166.id
  network_security_group_id = azurerm_network_security_group.res-1205.id
}
resource "azurerm_network_interface" "res-1168" {
  accelerated_networking_enabled = true
  location                       = "centralus"
  name                           = "amadeus-vm-strapi.io518-8ed40b8c"
  resource_group_name            = "amedeusnevio_rg"
  ip_configuration {
    name                          = "amadeus-vm-strapi.io518-defaultIpConfiguration"
    private_ip_address_allocation = "Dynamic"
    public_ip_address_id          = azurerm_public_ip.res-1272.id
    subnet_id                     = azurerm_subnet.res-1298.id
  }
}
resource "azurerm_network_interface_security_group_association" "res-1169" {
  network_interface_id      = azurerm_network_interface.res-1168.id
  network_security_group_id = azurerm_network_security_group.res-1201.id
}
resource "azurerm_network_interface" "res-1170" {
  accelerated_networking_enabled = true
  location                       = "centralus"
  name                           = "amedeus-vm-backstage163_z1"
  resource_group_name            = "amedeusnevio_rg"
  ip_configuration {
    name                          = "ipconfig1"
    private_ip_address_allocation = "Dynamic"
    public_ip_address_id          = azurerm_public_ip.res-1280.id
    subnet_id                     = azurerm_subnet.res-1298.id
  }
}
resource "azurerm_network_interface_security_group_association" "res-1171" {
  network_interface_id      = azurerm_network_interface.res-1170.id
  network_security_group_id = azurerm_network_security_group.res-1232.id
}
resource "azurerm_network_interface" "res-1172" {
  accelerated_networking_enabled = true
  location                       = "centralus"
  name                           = "amedeus-vm747_z1"
  resource_group_name            = "amedeusnevio_rg"
  ip_configuration {
    name                          = "ipconfig1"
    private_ip_address_allocation = "Dynamic"
    public_ip_address_id          = azurerm_public_ip.res-1279.id
    subnet_id                     = azurerm_subnet.res-1298.id
  }
}
resource "azurerm_network_interface_security_group_association" "res-1173" {
  network_interface_id      = azurerm_network_interface.res-1172.id
  network_security_group_id = azurerm_network_security_group.res-1219.id
}
resource "azurerm_network_interface" "res-1174" {
  accelerated_networking_enabled = true
  location                       = "centralus"
  name                           = "amedeus249_z1"
  resource_group_name            = "amedeusnevio_rg"
  ip_configuration {
    name                          = "ipconfig1"
    private_ip_address_allocation = "Dynamic"
    public_ip_address_id          = azurerm_public_ip.res-1273.id
    subnet_id                     = azurerm_subnet.res-1298.id
  }
}
resource "azurerm_network_interface_security_group_association" "res-1175" {
  network_interface_id      = azurerm_network_interface.res-1174.id
  network_security_group_id = azurerm_network_security_group.res-1209.id
}
resource "azurerm_network_interface" "res-1176" {
  location            = "centralus"
  name                = "backstage-vm"
  resource_group_name = "amedeusnevio_rg"
  ip_configuration {
    name                          = "ipconfig1"
    private_ip_address_allocation = "Dynamic"
    subnet_id                     = azurerm_subnet.res-1298.id
  }
}
resource "azurerm_network_interface_security_group_association" "res-1177" {
  network_interface_id      = azurerm_network_interface.res-1176.id
  network_security_group_id = azurerm_network_security_group.res-1249.id
}
resource "azurerm_network_interface" "res-1178" {
  accelerated_networking_enabled = true
  location                       = "eastus"
  name                           = "postgresdb473_z3"
  resource_group_name            = "amedeusnevio_rg"
  ip_configuration {
    name                          = "ipconfig1"
    private_ip_address_allocation = "Dynamic"
    public_ip_address_id          = azurerm_public_ip.res-1281.id
    subnet_id                     = azurerm_subnet.res-1291.id
  }
}
resource "azurerm_network_interface_security_group_association" "res-1179" {
  network_interface_id      = azurerm_network_interface.res-1178.id
  network_security_group_id = azurerm_network_security_group.res-1255.id
}
resource "azurerm_network_interface" "res-1180" {
  location            = "centralus"
  name                = "sonarqube-vm"
  resource_group_name = "amedeusnevio_rg"
  ip_configuration {
    name                          = "ipconfig1"
    private_ip_address_allocation = "Dynamic"
    subnet_id                     = azurerm_subnet.res-1298.id
  }
  ip_configuration {
    name                          = "sonar"
    private_ip_address_allocation = "Dynamic"
    subnet_id                     = azurerm_subnet.res-1298.id
  }
}
resource "azurerm_network_interface_security_group_association" "res-1181" {
  network_interface_id      = azurerm_network_interface.res-1180.id
  network_security_group_id = azurerm_network_security_group.res-1250.id
}
resource "azurerm_network_interface" "res-1182" {
  accelerated_networking_enabled = true
  location                       = "centralus"
  name                           = "uicodebasegeneration295_z1"
  resource_group_name            = "amedeusnevio_rg"
  tags = {
    environment = "development"
  }
  ip_configuration {
    name                          = "ipconfig1"
    private_ip_address_allocation = "Static"
    public_ip_address_id          = azurerm_public_ip.res-1269.id
    subnet_id                     = azurerm_subnet.res-1303.id
  }
}
resource "azurerm_network_interface_security_group_association" "res-1183" {
  network_interface_id      = azurerm_network_interface.res-1182.id
  network_security_group_id = azurerm_network_security_group.res-1197.id
}
resource "azurerm_network_interface" "res-1184" {
  accelerated_networking_enabled = true
  location                       = "centralus"
  name                           = "uicodegeneration130_z1"
  resource_group_name            = "amedeusnevio_rg"
  tags = {
    environment = "development"
  }
  ip_configuration {
    name                          = "ipconfig1"
    private_ip_address_allocation = "Dynamic"
    public_ip_address_id          = azurerm_public_ip.res-1270.id
    subnet_id                     = azurerm_subnet.res-1304.id
  }
}
resource "azurerm_network_interface_security_group_association" "res-1185" {
  network_interface_id      = azurerm_network_interface.res-1184.id
  network_security_group_id = azurerm_network_security_group.res-1199.id
}
resource "azurerm_network_security_group" "res-1186" {
  location            = "eastus"
  name                = "APIM-NSG"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_network_security_rule" "res-1187" {
  access                      = "Allow"
  destination_address_prefix  = "10.2.2.0/24"
  destination_port_range      = "*"
  direction                   = "Outbound"
  name                        = "APIMToFuncAppAnyOutbound"
  network_security_group_name = "APIM-NSG"
  priority                    = 120
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "10.2.1.0/24"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1186
  ]
}
resource "azurerm_network_security_rule" "res-1188" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "*"
  direction                   = "Outbound"
  name                        = "APIManagementServiceOutbound"
  network_security_group_name = "APIM-NSG"
  priority                    = 110
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1186
  ]
}
resource "azurerm_network_security_rule" "res-1189" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "3443"
  direction                   = "Inbound"
  name                        = "AllowAnyCustom3443Inbound"
  network_security_group_name = "APIM-NSG"
  priority                    = 130
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1186
  ]
}
resource "azurerm_network_security_rule" "res-1190" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "3443"
  direction                   = "Outbound"
  name                        = "AllowAnyCustom3443Outbound"
  network_security_group_name = "APIM-NSG"
  priority                    = 140
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1186
  ]
}
resource "azurerm_network_security_rule" "res-1191" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_ranges     = ["443", "80"]
  direction                   = "Inbound"
  name                        = "InternetInbound"
  network_security_group_name = "APIM-NSG"
  priority                    = 100
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1186
  ]
}
resource "azurerm_network_security_group" "res-1192" {
  location            = "centralus"
  name                = "Amadeus-vm-backstage-nsg"
  resource_group_name = "amedeusnevio_rg"
  tags = {
    application = "amedeus"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_network_security_rule" "res-1193" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "3000"
  direction                   = "Inbound"
  name                        = "AllowAnyCustom3000Inbound"
  network_security_group_name = "Amadeus-vm-backstage-nsg"
  priority                    = 350
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1192
  ]
}
resource "azurerm_network_security_rule" "res-1194" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "80"
  direction                   = "Inbound"
  name                        = "HTTP"
  network_security_group_name = "Amadeus-vm-backstage-nsg"
  priority                    = 320
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1192
  ]
}
resource "azurerm_network_security_rule" "res-1195" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "443"
  direction                   = "Inbound"
  name                        = "HTTPS"
  network_security_group_name = "Amadeus-vm-backstage-nsg"
  priority                    = 340
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1192
  ]
}
resource "azurerm_network_security_rule" "res-1196" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "22"
  direction                   = "Inbound"
  name                        = "SSH"
  network_security_group_name = "Amadeus-vm-backstage-nsg"
  priority                    = 300
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1192
  ]
}
resource "azurerm_network_security_group" "res-1197" {
  location            = "centralus"
  name                = "UICodeBaseGeneration-nsg"
  resource_group_name = "amedeusnevio_rg"
  tags = {
    environment = "development"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_network_security_rule" "res-1198" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "3389"
  direction                   = "Inbound"
  name                        = "RDP"
  network_security_group_name = "UICodeBaseGeneration-nsg"
  priority                    = 300
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1197
  ]
}
resource "azurerm_network_security_group" "res-1199" {
  location            = "centralus"
  name                = "UICodeGeneration-nsg"
  resource_group_name = "amedeusnevio_rg"
  tags = {
    environment = "development"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_network_security_rule" "res-1200" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "22"
  direction                   = "Inbound"
  name                        = "SSH"
  network_security_group_name = "UICodeGeneration-nsg"
  priority                    = 300
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1199
  ]
}
resource "azurerm_network_security_group" "res-1201" {
  location            = "centralus"
  name                = "amadeus-vm-strapi.io-nsg"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_network_security_rule" "res-1202" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "80"
  direction                   = "Inbound"
  name                        = "HTTP"
  network_security_group_name = "amadeus-vm-strapi.io-nsg"
  priority                    = 320
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1201
  ]
}
resource "azurerm_network_security_rule" "res-1203" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "443"
  direction                   = "Inbound"
  name                        = "HTTPS"
  network_security_group_name = "amadeus-vm-strapi.io-nsg"
  priority                    = 340
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1201
  ]
}
resource "azurerm_network_security_rule" "res-1204" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "22"
  direction                   = "Inbound"
  name                        = "SSH"
  network_security_group_name = "amadeus-vm-strapi.io-nsg"
  priority                    = 300
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1201
  ]
}
resource "azurerm_network_security_group" "res-1205" {
  location            = "centralus"
  name                = "amadeusvmbackstagensg507"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_network_security_rule" "res-1206" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "80"
  direction                   = "Inbound"
  name                        = "HTTP"
  network_security_group_name = "amadeusvmbackstagensg507"
  priority                    = 320
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1205
  ]
}
resource "azurerm_network_security_rule" "res-1207" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "443"
  direction                   = "Inbound"
  name                        = "HTTPS"
  network_security_group_name = "amadeusvmbackstagensg507"
  priority                    = 340
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1205
  ]
}
resource "azurerm_network_security_rule" "res-1208" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "22"
  direction                   = "Inbound"
  name                        = "SSH"
  network_security_group_name = "amadeusvmbackstagensg507"
  priority                    = 300
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1205
  ]
}
resource "azurerm_network_security_group" "res-1209" {
  location            = "centralus"
  name                = "amedeus-nsg"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_network_security_rule" "res-1210" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "9000"
  direction                   = "Inbound"
  name                        = "AllowAnyCustom9000Inbound"
  network_security_group_name = "amedeus-nsg"
  priority                    = 350
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1209
  ]
}
resource "azurerm_network_security_rule" "res-1211" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "80"
  direction                   = "Inbound"
  name                        = "HTTP"
  network_security_group_name = "amedeus-nsg"
  priority                    = 320
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1209
  ]
}
resource "azurerm_network_security_rule" "res-1212" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "443"
  direction                   = "Inbound"
  name                        = "HTTPS"
  network_security_group_name = "amedeus-nsg"
  priority                    = 340
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1209
  ]
}
resource "azurerm_network_security_rule" "res-1213" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "22"
  direction                   = "Inbound"
  name                        = "SSH"
  network_security_group_name = "amedeus-nsg"
  priority                    = 300
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1209
  ]
}
resource "azurerm_network_security_group" "res-1214" {
  location            = "centralus"
  name                = "amedeus-vm-backstage-nsg"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_network_security_rule" "res-1215" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "3000"
  direction                   = "Inbound"
  name                        = "AllowAnyCustom3000Inbound"
  network_security_group_name = "amedeus-vm-backstage-nsg"
  priority                    = 350
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1214
  ]
}
resource "azurerm_network_security_rule" "res-1216" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "80"
  direction                   = "Inbound"
  name                        = "HTTP"
  network_security_group_name = "amedeus-vm-backstage-nsg"
  priority                    = 320
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1214
  ]
}
resource "azurerm_network_security_rule" "res-1217" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "443"
  direction                   = "Inbound"
  name                        = "HTTPS"
  network_security_group_name = "amedeus-vm-backstage-nsg"
  priority                    = 340
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1214
  ]
}
resource "azurerm_network_security_rule" "res-1218" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "22"
  direction                   = "Inbound"
  name                        = "SSH"
  network_security_group_name = "amedeus-vm-backstage-nsg"
  priority                    = 300
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1214
  ]
}
resource "azurerm_network_security_group" "res-1219" {
  location            = "centralus"
  name                = "amedeus-vm-nsg"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_network_security_rule" "res-1220" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "22"
  direction                   = "Inbound"
  name                        = "AllowAnyCustom22Inbound"
  network_security_group_name = "amedeus-vm-nsg"
  priority                    = 380
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1219
  ]
}
resource "azurerm_network_security_rule" "res-1221" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "9000"
  direction                   = "Inbound"
  name                        = "AllowAnyCustom9000Inbound"
  network_security_group_name = "amedeus-vm-nsg"
  priority                    = 350
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1219
  ]
}
resource "azurerm_network_security_rule" "res-1222" {
  access                      = "Allow"
  destination_address_prefix  = "10.1.0.5"
  destination_port_range      = "22"
  direction                   = "Inbound"
  name                        = "AllowTagCustom22Inbound"
  network_security_group_name = "amedeus-vm-nsg"
  priority                    = 360
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "VirtualNetwork"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1219
  ]
}
resource "azurerm_network_security_rule" "res-1223" {
  access                      = "Allow"
  destination_address_prefix  = "10.1.0.5"
  destination_port_range      = "3389"
  direction                   = "Inbound"
  name                        = "AllowTagCustom3389Inbound"
  network_security_group_name = "amedeus-vm-nsg"
  priority                    = 370
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "VirtualNetwork"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1219
  ]
}
resource "azurerm_network_security_rule" "res-1224" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "80"
  direction                   = "Inbound"
  name                        = "HTTP"
  network_security_group_name = "amedeus-vm-nsg"
  priority                    = 320
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1219
  ]
}
resource "azurerm_network_security_rule" "res-1225" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "443"
  direction                   = "Inbound"
  name                        = "HTTPS"
  network_security_group_name = "amedeus-vm-nsg"
  priority                    = 340
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1219
  ]
}
resource "azurerm_network_security_rule" "res-1226" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "*"
  direction                   = "Inbound"
  name                        = "sonarqubebackstage"
  network_security_group_name = "amedeus-vm-nsg"
  priority                    = 100
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1219
  ]
}
resource "azurerm_network_security_rule" "res-1227" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "*"
  direction                   = "Outbound"
  name                        = "sonarqubebackstageoutbound"
  network_security_group_name = "amedeus-vm-nsg"
  priority                    = 100
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1219
  ]
}
resource "azurerm_network_security_group" "res-1228" {
  location            = "centralus"
  name                = "amedeusvmbackstagensg423"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_network_security_rule" "res-1229" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "80"
  direction                   = "Inbound"
  name                        = "HTTP"
  network_security_group_name = "amedeusvmbackstagensg423"
  priority                    = 320
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1228
  ]
}
resource "azurerm_network_security_rule" "res-1230" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "443"
  direction                   = "Inbound"
  name                        = "HTTPS"
  network_security_group_name = "amedeusvmbackstagensg423"
  priority                    = 340
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1228
  ]
}
resource "azurerm_network_security_rule" "res-1231" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "22"
  direction                   = "Inbound"
  name                        = "SSH"
  network_security_group_name = "amedeusvmbackstagensg423"
  priority                    = 300
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1228
  ]
}
resource "azurerm_network_security_group" "res-1232" {
  location            = "centralus"
  name                = "amedeusvmbackstagensg439"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_network_security_rule" "res-1233" {
  access                      = "Allow"
  destination_address_prefix  = "10.2.4.6"
  destination_port_range      = "5432"
  direction                   = "Outbound"
  name                        = "Allow-postgres-out"
  network_security_group_name = "amedeusvmbackstagensg439"
  priority                    = 1000
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1232
  ]
}
resource "azurerm_network_security_rule" "res-1234" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "3000"
  direction                   = "Inbound"
  name                        = "AllowAnyCustom3000Inbound"
  network_security_group_name = "amedeusvmbackstagensg439"
  priority                    = 350
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1232
  ]
}
resource "azurerm_network_security_rule" "res-1235" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "3000"
  direction                   = "Outbound"
  name                        = "AllowAnyCustom3000Outbound"
  network_security_group_name = "amedeusvmbackstagensg439"
  priority                    = 380
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1232
  ]
}
resource "azurerm_network_security_rule" "res-1236" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "7007"
  direction                   = "Inbound"
  name                        = "AllowAnyCustom7007Inbound"
  network_security_group_name = "amedeusvmbackstagensg439"
  priority                    = 360
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1232
  ]
}
resource "azurerm_network_security_rule" "res-1237" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "7007"
  direction                   = "Outbound"
  name                        = "AllowAnyCustom7007Outbound"
  network_security_group_name = "amedeusvmbackstagensg439"
  priority                    = 370
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1232
  ]
}
resource "azurerm_network_security_rule" "res-1238" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "80"
  direction                   = "Outbound"
  name                        = "AllowAnyCustom80Outbound"
  network_security_group_name = "amedeusvmbackstagensg439"
  priority                    = 390
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1232
  ]
}
resource "azurerm_network_security_rule" "res-1239" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "*"
  direction                   = "Inbound"
  name                        = "AllowAnyCustomAnyInbound"
  network_security_group_name = "amedeusvmbackstagensg439"
  priority                    = 100
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1232
  ]
}
resource "azurerm_network_security_rule" "res-1240" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "*"
  direction                   = "Outbound"
  name                        = "AllowAnyCustomAnyOutbound"
  network_security_group_name = "amedeusvmbackstagensg439"
  priority                    = 100
  protocol                    = "*"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1232
  ]
}
resource "azurerm_network_security_rule" "res-1241" {
  access                      = "Allow"
  destination_address_prefix  = "10.1.0.6"
  destination_port_range      = "22"
  direction                   = "Inbound"
  name                        = "AllowCidrBlockCustom22Inbound"
  network_security_group_name = "amedeusvmbackstagensg439"
  priority                    = 400
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "VirtualNetwork"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1232
  ]
}
resource "azurerm_network_security_rule" "res-1242" {
  access                      = "Allow"
  destination_address_prefix  = "168.63.129.16"
  destination_port_range      = "3389"
  direction                   = "Inbound"
  name                        = "AllowTagCustom3389Inbound"
  network_security_group_name = "amedeusvmbackstagensg439"
  priority                    = 410
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "VirtualNetwork"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1232
  ]
}
resource "azurerm_network_security_rule" "res-1243" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "80"
  direction                   = "Inbound"
  name                        = "HTTP"
  network_security_group_name = "amedeusvmbackstagensg439"
  priority                    = 320
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1232
  ]
}
resource "azurerm_network_security_rule" "res-1244" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "443"
  direction                   = "Inbound"
  name                        = "HTTPS"
  network_security_group_name = "amedeusvmbackstagensg439"
  priority                    = 340
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1232
  ]
}
resource "azurerm_network_security_group" "res-1245" {
  location            = "centralus"
  name                = "amedeusvmbackstagensg689"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_network_security_rule" "res-1246" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "80"
  direction                   = "Inbound"
  name                        = "HTTP"
  network_security_group_name = "amedeusvmbackstagensg689"
  priority                    = 320
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1245
  ]
}
resource "azurerm_network_security_rule" "res-1247" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "443"
  direction                   = "Inbound"
  name                        = "HTTPS"
  network_security_group_name = "amedeusvmbackstagensg689"
  priority                    = 340
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1245
  ]
}
resource "azurerm_network_security_rule" "res-1248" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "22"
  direction                   = "Inbound"
  name                        = "SSH"
  network_security_group_name = "amedeusvmbackstagensg689"
  priority                    = 300
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1245
  ]
}
resource "azurerm_network_security_group" "res-1249" {
  location            = "centralus"
  name                = "basicNsgbackstage-vm"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_network_security_group" "res-1250" {
  location            = "centralus"
  name                = "basicNsgsonarqube-vm"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_network_security_rule" "res-1251" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "80"
  direction                   = "Inbound"
  name                        = "HTTP"
  network_security_group_name = "basicNsgsonarqube-vm"
  priority                    = 320
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1250
  ]
}
resource "azurerm_network_security_rule" "res-1252" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "443"
  direction                   = "Inbound"
  name                        = "HTTPS"
  network_security_group_name = "basicNsgsonarqube-vm"
  priority                    = 340
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1250
  ]
}
resource "azurerm_network_security_rule" "res-1253" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "22"
  direction                   = "Inbound"
  name                        = "SSH"
  network_security_group_name = "basicNsgsonarqube-vm"
  priority                    = 300
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1250
  ]
}
resource "azurerm_network_security_group" "res-1254" {
  location            = "eastus"
  name                = "funcapp-nsg"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_network_security_group" "res-1255" {
  location            = "eastus"
  name                = "postgresdb-nsg"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_network_security_rule" "res-1256" {
  access                      = "Allow"
  destination_address_prefix  = "*"
  destination_port_range      = "22"
  direction                   = "Inbound"
  name                        = "SSH"
  network_security_group_name = "postgresdb-nsg"
  priority                    = 300
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "*"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1255
  ]
}
resource "azurerm_network_security_rule" "res-1257" {
  access                      = "Allow"
  destination_address_prefix  = "VirtualNetwork"
  destination_port_range      = "5432"
  direction                   = "Outbound"
  name                        = "outbound5432"
  network_security_group_name = "postgresdb-nsg"
  priority                    = 310
  protocol                    = "Tcp"
  resource_group_name         = "amedeusnevio_rg"
  source_address_prefix       = "VirtualNetwork"
  source_port_range           = "*"
  depends_on = [
    azurerm_network_security_group.res-1255
  ]
}
resource "azurerm_private_dns_zone" "res-1258" {
  name                = "privatelink.postgres.database.azure.com"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_private_dns_a_record" "res-1259" {
  name                = "nevioscdb"
  records             = ["10.2.4.6"]
  resource_group_name = "amedeusnevio_rg"
  tags = {
    creator = "created by private endpoint nevioscudb-pe with resource guid 9e77fd2d-996b-480b-b93e-da8f6aca1846"
  }
  ttl       = 10
  zone_name = "privatelink.postgres.database.azure.com"
  depends_on = [
    azurerm_private_dns_zone.res-1258
  ]
}
resource "azurerm_private_dns_zone_virtual_network_link" "res-1261" {
  name                  = "BackstageVM"
  private_dns_zone_name = "privatelink.postgres.database.azure.com"
  resource_group_name   = "amedeusnevio_rg"
  virtual_network_id    = azurerm_virtual_network.res-1296.id
  depends_on = [
    azurerm_private_dns_zone.res-1258
  ]
}
resource "azurerm_private_endpoint" "res-1262" {
  custom_network_interface_name = "amadeus-postgresdb-nic"
  location                      = "eastus"
  name                          = "amadeus-postgresdb"
  resource_group_name           = "amedeusnevio_rg"
  subnet_id                     = azurerm_subnet.res-1293.id
  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = [azurerm_private_dns_zone.res-1258.id]
  }
  private_service_connection {
    is_manual_connection           = false
    name                           = "amadeus-postgresdb"
    private_connection_resource_id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.DBforPostgreSQL/flexibleServers/nevioscuidb"
    subresource_names              = ["postgresqlServer"]
  }
}
resource "azurerm_private_endpoint" "res-1264" {
  custom_network_interface_name = "nevioscudb-pe-nic"
  location                      = "eastus"
  name                          = "nevioscudb-pe"
  resource_group_name           = "amedeusnevio_rg"
  subnet_id                     = azurerm_subnet.res-1291.id
  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = [azurerm_private_dns_zone.res-1258.id]
  }
  private_service_connection {
    is_manual_connection           = false
    name                           = "nevioscudb-pe"
    private_connection_resource_id = azurerm_postgresql_flexible_server.res-543.id
    subresource_names              = ["postgresqlServer"]
  }
}
resource "azurerm_private_endpoint" "res-1266" {
  location            = "germanywestcentral"
  name                = "pe-devdb"
  resource_group_name = "amedeusnevio_rg"
  subnet_id           = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeus-vm_group/providers/Microsoft.Network/virtualNetworks/vnet-dev-db/subnets/snet-dev-db"
  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeus-vm_group/providers/Microsoft.Network/privateDnsZones/privatelink.postgres.database.azure.com"]
  }
  private_service_connection {
    is_manual_connection           = false
    name                           = "pe-devdb_f6127c41-ecce-4698-97b8-27048fadc042"
    private_connection_resource_id = azurerm_postgresql_flexible_server.res-536.id
    subresource_names              = ["postgresqlServer"]
  }
}
resource "azurerm_public_ip" "res-1268" {
  allocation_method   = "Static"
  location            = "centralus"
  name                = "SCUI-backstage"
  resource_group_name = "amedeusnevio_rg"
  zones               = ["1", "2", "3"]
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_public_ip" "res-1269" {
  allocation_method   = "Static"
  domain_name_label   = "amadeus-testing"
  location            = "centralus"
  name                = "UICodeBaseGeneration-ip"
  resource_group_name = "amedeusnevio_rg"
  tags = {
    environment = "development"
  }
  zones = ["1"]
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_public_ip" "res-1270" {
  allocation_method   = "Static"
  location            = "centralus"
  name                = "UICodeGeneration-ip"
  resource_group_name = "amedeusnevio_rg"
  tags = {
    environment = "development"
  }
  zones = ["1"]
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_public_ip" "res-1271" {
  allocation_method   = "Static"
  location            = "centralus"
  name                = "amadeus-vm-backstage-ip"
  resource_group_name = "amedeusnevio_rg"
  zones               = ["1"]
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_public_ip" "res-1272" {
  allocation_method       = "Static"
  idle_timeout_in_minutes = 15
  location                = "centralus"
  name                    = "amadeus-vm-strapi.io-ip-8ed40b8c"
  resource_group_name     = "amedeusnevio_rg"
  zones                   = ["3"]
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_public_ip" "res-1273" {
  allocation_method   = "Static"
  domain_name_label   = "amadeus-sonarqube"
  location            = "centralus"
  name                = "amedeus-ip"
  resource_group_name = "amedeusnevio_rg"
  zones               = ["1"]
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_public_ip" "res-1274" {
  allocation_method   = "Static"
  location            = "centralus"
  name                = "amedeus-test-vnet-IPv4"
  resource_group_name = "amedeusnevio_rg"
  zones               = ["1", "2", "3"]
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_public_ip" "res-1275" {
  allocation_method   = "Static"
  domain_name_label   = "sc-idp"
  location            = "centralus"
  name                = "amedeus-vm-backstage-ip"
  resource_group_name = "amedeusnevio_rg"
  zones               = ["1"]
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_public_ip" "res-1276" {
  allocation_method   = "Static"
  domain_name_label   = "amedeus-sonarqube"
  location            = "centralus"
  name                = "amedeus-vm-ip"
  resource_group_name = "amedeusnevio_rg"
  zones               = ["1"]
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_public_ip" "res-1277" {
  allocation_method   = "Static"
  location            = "eastus"
  name                = "amedeusnevio"
  resource_group_name = "amedeusnevio_rg"
  zones               = ["1", "2", "3"]
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_public_ip" "res-1278" {
  allocation_method   = "Static"
  location            = "centralus"
  name                = "amedeustestvnetIPv4744"
  resource_group_name = "amedeusnevio_rg"
  zones               = ["1", "2", "3"]
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_public_ip" "res-1279" {
  allocation_method   = "Static"
  domain_name_label   = "scui-sonarqube"
  location            = "centralus"
  name                = "pip-amedeus-test-vnet-centralus-default"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_public_ip" "res-1280" {
  allocation_method   = "Static"
  domain_name_label   = "scui-backstage"
  location            = "centralus"
  name                = "pip-amedeus-test-vnet-centralus-default2"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_public_ip" "res-1281" {
  allocation_method   = "Static"
  location            = "eastus"
  name                = "postgresdb-ip"
  resource_group_name = "amedeusnevio_rg"
  zones               = ["3"]
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_virtual_network" "res-1282" {
  address_space       = ["10.0.0.0/16"]
  location            = "centralus"
  name                = "AmadeusNevioVnet"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_subnet" "res-1283" {
  address_prefixes     = ["10.0.1.0/24"]
  name                 = "default1"
  resource_group_name  = "amedeusnevio_rg"
  virtual_network_name = "AmadeusNevioVnet"
  depends_on = [
    azurerm_virtual_network.res-1282
  ]
}
resource "azurerm_subnet" "res-1284" {
  address_prefixes     = ["10.0.2.0/24"]
  name                 = "default2"
  resource_group_name  = "amedeusnevio_rg"
  virtual_network_name = "AmadeusNevioVnet"
  depends_on = [
    azurerm_virtual_network.res-1282
  ]
}
resource "azurerm_subnet" "res-1285" {
  address_prefixes     = ["10.0.3.0/24"]
  name                 = "default3"
  resource_group_name  = "amedeusnevio_rg"
  virtual_network_name = "AmadeusNevioVnet"
  depends_on = [
    azurerm_virtual_network.res-1282
  ]
}
resource "azurerm_subnet" "res-1286" {
  address_prefixes     = ["10.0.4.0/24"]
  name                 = "default4"
  resource_group_name  = "amedeusnevio_rg"
  virtual_network_name = "AmadeusNevioVnet"
  depends_on = [
    azurerm_virtual_network.res-1282
  ]
}
resource "azurerm_virtual_network" "res-1287" {
  address_space       = ["10.2.0.0/16"]
  location            = "eastus"
  name                = "amadeusnevio-VN"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_subnet" "res-1288" {
  address_prefixes     = ["10.2.1.0/24"]
  name                 = "AGW-Subnet"
  resource_group_name  = "amedeusnevio_rg"
  virtual_network_name = "amadeusnevio-VN"
  depends_on = [
    azurerm_virtual_network.res-1287
  ]
}
resource "azurerm_subnet" "res-1289" {
  address_prefixes     = ["10.2.2.0/24"]
  name                 = "APIM-Subnet"
  resource_group_name  = "amedeusnevio_rg"
  virtual_network_name = "amadeusnevio-VN"
  depends_on = [
    azurerm_virtual_network.res-1287
  ]
}
resource "azurerm_subnet_network_security_group_association" "res-1290" {
  network_security_group_id = azurerm_network_security_group.res-1186.id
  subnet_id                 = azurerm_subnet.res-1289.id
}
resource "azurerm_subnet" "res-1291" {
  address_prefixes     = ["10.2.4.0/24"]
  name                 = "DB-Subnet"
  resource_group_name  = "amedeusnevio_rg"
  virtual_network_name = "amadeusnevio-VN"
  depends_on = [
    azurerm_virtual_network.res-1287
  ]
}
resource "azurerm_subnet" "res-1292" {
  address_prefixes     = ["10.2.3.0/24"]
  name                 = "Fapps-Subnet"
  resource_group_name  = "amedeusnevio_rg"
  virtual_network_name = "amadeusnevio-VN"
  delegation {
    name = "delegation"
    service_delegation {
      actions = ["Microsoft.Network/virtualNetworks/subnets/join/action"]
      name    = "Microsoft.App/environments"
    }
  }
  depends_on = [
    azurerm_virtual_network.res-1287
  ]
}
resource "azurerm_subnet" "res-1293" {
  address_prefixes     = ["10.2.0.0/24"]
  name                 = "default"
  resource_group_name  = "amedeusnevio_rg"
  virtual_network_name = "amadeusnevio-VN"
  depends_on = [
    azurerm_virtual_network.res-1287
  ]
}
resource "azurerm_virtual_network_peering" "res-1294" {
  allow_forwarded_traffic   = true
  name                      = "AccessDB"
  remote_virtual_network_id = azurerm_virtual_network.res-1296.id
  resource_group_name       = "amedeusnevio_rg"
  virtual_network_name      = "amadeusnevio-VN"
  depends_on = [
    azurerm_virtual_network.res-1287
  ]
}
resource "azurerm_virtual_network_peering" "res-1295" {
  allow_forwarded_traffic   = true
  name                      = "AccessDataBase"
  remote_virtual_network_id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeus-vm_group/providers/Microsoft.Network/virtualNetworks/vnet-dev-db"
  resource_group_name       = "amedeusnevio_rg"
  virtual_network_name      = "amadeusnevio-VN"
  depends_on = [
    azurerm_virtual_network.res-1287
  ]
}
resource "azurerm_virtual_network" "res-1296" {
  address_space       = ["10.1.0.0/16"]
  location            = "centralus"
  name                = "amedeus-test-vnet"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_subnet" "res-1297" {
  address_prefixes     = ["10.1.1.0/26"]
  name                 = "AzureBastionSubnet"
  resource_group_name  = "amedeusnevio_rg"
  virtual_network_name = "amedeus-test-vnet"
  depends_on = [
    azurerm_virtual_network.res-1296
  ]
}
resource "azurerm_subnet" "res-1298" {
  address_prefixes     = ["10.1.0.0/24"]
  name                 = "default"
  resource_group_name  = "amedeusnevio_rg"
  virtual_network_name = "amedeus-test-vnet"
  depends_on = [
    azurerm_virtual_network.res-1296
  ]
}
resource "azurerm_virtual_network_peering" "res-1299" {
  allow_forwarded_traffic   = true
  allow_gateway_transit     = true
  name                      = "AccessDB"
  remote_virtual_network_id = azurerm_virtual_network.res-1287.id
  resource_group_name       = "amedeusnevio_rg"
  virtual_network_name      = "amedeus-test-vnet"
  depends_on = [
    azurerm_virtual_network.res-1296
  ]
}
resource "azurerm_virtual_network_peering" "res-1300" {
  allow_forwarded_traffic   = true
  allow_gateway_transit     = true
  name                      = "BackstageDB"
  remote_virtual_network_id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeus-vm_group/providers/Microsoft.Network/virtualNetworks/vnet-dev-db"
  resource_group_name       = "amedeusnevio_rg"
  virtual_network_name      = "amedeus-test-vnet"
  depends_on = [
    azurerm_virtual_network.res-1296
  ]
}
resource "azurerm_virtual_network" "res-1301" {
  address_space       = ["172.16.0.0/16"]
  location            = "centralus"
  name                = "vnet-centralus"
  resource_group_name = "amedeusnevio_rg"
  tags = {
    environment = "development"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_virtual_network" "res-1302" {
  address_space       = ["172.18.0.0/16"]
  location            = "centralus"
  name                = "vnet-centralus-1"
  resource_group_name = "amedeusnevio_rg"
  tags = {
    environment = "development"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_subnet" "res-1303" {
  address_prefixes     = ["172.18.0.0/24"]
  name                 = "snet-centralus-1"
  resource_group_name  = "amedeusnevio_rg"
  virtual_network_name = "vnet-centralus-1"
  depends_on = [
    azurerm_virtual_network.res-1302
  ]
}
resource "azurerm_subnet" "res-1304" {
  address_prefixes     = ["172.16.0.0/24"]
  name                 = "snet-centralus-1"
  resource_group_name  = "amedeusnevio_rg"
  virtual_network_name = "vnet-centralus"
  depends_on = [
    azurerm_virtual_network.res-1301
  ]
}
resource "azurerm_portal_dashboard" "res-1305" {
  dashboard_properties = jsonencode({
    lenses = {
      "0" = {
        order = 0
        parts = {
          "0" = {
            metadata = {
              asset = {
                idInputName = "id"
                type        = "ApplicationInsights"
              }
              defaultMenuItemId = "overview"
              inputs = [{
                name  = "id"
                value = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                }, {
                name  = "Version"
                value = "1.0"
              }]
              type = "Extension/AppInsightsExtension/PartType/AspNetOverviewPinnedPart"
            }
            position = {
              colSpan = 2
              rowSpan = 1
              x       = 0
              y       = 0
            }
          }
          "1" = {
            metadata = {
              asset = {
                idInputName = "ComponentId"
                type        = "ApplicationInsights"
              }
              defaultMenuItemId = "ProactiveDetection"
              inputs = [{
                name = "ComponentId"
                value = {
                  Name           = "offerapi"
                  ResourceGroup  = "amedeusnevio_rg"
                  SubscriptionId = "6894432a-17c6-42c4-8118-d547be97aca4"
                }
                }, {
                name  = "Version"
                value = "1.0"
              }]
              type = "Extension/AppInsightsExtension/PartType/ProactiveDetectionAsyncPart"
            }
            position = {
              colSpan = 1
              rowSpan = 1
              x       = 2
              y       = 0
            }
          }
          "10" = {
            metadata = {
              asset = {
                idInputName = "ResourceId"
                type        = "ApplicationInsights"
              }
              defaultMenuItemId = "performance"
              inputs = [{
                name  = "ResourceId"
                value = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                }, {
                isOptional = true
                name       = "DataModel"
                value = {
                  timeContext = {
                    createdTime           = "2018-05-04T23:43:37.804Z"
                    durationMs            = 86400000
                    grain                 = 1
                    isInitialTime         = false
                    useDashboardTimeRange = false
                  }
                  version = "1.0.0"
                }
                }, {
                isOptional = true
                name       = "ConfigurationId"
                value      = "2a8ede4f-2bee-4b9c-aed9-2db0e8a01865"
              }]
              isAdapter = true
              type      = "Extension/AppInsightsExtension/PartType/CuratedBladePerformancePinnedPart"
            }
            position = {
              colSpan = 1
              rowSpan = 1
              x       = 11
              y       = 1
            }
          }
          "11" = {
            metadata = {
              inputs = []
              settings = {
                content = {
                  settings = {
                    content  = "# Browser"
                    subtitle = ""
                    title    = ""
                  }
                }
              }
              type = "Extension[azure]/HubsExtension/PartType/MarkdownPart"
            }
            position = {
              colSpan = 3
              rowSpan = 1
              x       = 12
              y       = 1
            }
          }
          "12" = {
            metadata = {
              asset = {
                idInputName = "ComponentId"
                type        = "ApplicationInsights"
              }
              defaultMenuItemId = "browser"
              inputs = [{
                name = "ComponentId"
                value = {
                  Name           = "offerapi"
                  ResourceGroup  = "amedeusnevio_rg"
                  SubscriptionId = "6894432a-17c6-42c4-8118-d547be97aca4"
                }
                }, {
                name  = "MetricsExplorerJsonDefinitionId"
                value = "BrowserPerformanceTimelineMetrics"
                }, {
                name = "TimeContext"
                value = {
                  createdTime           = "2018-05-08T12:16:27.534Z"
                  durationMs            = 86400000
                  grain                 = 1
                  isInitialTime         = false
                  useDashboardTimeRange = false
                }
                }, {
                name = "CurrentFilter"
                value = {
                  eventTypes   = [4, 1, 3, 5, 2, 6, 13]
                  isPermissive = false
                  typeFacets   = {}
                }
                }, {
                name = "id"
                value = {
                  Name           = "offerapi"
                  ResourceGroup  = "amedeusnevio_rg"
                  SubscriptionId = "6894432a-17c6-42c4-8118-d547be97aca4"
                }
                }, {
                name  = "Version"
                value = "1.0"
              }]
              type = "Extension/AppInsightsExtension/PartType/MetricsExplorerBladePinnedPart"
            }
            position = {
              colSpan = 1
              rowSpan = 1
              x       = 15
              y       = 1
            }
          }
          "13" = {
            metadata = {
              inputs = [{
                name = "options"
                value = {
                  chart = {
                    metrics = [{
                      aggregationType = 5
                      metricVisualization = {
                        color       = "#47BDF5"
                        displayName = "Sessions"
                      }
                      name      = "sessions/count"
                      namespace = "microsoft.insights/components/kusto"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                      }, {
                      aggregationType = 5
                      metricVisualization = {
                        color       = "#7E58FF"
                        displayName = "Users"
                      }
                      name      = "users/count"
                      namespace = "microsoft.insights/components/kusto"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                    }]
                    openBladeOnClick = {
                      destinationBlade = {
                        bladeName     = "ResourceMenuBlade"
                        extensionName = "HubsExtension"
                        parameters = {
                          id     = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                          menuid = "segmentationUsers"
                        }
                      }
                      openBlade = true
                    }
                    title = "Unique sessions and users"
                    visualization = {
                      axisVisualization = {
                        x = {
                          axisType  = 2
                          isVisible = true
                        }
                        y = {
                          axisType  = 1
                          isVisible = true
                        }
                      }
                      chartType = 2
                      legendVisualization = {
                        hideSubtitle = false
                        isVisible    = true
                        position     = 2
                      }
                    }
                  }
                }
                }, {
                isOptional = true
                name       = "sharedTimeRange"
              }]
              settings = {}
              type     = "Extension/HubsExtension/PartType/MonitorChartPart"
            }
            position = {
              colSpan = 4
              rowSpan = 3
              x       = 0
              y       = 2
            }
          }
          "14" = {
            metadata = {
              inputs = [{
                name = "options"
                value = {
                  chart = {
                    metrics = [{
                      aggregationType = 7
                      metricVisualization = {
                        color       = "#EC008C"
                        displayName = "Failed requests"
                      }
                      name      = "requests/failed"
                      namespace = "microsoft.insights/components"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                    }]
                    openBladeOnClick = {
                      destinationBlade = {
                        bladeName     = "ResourceMenuBlade"
                        extensionName = "HubsExtension"
                        parameters = {
                          id     = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                          menuid = "failures"
                        }
                      }
                      openBlade = true
                    }
                    title = "Failed requests"
                    visualization = {
                      axisVisualization = {
                        x = {
                          axisType  = 2
                          isVisible = true
                        }
                        y = {
                          axisType  = 1
                          isVisible = true
                        }
                      }
                      chartType = 3
                      legendVisualization = {
                        hideSubtitle = false
                        isVisible    = true
                        position     = 2
                      }
                    }
                  }
                }
                }, {
                isOptional = true
                name       = "sharedTimeRange"
              }]
              settings = {}
              type     = "Extension/HubsExtension/PartType/MonitorChartPart"
            }
            position = {
              colSpan = 4
              rowSpan = 3
              x       = 4
              y       = 2
            }
          }
          "15" = {
            metadata = {
              inputs = [{
                name = "options"
                value = {
                  chart = {
                    metrics = [{
                      aggregationType = 4
                      metricVisualization = {
                        color       = "#00BCF2"
                        displayName = "Server response time"
                      }
                      name      = "requests/duration"
                      namespace = "microsoft.insights/components"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                    }]
                    openBladeOnClick = {
                      destinationBlade = {
                        bladeName     = "ResourceMenuBlade"
                        extensionName = "HubsExtension"
                        parameters = {
                          id     = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                          menuid = "performance"
                        }
                      }
                      openBlade = true
                    }
                    title = "Server response time"
                    visualization = {
                      axisVisualization = {
                        x = {
                          axisType  = 2
                          isVisible = true
                        }
                        y = {
                          axisType  = 1
                          isVisible = true
                        }
                      }
                      chartType = 2
                      legendVisualization = {
                        hideSubtitle = false
                        isVisible    = true
                        position     = 2
                      }
                    }
                  }
                }
                }, {
                isOptional = true
                name       = "sharedTimeRange"
              }]
              settings = {}
              type     = "Extension/HubsExtension/PartType/MonitorChartPart"
            }
            position = {
              colSpan = 4
              rowSpan = 3
              x       = 8
              y       = 2
            }
          }
          "16" = {
            metadata = {
              inputs = [{
                name = "options"
                value = {
                  chart = {
                    metrics = [{
                      aggregationType = 4
                      metricVisualization = {
                        color       = "#7E58FF"
                        displayName = "Page load network connect time"
                      }
                      name      = "browserTimings/networkDuration"
                      namespace = "microsoft.insights/components"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                      }, {
                      aggregationType = 4
                      metricVisualization = {
                        color       = "#44F1C8"
                        displayName = "Client processing time"
                      }
                      name      = "browserTimings/processingDuration"
                      namespace = "microsoft.insights/components"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                      }, {
                      aggregationType = 4
                      metricVisualization = {
                        color       = "#EB9371"
                        displayName = "Send request time"
                      }
                      name      = "browserTimings/sendDuration"
                      namespace = "microsoft.insights/components"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                      }, {
                      aggregationType = 4
                      metricVisualization = {
                        color       = "#0672F1"
                        displayName = "Receiving response time"
                      }
                      name      = "browserTimings/receiveDuration"
                      namespace = "microsoft.insights/components"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                    }]
                    title = "Average page load time breakdown"
                    visualization = {
                      axisVisualization = {
                        x = {
                          axisType  = 2
                          isVisible = true
                        }
                        y = {
                          axisType  = 1
                          isVisible = true
                        }
                      }
                      chartType = 3
                      legendVisualization = {
                        hideSubtitle = false
                        isVisible    = true
                        position     = 2
                      }
                    }
                  }
                }
                }, {
                isOptional = true
                name       = "sharedTimeRange"
              }]
              settings = {}
              type     = "Extension/HubsExtension/PartType/MonitorChartPart"
            }
            position = {
              colSpan = 4
              rowSpan = 3
              x       = 12
              y       = 2
            }
          }
          "17" = {
            metadata = {
              inputs = [{
                name = "options"
                value = {
                  chart = {
                    metrics = [{
                      aggregationType = 4
                      metricVisualization = {
                        color       = "#47BDF5"
                        displayName = "Availability"
                      }
                      name      = "availabilityResults/availabilityPercentage"
                      namespace = "microsoft.insights/components"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                    }]
                    openBladeOnClick = {
                      destinationBlade = {
                        bladeName     = "ResourceMenuBlade"
                        extensionName = "HubsExtension"
                        parameters = {
                          id     = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                          menuid = "availability"
                        }
                      }
                      openBlade = true
                    }
                    title = "Average availability"
                    visualization = {
                      axisVisualization = {
                        x = {
                          axisType  = 2
                          isVisible = true
                        }
                        y = {
                          axisType  = 1
                          isVisible = true
                        }
                      }
                      chartType = 3
                      legendVisualization = {
                        hideSubtitle = false
                        isVisible    = true
                        position     = 2
                      }
                    }
                  }
                }
                }, {
                isOptional = true
                name       = "sharedTimeRange"
              }]
              settings = {}
              type     = "Extension/HubsExtension/PartType/MonitorChartPart"
            }
            position = {
              colSpan = 4
              rowSpan = 3
              x       = 0
              y       = 5
            }
          }
          "18" = {
            metadata = {
              inputs = [{
                name = "options"
                value = {
                  chart = {
                    metrics = [{
                      aggregationType = 7
                      metricVisualization = {
                        color       = "#47BDF5"
                        displayName = "Server exceptions"
                      }
                      name      = "exceptions/server"
                      namespace = "microsoft.insights/components"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                      }, {
                      aggregationType = 7
                      metricVisualization = {
                        color       = "#7E58FF"
                        displayName = "Dependency failures"
                      }
                      name      = "dependencies/failed"
                      namespace = "microsoft.insights/components"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                    }]
                    title = "Server exceptions and Dependency failures"
                    visualization = {
                      axisVisualization = {
                        x = {
                          axisType  = 2
                          isVisible = true
                        }
                        y = {
                          axisType  = 1
                          isVisible = true
                        }
                      }
                      chartType = 2
                      legendVisualization = {
                        hideSubtitle = false
                        isVisible    = true
                        position     = 2
                      }
                    }
                  }
                }
                }, {
                isOptional = true
                name       = "sharedTimeRange"
              }]
              settings = {}
              type     = "Extension/HubsExtension/PartType/MonitorChartPart"
            }
            position = {
              colSpan = 4
              rowSpan = 3
              x       = 4
              y       = 5
            }
          }
          "19" = {
            metadata = {
              inputs = [{
                name = "options"
                value = {
                  chart = {
                    metrics = [{
                      aggregationType = 4
                      metricVisualization = {
                        color       = "#47BDF5"
                        displayName = "Processor time"
                      }
                      name      = "performanceCounters/processorCpuPercentage"
                      namespace = "microsoft.insights/components"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                      }, {
                      aggregationType = 4
                      metricVisualization = {
                        color       = "#7E58FF"
                        displayName = "Process CPU"
                      }
                      name      = "performanceCounters/processCpuPercentage"
                      namespace = "microsoft.insights/components"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                    }]
                    title = "Average processor and process CPU utilization"
                    visualization = {
                      axisVisualization = {
                        x = {
                          axisType  = 2
                          isVisible = true
                        }
                        y = {
                          axisType  = 1
                          isVisible = true
                        }
                      }
                      chartType = 2
                      legendVisualization = {
                        hideSubtitle = false
                        isVisible    = true
                        position     = 2
                      }
                    }
                  }
                }
                }, {
                isOptional = true
                name       = "sharedTimeRange"
              }]
              settings = {}
              type     = "Extension/HubsExtension/PartType/MonitorChartPart"
            }
            position = {
              colSpan = 4
              rowSpan = 3
              x       = 8
              y       = 5
            }
          }
          "2" = {
            metadata = {
              asset = {
                idInputName = "ComponentId"
                type        = "ApplicationInsights"
              }
              inputs = [{
                name = "ComponentId"
                value = {
                  Name           = "offerapi"
                  ResourceGroup  = "amedeusnevio_rg"
                  SubscriptionId = "6894432a-17c6-42c4-8118-d547be97aca4"
                }
                }, {
                name  = "ResourceId"
                value = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
              }]
              type = "Extension/AppInsightsExtension/PartType/QuickPulseButtonSmallPart"
            }
            position = {
              colSpan = 1
              rowSpan = 1
              x       = 3
              y       = 0
            }
          }
          "20" = {
            metadata = {
              inputs = [{
                name = "options"
                value = {
                  chart = {
                    metrics = [{
                      aggregationType = 7
                      metricVisualization = {
                        color       = "#47BDF5"
                        displayName = "Browser exceptions"
                      }
                      name      = "exceptions/browser"
                      namespace = "microsoft.insights/components"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                    }]
                    title = "Browser exceptions"
                    visualization = {
                      axisVisualization = {
                        x = {
                          axisType  = 2
                          isVisible = true
                        }
                        y = {
                          axisType  = 1
                          isVisible = true
                        }
                      }
                      chartType = 2
                      legendVisualization = {
                        hideSubtitle = false
                        isVisible    = true
                        position     = 2
                      }
                    }
                  }
                }
                }, {
                isOptional = true
                name       = "sharedTimeRange"
              }]
              settings = {}
              type     = "Extension/HubsExtension/PartType/MonitorChartPart"
            }
            position = {
              colSpan = 4
              rowSpan = 3
              x       = 12
              y       = 5
            }
          }
          "21" = {
            metadata = {
              inputs = [{
                name = "options"
                value = {
                  chart = {
                    metrics = [{
                      aggregationType = 7
                      metricVisualization = {
                        color       = "#47BDF5"
                        displayName = "Availability test results count"
                      }
                      name      = "availabilityResults/count"
                      namespace = "microsoft.insights/components"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                    }]
                    title = "Availability test results count"
                    visualization = {
                      axisVisualization = {
                        x = {
                          axisType  = 2
                          isVisible = true
                        }
                        y = {
                          axisType  = 1
                          isVisible = true
                        }
                      }
                      chartType = 2
                      legendVisualization = {
                        hideSubtitle = false
                        isVisible    = true
                        position     = 2
                      }
                    }
                  }
                }
                }, {
                isOptional = true
                name       = "sharedTimeRange"
              }]
              settings = {}
              type     = "Extension/HubsExtension/PartType/MonitorChartPart"
            }
            position = {
              colSpan = 4
              rowSpan = 3
              x       = 0
              y       = 8
            }
          }
          "22" = {
            metadata = {
              inputs = [{
                name = "options"
                value = {
                  chart = {
                    metrics = [{
                      aggregationType = 4
                      metricVisualization = {
                        color       = "#47BDF5"
                        displayName = "Process IO rate"
                      }
                      name      = "performanceCounters/processIOBytesPerSecond"
                      namespace = "microsoft.insights/components"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                    }]
                    title = "Average process I/O rate"
                    visualization = {
                      axisVisualization = {
                        x = {
                          axisType  = 2
                          isVisible = true
                        }
                        y = {
                          axisType  = 1
                          isVisible = true
                        }
                      }
                      chartType = 2
                      legendVisualization = {
                        hideSubtitle = false
                        isVisible    = true
                        position     = 2
                      }
                    }
                  }
                }
                }, {
                isOptional = true
                name       = "sharedTimeRange"
              }]
              settings = {}
              type     = "Extension/HubsExtension/PartType/MonitorChartPart"
            }
            position = {
              colSpan = 4
              rowSpan = 3
              x       = 4
              y       = 8
            }
          }
          "23" = {
            metadata = {
              inputs = [{
                name = "options"
                value = {
                  chart = {
                    metrics = [{
                      aggregationType = 4
                      metricVisualization = {
                        color       = "#47BDF5"
                        displayName = "Available memory"
                      }
                      name      = "performanceCounters/memoryAvailableBytes"
                      namespace = "microsoft.insights/components"
                      resourceMetadata = {
                        id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                      }
                    }]
                    title = "Average available memory"
                    visualization = {
                      axisVisualization = {
                        x = {
                          axisType  = 2
                          isVisible = true
                        }
                        y = {
                          axisType  = 1
                          isVisible = true
                        }
                      }
                      chartType = 2
                      legendVisualization = {
                        hideSubtitle = false
                        isVisible    = true
                        position     = 2
                      }
                    }
                  }
                }
                }, {
                isOptional = true
                name       = "sharedTimeRange"
              }]
              settings = {}
              type     = "Extension/HubsExtension/PartType/MonitorChartPart"
            }
            position = {
              colSpan = 4
              rowSpan = 3
              x       = 8
              y       = 8
            }
          }
          "3" = {
            metadata = {
              asset = {
                idInputName = "ComponentId"
                type        = "ApplicationInsights"
              }
              inputs = [{
                name = "ComponentId"
                value = {
                  Name           = "offerapi"
                  ResourceGroup  = "amedeusnevio_rg"
                  SubscriptionId = "6894432a-17c6-42c4-8118-d547be97aca4"
                }
                }, {
                name = "TimeContext"
                value = {
                  createdTime           = "2018-05-04T01:20:33.345Z"
                  durationMs            = 86400000
                  endTime               = null
                  grain                 = 1
                  isInitialTime         = true
                  useDashboardTimeRange = false
                }
                }, {
                name  = "Version"
                value = "1.0"
              }]
              type = "Extension/AppInsightsExtension/PartType/AvailabilityNavButtonPart"
            }
            position = {
              colSpan = 1
              rowSpan = 1
              x       = 4
              y       = 0
            }
          }
          "4" = {
            metadata = {
              asset = {
                idInputName = "ComponentId"
                type        = "ApplicationInsights"
              }
              inputs = [{
                name = "ComponentId"
                value = {
                  Name           = "offerapi"
                  ResourceGroup  = "amedeusnevio_rg"
                  SubscriptionId = "6894432a-17c6-42c4-8118-d547be97aca4"
                }
                }, {
                name = "TimeContext"
                value = {
                  createdTime           = "2018-05-08T18:47:35.237Z"
                  durationMs            = 86400000
                  endTime               = null
                  grain                 = 1
                  isInitialTime         = true
                  useDashboardTimeRange = false
                }
                }, {
                name  = "ConfigurationId"
                value = "78ce933e-e864-4b05-a27b-71fd55a6afad"
              }]
              type = "Extension/AppInsightsExtension/PartType/AppMapButtonPart"
            }
            position = {
              colSpan = 1
              rowSpan = 1
              x       = 5
              y       = 0
            }
          }
          "5" = {
            metadata = {
              inputs = []
              settings = {
                content = {
                  settings = {
                    content  = "# Usage"
                    subtitle = ""
                    title    = ""
                  }
                }
              }
              type = "Extension[azure]/HubsExtension/PartType/MarkdownPart"
            }
            position = {
              colSpan = 3
              rowSpan = 1
              x       = 0
              y       = 1
            }
          }
          "6" = {
            metadata = {
              asset = {
                idInputName = "ComponentId"
                type        = "ApplicationInsights"
              }
              inputs = [{
                name = "ComponentId"
                value = {
                  Name           = "offerapi"
                  ResourceGroup  = "amedeusnevio_rg"
                  SubscriptionId = "6894432a-17c6-42c4-8118-d547be97aca4"
                }
                }, {
                name = "TimeContext"
                value = {
                  createdTime           = "2018-05-04T01:22:35.782Z"
                  durationMs            = 86400000
                  endTime               = null
                  grain                 = 1
                  isInitialTime         = true
                  useDashboardTimeRange = false
                }
              }]
              type = "Extension/AppInsightsExtension/PartType/UsageUsersOverviewPart"
            }
            position = {
              colSpan = 1
              rowSpan = 1
              x       = 3
              y       = 1
            }
          }
          "7" = {
            metadata = {
              inputs = []
              settings = {
                content = {
                  settings = {
                    content  = "# Reliability"
                    subtitle = ""
                    title    = ""
                  }
                }
              }
              type = "Extension[azure]/HubsExtension/PartType/MarkdownPart"
            }
            position = {
              colSpan = 3
              rowSpan = 1
              x       = 4
              y       = 1
            }
          }
          "8" = {
            metadata = {
              asset = {
                idInputName = "ResourceId"
                type        = "ApplicationInsights"
              }
              defaultMenuItemId = "failures"
              inputs = [{
                name  = "ResourceId"
                value = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/offerapi"
                }, {
                isOptional = true
                name       = "DataModel"
                value = {
                  timeContext = {
                    createdTime           = "2018-05-04T23:42:40.072Z"
                    durationMs            = 86400000
                    grain                 = 1
                    isInitialTime         = false
                    useDashboardTimeRange = false
                  }
                  version = "1.0.0"
                }
                }, {
                isOptional = true
                name       = "ConfigurationId"
                value      = "8a02f7bf-ac0f-40e1-afe9-f0e72cfee77f"
              }]
              isAdapter = true
              type      = "Extension/AppInsightsExtension/PartType/CuratedBladeFailuresPinnedPart"
            }
            position = {
              colSpan = 1
              rowSpan = 1
              x       = 7
              y       = 1
            }
          }
          "9" = {
            metadata = {
              inputs = []
              settings = {
                content = {
                  settings = {
                    content  = "# Responsiveness\r\n"
                    subtitle = ""
                    title    = ""
                  }
                }
              }
              type = "Extension[azure]/HubsExtension/PartType/MarkdownPart"
            }
            position = {
              colSpan = 3
              rowSpan = 1
              x       = 8
              y       = 1
            }
          }
        }
      }
    }
  })
  location            = "eastus"
  name                = "02de1020-80eb-450f-b0f7-b2b70e9d4596-dashboard"
  resource_group_name = "amedeusnevio_rg"
  tags = {
    hidden-title = "offerapi Dashboard"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account" "res-1306" {
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  location                        = "eastus"
  name                            = "amadeusblob"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_container" "res-1308" {
  name               = "amadeuscontainer"
  storage_account_id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Storage/storageAccounts/amadeusblob"
  depends_on = [
    # One of azurerm_storage_account.res-1306,azurerm_storage_account_queue_properties.res-1310 (can't auto-resolve as their ids are identical)
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1310" {
  storage_account_id = azurerm_storage_account.res-1306.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_account" "res-1312" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "canadacentral"
  name                            = "amedeusneviorg86fe"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_container" "res-1314" {
  name               = "azure-webjobs-hosts"
  storage_account_id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Storage/storageAccounts/amedeusneviorg86fe"
  depends_on = [
    # One of azurerm_storage_account.res-1312,azurerm_storage_account_queue_properties.res-1317 (can't auto-resolve as their ids are identical)
  ]
}
resource "azurerm_storage_container" "res-1315" {
  name               = "azure-webjobs-secrets"
  storage_account_id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Storage/storageAccounts/amedeusneviorg86fe"
  depends_on = [
    # One of azurerm_storage_account.res-1312,azurerm_storage_account_queue_properties.res-1317 (can't auto-resolve as their ids are identical)
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1317" {
  storage_account_id = azurerm_storage_account.res-1312.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1319" {
  name                 = "AzureFunctionsDiagnosticEvents202506"
  storage_account_name = "amedeusneviorg86fe"
}
resource "azurerm_storage_account" "res-1320" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg8717"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_container" "res-1322" {
  name               = "app-package-sc-api-checkout-passengers-2f3343f"
  storage_account_id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Storage/storageAccounts/amedeusneviorg8717"
  depends_on = [
    # One of azurerm_storage_account.res-1320,azurerm_storage_account_queue_properties.res-1326 (can't auto-resolve as their ids are identical)
  ]
}
resource "azurerm_storage_container" "res-1323" {
  name               = "azure-webjobs-hosts"
  storage_account_id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Storage/storageAccounts/amedeusneviorg8717"
  depends_on = [
    # One of azurerm_storage_account.res-1320,azurerm_storage_account_queue_properties.res-1326 (can't auto-resolve as their ids are identical)
  ]
}
resource "azurerm_storage_container" "res-1324" {
  name               = "azure-webjobs-secrets"
  storage_account_id = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Storage/storageAccounts/amedeusneviorg8717"
  depends_on = [
    # One of azurerm_storage_account.res-1320,azurerm_storage_account_queue_properties.res-1326 (can't auto-resolve as their ids are identical)
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1326" {
  storage_account_id = azurerm_storage_account.res-1320.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1328" {
  name                 = "AzureFunctionsDiagnosticEvents202507"
  storage_account_name = "amedeusneviorg8717"
}
resource "azurerm_storage_account" "res-1329" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg8a92"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1332" {
  storage_account_id = azurerm_storage_account.res-1329.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_account" "res-1334" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg8be0"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1337" {
  storage_account_id = azurerm_storage_account.res-1334.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1339" {
  name                 = "AzureFunctionsDiagnosticEvents202508"
  storage_account_name = "amedeusneviorg8be0"
}
resource "azurerm_storage_account" "res-1340" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg8e60"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1343" {
  storage_account_id = azurerm_storage_account.res-1340.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1345" {
  name                 = "AzureFunctionsDiagnosticEvents202505"
  storage_account_name = "amedeusneviorg8e60"
}
resource "azurerm_storage_account" "res-1346" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg8f6a"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1349" {
  storage_account_id = azurerm_storage_account.res-1346.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1351" {
  name                 = "AzureFunctionsDiagnosticEvents202505"
  storage_account_name = "amedeusneviorg8f6a"
}
resource "azurerm_storage_account" "res-1352" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg8fd5"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1355" {
  storage_account_id = azurerm_storage_account.res-1352.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1357" {
  name                 = "AzureFunctionsDiagnosticEvents202507"
  storage_account_name = "amedeusneviorg8fd5"
}
resource "azurerm_storage_account" "res-1358" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg90d4"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1361" {
  storage_account_id = azurerm_storage_account.res-1358.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1363" {
  name                 = "AzureFunctionsDiagnosticEvents202505"
  storage_account_name = "amedeusneviorg90d4"
}
resource "azurerm_storage_account" "res-1364" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg9588"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1367" {
  storage_account_id = azurerm_storage_account.res-1364.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1369" {
  name                 = "AzureFunctionsDiagnosticEvents202508"
  storage_account_name = "amedeusneviorg9588"
}
resource "azurerm_storage_account" "res-1370" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg95c6"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1373" {
  storage_account_id = azurerm_storage_account.res-1370.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1375" {
  name                 = "AzureFunctionsDiagnosticEvents202506"
  storage_account_name = "amedeusneviorg95c6"
}
resource "azurerm_storage_account" "res-1376" {
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg95f3"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1379" {
  storage_account_id = azurerm_storage_account.res-1376.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1381" {
  name                 = "AzureFunctionsDiagnosticEvents202508"
  storage_account_name = "amedeusneviorg95f3"
}
resource "azurerm_storage_account" "res-1382" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg994f"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1385" {
  storage_account_id = azurerm_storage_account.res-1382.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1387" {
  name                 = "AzureFunctionsDiagnosticEvents202505"
  storage_account_name = "amedeusneviorg994f"
}
resource "azurerm_storage_account" "res-1388" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg99e3"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1391" {
  storage_account_id = azurerm_storage_account.res-1388.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1393" {
  name                 = "AzureFunctionsDiagnosticEvents202508"
  storage_account_name = "amedeusneviorg99e3"
}
resource "azurerm_storage_account" "res-1394" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg9b75"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1397" {
  storage_account_id = azurerm_storage_account.res-1394.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1399" {
  name                 = "AzureFunctionsDiagnosticEvents202508"
  storage_account_name = "amedeusneviorg9b75"
}
resource "azurerm_storage_account" "res-1400" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg9ca6"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1403" {
  storage_account_id = azurerm_storage_account.res-1400.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1405" {
  name                 = "AzureFunctionsDiagnosticEvents202506"
  storage_account_name = "amedeusneviorg9ca6"
}
resource "azurerm_storage_account" "res-1406" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg9cc1"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1409" {
  storage_account_id = azurerm_storage_account.res-1406.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1411" {
  name                 = "AzureFunctionsDiagnosticEvents202506"
  storage_account_name = "amedeusneviorg9cc1"
}
resource "azurerm_storage_table" "res-1412" {
  name                 = "AzureFunctionsDiagnosticEvents202507"
  storage_account_name = "amedeusneviorg9cc1"
}
resource "azurerm_storage_account" "res-1413" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg9cd4"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1416" {
  storage_account_id = azurerm_storage_account.res-1413.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1418" {
  name                 = "AzureFunctionsDiagnosticEvents202506"
  storage_account_name = "amedeusneviorg9cd4"
}
resource "azurerm_storage_account" "res-1419" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorg9da3"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1422" {
  storage_account_id = azurerm_storage_account.res-1419.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1424" {
  name                 = "AzureFunctionsDiagnosticEvents202506"
  storage_account_name = "amedeusneviorg9da3"
}
resource "azurerm_storage_account" "res-1425" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorga71f"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1428" {
  storage_account_id = azurerm_storage_account.res-1425.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1430" {
  name                 = "AzureFunctionsDiagnosticEvents202508"
  storage_account_name = "amedeusneviorga71f"
}
resource "azurerm_storage_account" "res-1431" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorgaae6"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1434" {
  storage_account_id = azurerm_storage_account.res-1431.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1436" {
  name                 = "AzureFunctionsDiagnosticEvents202505"
  storage_account_name = "amedeusneviorgaae6"
}
resource "azurerm_storage_account" "res-1437" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorgaaff"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1440" {
  storage_account_id = azurerm_storage_account.res-1437.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1442" {
  name                 = "AzureFunctionsDiagnosticEvents202510"
  storage_account_name = "amedeusneviorgaaff"
}
resource "azurerm_storage_account" "res-1443" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorgab7d"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1446" {
  storage_account_id = azurerm_storage_account.res-1443.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1448" {
  name                 = "AzureFunctionsDiagnosticEvents202506"
  storage_account_name = "amedeusneviorgab7d"
}
resource "azurerm_storage_table" "res-1449" {
  name                 = "AzureFunctionsDiagnosticEvents202507"
  storage_account_name = "amedeusneviorgab7d"
}
resource "azurerm_storage_account" "res-1450" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorgac41"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1453" {
  storage_account_id = azurerm_storage_account.res-1450.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1455" {
  name                 = "AzureFunctionsDiagnosticEvents202508"
  storage_account_name = "amedeusneviorgac41"
}
resource "azurerm_storage_account" "res-1456" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorgacda"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1459" {
  storage_account_id = azurerm_storage_account.res-1456.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1461" {
  name                 = "AzureFunctionsDiagnosticEvents202505"
  storage_account_name = "amedeusneviorgacda"
}
resource "azurerm_storage_account" "res-1462" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorgad30"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1465" {
  storage_account_id = azurerm_storage_account.res-1462.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1467" {
  name                 = "AzureFunctionsDiagnosticEvents202508"
  storage_account_name = "amedeusneviorgad30"
}
resource "azurerm_storage_account" "res-1468" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorgaf76"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1471" {
  storage_account_id = azurerm_storage_account.res-1468.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1473" {
  name                 = "AzureFunctionsDiagnosticEvents202505"
  storage_account_name = "amedeusneviorgaf76"
}
resource "azurerm_storage_account" "res-1474" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorgb62e"
  resource_group_name             = "amedeusnevio_rg"
  tags = {
    environment = "development"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1477" {
  storage_account_id = azurerm_storage_account.res-1474.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_account" "res-1479" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorgb6b0"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1482" {
  storage_account_id = azurerm_storage_account.res-1479.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1484" {
  name                 = "AzureFunctionsDiagnosticEvents202508"
  storage_account_name = "amedeusneviorgb6b0"
}
resource "azurerm_storage_account" "res-1485" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorgb6fb"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1488" {
  storage_account_id = azurerm_storage_account.res-1485.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1490" {
  name                 = "AzureFunctionsDiagnosticEvents202505"
  storage_account_name = "amedeusneviorgb6fb"
}
resource "azurerm_storage_account" "res-1491" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorgb7c4"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1494" {
  storage_account_id = azurerm_storage_account.res-1491.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1496" {
  name                 = "AzureFunctionsDiagnosticEvents202508"
  storage_account_name = "amedeusneviorgb7c4"
}
resource "azurerm_storage_account" "res-1497" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorgb9c6"
  resource_group_name             = "amedeusnevio_rg"
  tags = {
    environment = "dev"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1500" {
  storage_account_id = azurerm_storage_account.res-1497.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_account" "res-1502" {
  account_kind                    = "Storage"
  account_replication_type        = "LRS"
  account_tier                    = "Standard"
  allow_nested_items_to_be_public = false
  default_to_oauth_authentication = true
  location                        = "eastus"
  name                            = "amedeusneviorgbb71"
  resource_group_name             = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_storage_account_queue_properties" "res-1505" {
  storage_account_id = azurerm_storage_account.res-1502.id
  hour_metrics {
    version = "1.0"
  }
  logging {
    delete  = false
    read    = false
    version = "1.0"
    write   = false
  }
  minute_metrics {
    version = "1.0"
  }
}
resource "azurerm_storage_table" "res-1507" {
  name                 = "AzureFunctionsDiagnosticEvents202507"
  storage_account_name = "amedeusneviorgbb71"
}
resource "azurerm_storage_table" "res-1508" {
  name                 = "AzureFunctionsDiagnosticEvents202508"
  storage_account_name = "amedeusneviorgbb71"
}
resource "azurerm_service_plan" "res-1509" {
  location            = "eastus"
  name                = "ASP-amedeusneviorg-8205"
  os_type             = "Linux"
  resource_group_name = "amedeusnevio_rg"
  sku_name            = "FC1"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_service_plan" "res-1510" {
  location            = "eastus"
  name                = "ASP-amedeusneviorg-8559"
  os_type             = "Linux"
  resource_group_name = "amedeusnevio_rg"
  sku_name            = "FC1"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_service_plan" "res-1511" {
  location            = "eastus"
  name                = "ASP-amedeusneviorg-8560"
  os_type             = "Linux"
  resource_group_name = "amedeusnevio_rg"
  sku_name            = "FC1"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_service_plan" "res-1512" {
  location            = "eastus"
  name                = "ASP-amedeusneviorg-9000"
  os_type             = "Linux"
  resource_group_name = "amedeusnevio_rg"
  sku_name            = "FC1"
  tags = {
    environment = "development"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_service_plan" "res-1513" {
  location            = "eastus"
  name                = "ASP-amedeusneviorg-9835"
  os_type             = "Linux"
  resource_group_name = "amedeusnevio_rg"
  sku_name            = "FC1"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_service_plan" "res-1514" {
  location            = "eastus"
  name                = "ASP-amedeusneviorg-9c10"
  os_type             = "Linux"
  resource_group_name = "amedeusnevio_rg"
  sku_name            = "FC1"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_service_plan" "res-1515" {
  location            = "eastus"
  name                = "ASP-amedeusneviorg-9c9c"
  os_type             = "Linux"
  resource_group_name = "amedeusnevio_rg"
  sku_name            = "FC1"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_service_plan" "res-1516" {
  location            = "eastus"
  name                = "ASP-amedeusneviorg-9cb0"
  os_type             = "Linux"
  resource_group_name = "amedeusnevio_rg"
  sku_name            = "FC1"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_service_plan" "res-1517" {
  location            = "eastus"
  name                = "ASP-amedeusneviorg-9d35"
  os_type             = "Linux"
  resource_group_name = "amedeusnevio_rg"
  sku_name            = "FC1"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_service_plan" "res-1518" {
  location            = "eastus"
  name                = "ASP-amedeusneviorg-a9e8"
  os_type             = "Linux"
  resource_group_name = "amedeusnevio_rg"
  sku_name            = "FC1"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_service_plan" "res-1519" {
  location            = "eastus"
  name                = "ASP-amedeusneviorg-abe1"
  os_type             = "Linux"
  resource_group_name = "amedeusnevio_rg"
  sku_name            = "FC1"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_service_plan" "res-1520" {
  location            = "eastus"
  name                = "ASP-amedeusneviorg-b106"
  os_type             = "Linux"
  resource_group_name = "amedeusnevio_rg"
  sku_name            = "FC1"
  tags = {
    environment = "dev"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_service_plan" "res-1521" {
  location            = "eastus"
  name                = "ASP-amedeusneviorg-bb94"
  os_type             = "Linux"
  resource_group_name = "amedeusnevio_rg"
  sku_name            = "FC1"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_service_plan" "res-1522" {
  location            = "eastus2"
  name                = "ASP-amedeusneviorg-bbd9"
  os_type             = "Linux"
  resource_group_name = "amedeusnevio_rg"
  sku_name            = "B1"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_service_plan" "res-1523" {
  location            = "eastus"
  name                = "ASP-amedeusneviorg-bc0a"
  os_type             = "Linux"
  resource_group_name = "amedeusnevio_rg"
  sku_name            = "FC1"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_linux_web_app" "res-1524" {
  app_settings = {
    AGENTID                                  = "789516691364"
    AIRLINECODE                              = "AY"
    API_BASE_URL                             = "https://nevioservicecenterapim.azure-api.net"
    APP_CONFIG_API_URL                       = "/appConfig"
    BOOKING_API_URL                          = "https://api.example.com/booking"
    CHECKOUT_CONFIRM_API_URL                 = "https://nevioservicecenterapim.azure-api.net/checkoutConfirm"
    CHECKOUT_INITIATE_API_URL                = "/checkoutInitiate"
    FLIGHT_API_URL                           = "/shop/flights"
    MICROSOFT_PROVIDER_AUTHENTICATION_SECRET = "AeJ8Q~ahkiqp.I7n295lgTWx7L6sFryYhbp3sawb"
    NEXTAUTH_SECRET                          = "XskCaNL9CVX6fvQynihld8k6dzYCCnQtfT+YCjyjDGA="
    NEXTAUTH_URL                             = "https://sc-ui-archive-hub6d4hedsfjdkgg.eastus2-01.azurewebsites.net/"
    NEXT_PUBLIC_STRAPI_URL                   = "http://20.118.202.38:1337"
    ORDER_RETRIEVE_API_URL                   = "https://nevioservicecenterapim.azure-api.net//orders/retrieve"
    PASSENGER_API_URL                        = "/checkout/passengers"
    ROLE_PERMISSIONS_API_URL                 = "/rolepermissions"
    SEARCHPANEL_API_URL                      = "/searchpanel"
    TOKEN_API_URL                            = "/token"
    TOKEN_CLIENT_ID                          = "b30d32e6-141a-4376-b078-30737fba7af2"
    TOKEN_CLIENT_SECRET                      = "b4B8Q~2HBGztmY.BLLUTLQnpxZ4a2On93Lt6ucPo"
    TOKEN_GRANT_TYPE                         = "client_credentials"
    TOKEN_SCOPE                              = "api://863bea85-7f96-4062-b4d7-6cd72b7a0874/.default"
    WEBSITE_AUTH_AAD_ALLOWED_TENANTS         = "9bea73bd-2106-45da-a98b-33352e3784a3"
    XDT_MicrosoftApplicationInsights_Mode    = "default"
  }
  ftp_publish_basic_authentication_enabled = false
  https_only                               = true
  location                                 = "eastus2"
  name                                     = "SC-UI-Archive"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1522.id
  tags = {
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/SC-UI-Archive"
  }
  webdeploy_publish_basic_authentication_enabled = false
  auth_settings_v2 {
    auth_enabled           = true
    default_provider       = "azureactivedirectory"
    require_authentication = true
    active_directory_v2 {
      allowed_applications = ["63305545-2420-42ad-b592-c9a0a0947e32"]
      client_id            = "63305545-2420-42ad-b592-c9a0a0947e32"
      tenant_auth_endpoint = "https://sts.windows.net/9bea73bd-2106-45da-a98b-33352e3784a3/v2.0"
    }
    apple_v2 {
      client_id                  = ""
      client_secret_setting_name = ""
    }
    facebook_v2 {
      app_id                  = ""
      app_secret_setting_name = ""
    }
    github_v2 {
      client_id                  = ""
      client_secret_setting_name = ""
    }
    google_v2 {
      client_id                  = ""
      client_secret_setting_name = ""
    }
    login {
      logout_endpoint     = "/.auth/logout"
      token_store_enabled = true
    }
    microsoft_v2 {
      client_id                  = ""
      client_secret_setting_name = ""
    }
    twitter_v2 {
      consumer_key                 = ""
      consumer_secret_setting_name = ""
    }
  }
  site_config {
    always_on        = false
    app_command_line = "node server.js"
    ftps_state       = "FtpsOnly"
  }
  sticky_settings {
    app_setting_names = ["MICROSOFT_PROVIDER_AUTHENTICATION_SECRET"]
  }
}
resource "azurerm_app_service_custom_hostname_binding" "res-1538" {
  app_service_name    = "SC-UI-Archive"
  hostname            = "sc-ui-archive-hub6d4hedsfjdkgg.eastus2-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_web_app.res-1524
  ]
}
resource "azurerm_linux_web_app" "res-1539" {
  app_settings = {
    APPLICATIONINSIGHTS_CONNECTION_STRING      = "InstrumentationKey=bdd5497c-afca-462f-a632-b80dc9f02ab7;IngestionEndpoint=https://eastus2-3.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus2.livediagnostics.monitor.azure.com/;ApplicationId=1c55568b-aa32-4093-8a81-2d6217cc81bb"
    ApplicationInsightsAgent_EXTENSION_VERSION = "~3"
    XDT_MicrosoftApplicationInsights_Mode      = "default"
  }
  ftp_publish_basic_authentication_enabled       = false
  https_only                                     = true
  location                                       = "eastus2"
  name                                           = "SC-UI-MFE-Admin"
  resource_group_name                            = "amedeusnevio_rg"
  service_plan_id                                = azurerm_service_plan.res-1522.id
  webdeploy_publish_basic_authentication_enabled = false
  site_config {
    always_on                         = false
    ftps_state                        = "FtpsOnly"
    ip_restriction_default_action     = ""
    scm_ip_restriction_default_action = ""
  }
}
resource "azurerm_app_service_custom_hostname_binding" "res-1545" {
  app_service_name    = "SC-UI-MFE-Admin"
  hostname            = "sc-ui-mfe-admin-ccbmhpg4cfgrbpbj.eastus2-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_web_app.res-1539
  ]
}
resource "azurerm_linux_web_app" "res-1546" {
  app_settings = {
    APPLICATIONINSIGHTS_CONNECTION_STRING      = "InstrumentationKey=f0ac2b64-37a9-45e9-beb5-7db8a67f9295;IngestionEndpoint=https://eastus2-3.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus2.livediagnostics.monitor.azure.com/;ApplicationId=6b52bbab-3d9f-4b51-8c1d-741dc60bb137"
    ApplicationInsightsAgent_EXTENSION_VERSION = "~3"
    NEXT_PUBLIC_FLIGHT_API_URL                 = "https://func-shop-offer-dev-eus-fcb0gydkbfggethp.eastus-01.azurewebsites.net/shop/flights"
    XDT_MicrosoftApplicationInsights_Mode      = "default"
  }
  ftp_publish_basic_authentication_enabled = false
  https_only                               = true
  location                                 = "eastus2"
  name                                     = "SC-UI-MFE-FlightSearch"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1522.id
  tags = {
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/SC-UI-MFE-FlightSearch"
  }
  webdeploy_publish_basic_authentication_enabled = false
  site_config {
    always_on                         = false
    app_command_line                  = "node server.js"
    ftps_state                        = "FtpsOnly"
    ip_restriction_default_action     = ""
    scm_ip_restriction_default_action = ""
    cors {
      allowed_origins     = ["http://localhost:3000"]
      support_credentials = true
    }
  }
}
resource "azurerm_app_service_custom_hostname_binding" "res-1560" {
  app_service_name    = "SC-UI-MFE-FlightSearch"
  hostname            = "sc-ui-mfe-flightsearch-hsggd3hjb6feghhj.eastus2-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_web_app.res-1546
  ]
}
resource "azurerm_linux_web_app" "res-1561" {
  app_settings = {
    APPLICATIONINSIGHTS_CONNECTION_STRING      = "InstrumentationKey=6cac8e05-c0c6-46e0-b6fe-ab829549a6f8;IngestionEndpoint=https://eastus2-3.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus2.livediagnostics.monitor.azure.com/;ApplicationId=320c06aa-04d9-421e-a776-1855a3d9c12f"
    ApplicationInsightsAgent_EXTENSION_VERSION = "~3"
    XDT_MicrosoftApplicationInsights_Mode      = "default"
  }
  ftp_publish_basic_authentication_enabled = false
  https_only                               = true
  location                                 = "eastus2"
  name                                     = "SC-UI-MFE-ScratchPad"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1522.id
  tags = {
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/SC-UI-MFE-ScratchPad"
  }
  webdeploy_publish_basic_authentication_enabled = false
  site_config {
    always_on                         = false
    app_command_line                  = "node server.js"
    ftps_state                        = "FtpsOnly"
    ip_restriction_default_action     = ""
    scm_ip_restriction_default_action = ""
  }
}
resource "azurerm_app_service_custom_hostname_binding" "res-1568" {
  app_service_name    = "SC-UI-MFE-ScratchPad"
  hostname            = "sc-ui-mfe-scratchpad-gcfchhfxfdd6ewax.eastus2-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_web_app.res-1561
  ]
}
resource "azurerm_linux_web_app" "res-1569" {
  app_settings = {
    APPLICATIONINSIGHTS_CONNECTION_STRING      = "InstrumentationKey=d78a3d90-e079-43f1-8436-cb207eb12dd2;IngestionEndpoint=https://eastus2-3.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus2.livediagnostics.monitor.azure.com/;ApplicationId=b19c6d8f-4480-48fc-b99b-141628484aa2"
    ApplicationInsightsAgent_EXTENSION_VERSION = "~3"
    XDT_MicrosoftApplicationInsights_Mode      = "default"
  }
  ftp_publish_basic_authentication_enabled = false
  https_only                               = true
  location                                 = "eastus2"
  name                                     = "SC-UI-Shell-SeviceCenter"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1522.id
  tags = {
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/SC-UI-Shell-SeviceCenter"
  }
  webdeploy_publish_basic_authentication_enabled = false
  site_config {
    always_on                         = false
    app_command_line                  = "node server.js"
    ftps_state                        = "FtpsOnly"
    ip_restriction_default_action     = ""
    scm_ip_restriction_default_action = ""
  }
}
resource "azurerm_app_service_custom_hostname_binding" "res-1583" {
  app_service_name    = "SC-UI-Shell-SeviceCenter"
  hostname            = "sc-ui-shell-sevicecenter-e9dgfcajg8acaug0.eastus2-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_web_app.res-1569
  ]
}
resource "azurerm_linux_web_app" "res-1584" {
  app_settings = {
    AGENTID                                    = "789516691364"
    AIRLINECODE                                = "AY"
    API_BASE_URL                               = "https://nevioservicecenterapim.azure-api.net"
    APPLICATIONINSIGHTS_CONNECTION_STRING      = "InstrumentationKey=aec76187-c760-4e92-aeb6-e945903bcfc3;IngestionEndpoint=https://eastus2-3.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus2.livediagnostics.monitor.azure.com/;ApplicationId=6f8f9766-2375-4208-9f21-55ce81ce2591"
    APP_CONFIG_API_URL                         = "/appConfig"
    ApplicationInsightsAgent_EXTENSION_VERSION = "~3"
    BOOKING_API_URL                            = "https://api.example.com/booking"
    CHECKOUT_CONFIRM_API_URL                   = "/checkoutConfirm"
    CHECKOUT_INITIATE_API_URL                  = "/checkoutInitiate"
    FLIGHT_API_URL                             = "/shop/flights"
    MICROSOFT_PROVIDER_AUTHENTICATION_SECRET   = "lls8Q~QqgOTiXpMZU6pNr6GrraIOpesi2r2Y2b1R"
    NEXTAUTH_SECRET                            = "XskCaNL9CVX6fvQynihld8k6dzYCCnQtfT+YCjyjDGA="
    NEXTAUTH_URL                               = "https://servicecenter-ui-dccgatctdccbdbeu.eastus2-01.azurewebsites.net/"
    NEXT_PUBLIC_ENVIRONMENT                    = "Development"
    NEXT_PUBLIC_STRAPI_URL                     = "http://52.238.208.80:1338"
    ORDER_RETRIEVE_API_URL                     = "/orders/retrieve"
    PASSENGER_API_URL                          = "/checkout/passengers"
    ROLE_PERMISSIONS_API_URL                   = "/rolepermissions"
    SEARCHPANEL_API_URL                        = "/searchpanel"
    TOKEN_API_URL                              = "/token"
    TOKEN_CLIENT_ID                            = "b30d32e6-141a-4376-b078-30737fba7af2"
    TOKEN_CLIENT_SECRET                        = "b4B8Q~2HBGztmY.BLLUTLQnpxZ4a2On93Lt6ucPo"
    TOKEN_GRANT_TYPE                           = "client_credentials"
    TOKEN_SCOPE                                = "api://863bea85-7f96-4062-b4d7-6cd72b7a0874/.default"
    WEBSITE_AUTH_AAD_ALLOWED_TENANTS           = "9bea73bd-2106-45da-a98b-33352e3784a3"
    XDT_MicrosoftApplicationInsights_Mode      = "default"
  }
  ftp_publish_basic_authentication_enabled = false
  https_only                               = true
  location                                 = "eastus2"
  name                                     = "ServiceCenter-UI"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1522.id
  tags = {
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/ServiceCenter-UI"
  }
  webdeploy_publish_basic_authentication_enabled = false
  site_config {
    always_on                     = false
    app_command_line              = "node server.js"
    ftps_state                    = "FtpsOnly"
    ip_restriction_default_action = "Deny"
    scm_use_main_ip_restriction   = true
    ip_restriction {
      ip_address = "165.225.104.0/24"
      priority   = 40
    }
    ip_restriction {
      ip_address = "165.225.122.0/20"
      priority   = 50
    }
    ip_restriction {
      ip_address = "167.103.6.0/23"
      priority   = 50
    }
    ip_restriction {
      ip_address = "136.226.240.0/20"
      priority   = 70
    }
    ip_restriction {
      ip_address = "167.103.88.0/23"
      priority   = 70
    }
    ip_restriction {
      ip_address = "136.226.250.0/20"
      priority   = 70
    }
    ip_restriction {
      ip_address = "136.226.252.0/20"
      priority   = 80
    }
    ip_restriction {
      ip_address = "167.103.54.0/23"
      priority   = 80
    }
    ip_restriction {
      ip_address = "136.226.225.0/20"
      priority   = 80
    }
    ip_restriction {
      priority    = 100
      service_tag = "AzureCloud"
    }
    ip_restriction {
      ip_address = "167.103.21.30/20"
      priority   = 45
    }
  }
}
resource "azurerm_app_service_custom_hostname_binding" "res-1598" {
  app_service_name    = "ServiceCenter-UI"
  hostname            = "servicecenter-ui-dccgatctdccbdbeu.eastus2-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_web_app.res-1584
  ]
}
resource "azurerm_linux_web_app" "res-1599" {
  app_settings = {
    APPINSIGHTS_INSTRUMENTATIONKEY                  = "8b8231e1-63a9-4647-9592-9b5c9ba8aeed"
    APPINSIGHTS_PROFILERFEATURE_VERSION             = "disabled"
    APPINSIGHTS_SNAPSHOTFEATURE_VERSION             = "disabled"
    APPLICATIONINSIGHTS_CONNECTION_STRING           = "InstrumentationKey=8b8231e1-63a9-4647-9592-9b5c9ba8aeed;IngestionEndpoint=https://eastus2-3.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus2.livediagnostics.monitor.azure.com/;ApplicationId=34e272ae-f190-4c95-819a-108d10342b13"
    ApplicationInsightsAgent_EXTENSION_VERSION      = "disabled"
    DiagnosticServices_EXTENSION_VERSION            = "disabled"
    InstrumentationEngine_EXTENSION_VERSION         = "disabled"
    SnapshotDebugger_EXTENSION_VERSION              = "disabled"
    XDT_MicrosoftApplicationInsights_BaseExtensions = "disabled"
    XDT_MicrosoftApplicationInsights_Mode           = "default"
    XDT_MicrosoftApplicationInsights_PreemptSdk     = "disabled"
  }
  https_only          = true
  location            = "eastus2"
  name                = "cart-api"
  resource_group_name = "amedeusnevio_rg"
  service_plan_id     = azurerm_service_plan.res-1522.id
  tags = {
    "hidden-link: /app-insights-conn-string"         = "InstrumentationKey=8b8231e1-63a9-4647-9592-9b5c9ba8aeed;IngestionEndpoint=https://eastus2-3.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus2.livediagnostics.monitor.azure.com/;ApplicationId=34e272ae-f190-4c95-819a-108d10342b13"
    "hidden-link: /app-insights-instrumentation-key" = "8b8231e1-63a9-4647-9592-9b5c9ba8aeed"
    "hidden-link: /app-insights-resource-id"         = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/cart-api"
  }
  site_config {
    always_on                         = false
    app_command_line                  = "npm run start-server"
    ftps_state                        = "FtpsOnly"
    ip_restriction_default_action     = ""
    scm_ip_restriction_default_action = ""
  }
  sticky_settings {
    app_setting_names = ["APPINSIGHTS_INSTRUMENTATIONKEY", "APPLICATIONINSIGHTS_CONNECTION_STRING ", "APPINSIGHTS_PROFILERFEATURE_VERSION", "APPINSIGHTS_SNAPSHOTFEATURE_VERSION", "ApplicationInsightsAgent_EXTENSION_VERSION", "XDT_MicrosoftApplicationInsights_BaseExtensions", "DiagnosticServices_EXTENSION_VERSION", "InstrumentationEngine_EXTENSION_VERSION", "SnapshotDebugger_EXTENSION_VERSION", "XDT_MicrosoftApplicationInsights_Mode", "XDT_MicrosoftApplicationInsights_PreemptSdk", "APPLICATIONINSIGHTS_CONFIGURATION_CONTENT", "XDT_MicrosoftApplicationInsightsJava", "XDT_MicrosoftApplicationInsights_NodeJS"]
  }
}
resource "azurerm_app_service_custom_hostname_binding" "res-1609" {
  app_service_name    = "cart-api"
  hostname            = "cart-api-byc5dmhebnegd0gp.eastus2-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_web_app.res-1599
  ]
}
resource "azurerm_linux_web_app" "res-1610" {
  https_only          = true
  location            = "eastus2"
  name                = "federation"
  resource_group_name = "amedeusnevio_rg"
  service_plan_id     = azurerm_service_plan.res-1522.id
  site_config {
    always_on                         = false
    app_command_line                  = "npm run start-server"
    ftps_state                        = "FtpsOnly"
    ip_restriction_default_action     = ""
    scm_ip_restriction_default_action = ""
  }
}
resource "azurerm_app_service_custom_hostname_binding" "res-1617" {
  app_service_name    = "federation"
  hostname            = "federation-drfsbch9fya3fjhz.eastus2-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_web_app.res-1610
  ]
}
resource "azurerm_linux_function_app" "res-1618" {
  app_settings = {
    DEPLOYMENT_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=amedeusneviorgb9c6;AccountKey=IeYUMb/maHGJ4KKl5l9x5NCXislDFG/T153gaIR+wuQCbirTy2wuwUAuRuUmhKqjYQkMuEMFTaL8+AStH+Vdgg==;EndpointSuffix=core.windows.net"
  }
  builtin_logging_enabled                  = false
  client_certificate_mode                  = "Required"
  ftp_publish_basic_authentication_enabled = false
  functions_extension_version              = ""
  https_only                               = true
  location                                 = "eastus"
  name                                     = "func-Baggage-Policies-dev-eus"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1520.id
  storage_account_access_key               = "IeYUMb/maHGJ4KKl5l9x5NCXislDFG/T153gaIR+wuQCbirTy2wuwUAuRuUmhKqjYQkMuEMFTaL8+AStH+Vdgg=="
  storage_account_name                     = "amedeusneviorgb9c6"
  tags = {
    environment                              = "dev"
    "hidden-link: /app-insights-resource-id" = azurerm_application_insights.res-1735.id
  }
  webdeploy_publish_basic_authentication_enabled = false
  site_config {
    application_insights_connection_string = "InstrumentationKey=08234246-d98e-420e-b3ce-8666ec6d8916;IngestionEndpoint=https://eastus-8.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus.livediagnostics.monitor.azure.com/;ApplicationId=c1f972c8-c28a-42a9-adfe-5e48ed691b70"
    ftps_state                             = "FtpsOnly"
    ip_restriction_default_action          = ""
    scm_ip_restriction_default_action      = ""
    cors {
      allowed_origins = ["https://portal.azure.com"]
    }
  }
}
resource "azurerm_app_service_custom_hostname_binding" "res-1622" {
  app_service_name    = "func-Baggage-Policies-dev-eus"
  hostname            = "func-baggage-policies-dev-eus-ayejb0c3d0hkfyap.eastus-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_function_app.res-1618
  ]
}
resource "azurerm_linux_function_app" "res-1623" {
  app_settings = {
    AZURE_REDIS_CLIENT_ID                    = "50803981-2919-4c78-b582-f78a04b791b0"
    AZURE_REDIS_CLIENT_SECRET                = "xQ98Q~hJDLFt5beriJ8n1~yEizgiKuRJa_uXVbdp"
    AZURE_REDIS_SERVICE_PRINCIPAL_ID         = "f883459e-fa95-475d-b011-7c183625e701"
    AZURE_TENANT_ID                          = "9bea73bd-2106-45da-a98b-33352e3784a3"
    DATABASE_URL                             = "postgresql://amadeus:1@neviodb@nevioscdb.postgres.database.azure.com:5432/postgres"
    DEPLOYMENT_STORAGE_CONNECTION_STRING     = "DefaultEndpointsProtocol=https;AccountName=amedeusneviorgb6b0;AccountKey=3ms+WSj3VZHsbf2TgQYFRUjbI2L0xVlQmq02LxLS/plNAMi6UBN9r+SPyIaN4VlsmMDugmP2t5+X+AStHd/dSA==;EndpointSuffix=core.windows.net"
    KEY_VAULT_NAME                           = "amadeus-key-vault"
    MICROSOFT_PROVIDER_AUTHENTICATION_SECRET = "vfl8Q~KLH21qmfypAp1LxM6D5JMMn-v2J1nPqbD7"
    REDIS_HOST                               = "amadeus-rc.redis.cache.windows.net"
    WEBSITE_AUTH_AAD_ALLOWED_TENANTS         = "9bea73bd-2106-45da-a98b-33352e3784a3"
  }
  builtin_logging_enabled                  = false
  client_certificate_mode                  = "Required"
  ftp_publish_basic_authentication_enabled = false
  functions_extension_version              = ""
  https_only                               = true
  location                                 = "eastus"
  name                                     = "func-app-config-dev-eus"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1514.id
  storage_account_access_key               = "3ms+WSj3VZHsbf2TgQYFRUjbI2L0xVlQmq02LxLS/plNAMi6UBN9r+SPyIaN4VlsmMDugmP2t5+X+AStHd/dSA=="
  storage_account_name                     = "amedeusneviorgb6b0"
  tags = {
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/func-app-config-dev-eus"
  }
  virtual_network_subnet_id                      = azurerm_subnet.res-1292.id
  webdeploy_publish_basic_authentication_enabled = false
  auth_settings_v2 {
    require_authentication = true
    unauthenticated_action = "AllowAnonymous"
    active_directory_v2 {
      client_id            = ""
      tenant_auth_endpoint = ""
    }
    apple_v2 {
      client_id                  = ""
      client_secret_setting_name = ""
    }
    facebook_v2 {
      app_id                  = ""
      app_secret_setting_name = ""
    }
    github_v2 {
      client_id                  = ""
      client_secret_setting_name = ""
    }
    google_v2 {
      client_id                  = ""
      client_secret_setting_name = ""
    }
    login {
      token_store_enabled = true
    }
    microsoft_v2 {
      client_id                  = ""
      client_secret_setting_name = ""
    }
    twitter_v2 {
      consumer_key                 = ""
      consumer_secret_setting_name = ""
    }
  }
  identity {
    identity_ids = [azurerm_user_assigned_identity.res-1133.id, azurerm_user_assigned_identity.res-1154.id, azurerm_user_assigned_identity.res-1156.id]
    type         = "SystemAssigned, UserAssigned"
  }
  site_config {
    application_insights_connection_string = "InstrumentationKey=25a9506d-e086-41c4-ba25-2e084179651a;IngestionEndpoint=https://eastus-8.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus.livediagnostics.monitor.azure.com/;ApplicationId=af879cdd-c060-47c2-8a86-e5ea5c09b89a"
    ftps_state                             = "FtpsOnly"
    cors {
      allowed_origins     = ["http://localhost:3005", "https://portal.azure.com"]
      support_credentials = true
    }
  }
  sticky_settings {
    app_setting_names = ["MICROSOFT_PROVIDER_AUTHENTICATION_SECRET"]
  }
}
resource "azurerm_function_app_function" "res-1627" {
  config_json = jsonencode({
    bindings = [{
      authLevel = "anonymous"
      direction = "in"
      methods   = ["GET", "POST"]
      name      = "httpTrigger6ee56ee865"
      route     = "appConfig"
      type      = "httpTrigger"
      }, {
      direction = "out"
      name      = "$return"
      type      = "http"
    }]
    entryPoint        = ""
    functionDirectory = "/home/site/wwwroot/dist"
    language          = "node"
    name              = "graphqlApollo"
    scriptFile        = "index.js"
  })
  function_app_id = azurerm_linux_function_app.res-1623.id
  name            = "graphqlApollo"
}
resource "azurerm_app_service_custom_hostname_binding" "res-1628" {
  app_service_name    = "func-app-config-dev-eus"
  hostname            = "func-app-config-dev-eus-g6f6c3d6h4bdbhhv.eastus-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_function_app.res-1623
  ]
}
resource "azurerm_linux_function_app" "res-1629" {
  app_settings = {
    AMADEUS_API_KEY                      = "OtVPcTiHkGhJeEtIVCVOcGZHo57v"
    APP_ERROR_PREFIX                     = "SCCC"
    BASE_URL                             = "https://test.airlines.api.amadeus.com"
    DATABASE_URL                         = "postgresql://amadeus:1@neviodb@nevioscdb.postgres.database.azure.com:5432/postgres?schema=test_schema"
    DEPLOYMENT_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=amedeusneviorg9588;AccountKey=mZVt4vXPlrU7UWziU3/konkd/VvFUTryPOvaIev3hK842oxZBKigrq5ESapkeDzk3Qt7MRFhJjDD+AStD6FT3A==;EndpointSuffix=core.windows.net"
    ERRORS_DATABASE_URL                  = "postgresql://amadeus:1@neviodb@nevioscdb.postgres.database.azure.com:5432/postgres?schema=test_schema"
    ERROR_CACHE_TYPE                     = "in-memory"
    GENERIC_ERROR_PREFIX                 = "SCCM"
    KEY_VAULT_NAME                       = "amadeus-key-vault"
    ORDERCREATE_API_URL                  = "https://test.airlines.api.amadeus.com/v2/purchase/orders?cartId={cartId}"
    TOKEN_URL                            = "https://nevioservicecenterapim.azure-api.net/token/amadeus"
  }
  builtin_logging_enabled                  = false
  client_certificate_mode                  = "Required"
  ftp_publish_basic_authentication_enabled = false
  functions_extension_version              = ""
  https_only                               = true
  location                                 = "eastus"
  name                                     = "func-checkout-confirm-dev-eus"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1516.id
  storage_account_access_key               = "mZVt4vXPlrU7UWziU3/konkd/VvFUTryPOvaIev3hK842oxZBKigrq5ESapkeDzk3Qt7MRFhJjDD+AStD6FT3A=="
  storage_account_name                     = "amedeusneviorg9588"
  tags = {
    application                              = "checkout-confirm"
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/func-checkout-confirm-dev-eus"
  }
  virtual_network_subnet_id                      = azurerm_subnet.res-1292.id
  webdeploy_publish_basic_authentication_enabled = false
  identity {
    type = "SystemAssigned"
  }
  site_config {
    application_insights_connection_string = "InstrumentationKey=ebac8f0b-3830-4382-ad4e-f64d2165c623;IngestionEndpoint=https://eastus-8.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus.livediagnostics.monitor.azure.com/;ApplicationId=8cc27661-de01-4c54-8ba1-5dd7cbf174f9"
    ftps_state                             = "FtpsOnly"
    ip_restriction_default_action          = "Deny"
    cors {
      allowed_origins     = ["http://localhost:3006", "https://portal.azure.com"]
      support_credentials = true
    }
    ip_restriction {
      ip_address = "172.212.52.246/32"
      priority   = 980
    }
  }
}
resource "azurerm_function_app_function" "res-1633" {
  config_json = jsonencode({
    bindings = [{
      authLevel = "anonymous"
      direction = "in"
      methods   = ["GET", "POST"]
      name      = "httpTriggera8db4346e9"
      route     = "checkoutConfirm"
      type      = "httpTrigger"
      }, {
      direction = "out"
      name      = "$return"
      type      = "http"
    }]
    entryPoint        = ""
    functionDirectory = "/home/site/wwwroot/dist"
    language          = "node"
    name              = "checkoutConfirm"
    scriptFile        = "index.js"
  })
  function_app_id = azurerm_linux_function_app.res-1629.id
  name            = "checkoutConfirm"
}
resource "azurerm_app_service_custom_hostname_binding" "res-1634" {
  app_service_name    = "func-checkout-confirm-dev-eus"
  hostname            = "func-checkout-confirm-dev-eus-arctazgze7fjhgej.eastus-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_function_app.res-1629
  ]
}
resource "azurerm_linux_function_app" "res-1635" {
  app_settings = {
    AMADEUS_API_KEY                      = "OtVPcTiHkGhJeEtIVCVOcGZHo57v"
    APP_ERROR_PREFIX                     = "SCCI"
    BASE_URL                             = "https://test.airlines.api.amadeus.com"
    CARTUPDATE_API_URL                   = "https://test.airlines.api.amadeus.com/v2//shopping/carts/{cartId}/air-offers"
    CART_API_URL                         = "https://test.airlines.api.amadeus.com/v2/shopping/carts"
    DATABASE_URL                         = "postgresql://amadeus:1@neviodb@nevioscdb.postgres.database.azure.com:5432/postgres?schema=test_schema"
    DEPLOYMENT_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=amedeusneviorg8be0;AccountKey=pQTTDHb26oLgVQAgVm80JmNAAJ01IN1KrXTPuw7Lx1wTVg1JIfBMU3iQ79jUhezv8E0jYrNbhdYy+AStsK5iTg==;EndpointSuffix=core.windows.net"
    ERRORS_DATABASE_URL                  = "postgresql://amadeus:1@neviodb@nevioscdb.postgres.database.azure.com:5432/postgres?schema=test_schema"
    ERROR_CACHE_TYPE                     = "in-memory"
    GENERIC_ERROR_PREFIX                 = "SCCM"
    KEY_VAULT_NAME                       = "amadeus-key-vault"
    TOKEN_URL                            = "https://nevioservicecenterapim.azure-api.net/token/amadeus"
  }
  builtin_logging_enabled                  = false
  client_certificate_mode                  = "Required"
  ftp_publish_basic_authentication_enabled = false
  functions_extension_version              = ""
  https_only                               = true
  location                                 = "eastus"
  name                                     = "func-checkout-initiate-dev-eus"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1510.id
  storage_account_access_key               = "pQTTDHb26oLgVQAgVm80JmNAAJ01IN1KrXTPuw7Lx1wTVg1JIfBMU3iQ79jUhezv8E0jYrNbhdYy+AStsK5iTg=="
  storage_account_name                     = "amedeusneviorg8be0"
  tags = {
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/func-checkout-initiate-dev-eus"
  }
  virtual_network_subnet_id                      = azurerm_subnet.res-1292.id
  webdeploy_publish_basic_authentication_enabled = false
  identity {
    type = "SystemAssigned"
  }
  site_config {
    application_insights_connection_string = "InstrumentationKey=80f40401-0b78-4224-9ebd-fceebfbf1afe;IngestionEndpoint=https://eastus-8.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus.livediagnostics.monitor.azure.com/;ApplicationId=01b08a63-3607-439a-babf-db565d301671"
    ftps_state                             = "FtpsOnly"
    ip_restriction_default_action          = "Deny"
    cors {
      allowed_origins     = ["http://localhost:3000", "http://localhost:3004", "http://localhost:3006", "https://portal.azure.com"]
      support_credentials = true
    }
    ip_restriction {
      ip_address = "172.212.52.246/32"
      priority   = 1020
    }
  }
}
resource "azurerm_function_app_function" "res-1639" {
  config_json = jsonencode({
    bindings = [{
      authLevel = "anonymous"
      direction = "in"
      methods   = ["GET", "POST"]
      name      = "httpTriggere0dd4535a2"
      route     = "checkoutInitiate"
      type      = "httpTrigger"
      }, {
      direction = "out"
      name      = "$return"
      type      = "http"
    }]
    entryPoint        = ""
    functionDirectory = "/home/site/wwwroot/dist"
    language          = "node"
    name              = "checkoutInitiate"
    scriptFile        = "index.js"
  })
  function_app_id = azurerm_linux_function_app.res-1635.id
  name            = "checkoutInitiate"
}
resource "azurerm_app_service_custom_hostname_binding" "res-1640" {
  app_service_name    = "func-checkout-initiate-dev-eus"
  hostname            = "func-checkout-initiate-dev-eus-c5bac7bbbha5dheq.eastus-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_function_app.res-1635
  ]
}
resource "azurerm_linux_function_app" "res-1641" {
  app_settings = {
    APP_ERROR_PREFIX                     = "SCCP"
    BASE_URL                             = "https://test.airlines.api.amadeus.com"
    CHECKOUT_API_URL                     = "v2/shopping/carts"
    DATABASE_URL                         = "postgresql://amadeus:1@neviodb@nevioscdb.postgres.database.azure.com:5432/postgres?schema=test_schema"
    DEPLOYMENT_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=amedeusneviorgad30;AccountKey=kZawNGfxxjR4nkGGfo/3ZakzuEt4m/lQ/ZwnONg3X88UHAwa7flwzuwakA0tOcdD0UQOtaE6uExO+AStkpkIOA==;EndpointSuffix=core.windows.net"
    ERRORS_DATABASE_URL                  = "postgresql://amadeus:1@neviodb@nevioscdb.postgres.database.azure.com:5432/postgres?schema=test_schema"
    ERROR_CACHE_TYPE                     = "in-memory"
    GENERIC_ERROR_PREFIX                 = "SCCM"
    KEY_VAULT_NAME                       = "amadeus-key-vault"
    TOKEN_URL                            = "https://nevioservicecenterapim.azure-api.net/token/amadeus"
  }
  builtin_logging_enabled                  = false
  client_certificate_mode                  = "Required"
  ftp_publish_basic_authentication_enabled = false
  functions_extension_version              = ""
  https_only                               = true
  location                                 = "eastus"
  name                                     = "func-checkout-passengers-dev-eus"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1519.id
  storage_account_access_key               = "kZawNGfxxjR4nkGGfo/3ZakzuEt4m/lQ/ZwnONg3X88UHAwa7flwzuwakA0tOcdD0UQOtaE6uExO+AStkpkIOA=="
  storage_account_name                     = "amedeusneviorgad30"
  tags = {
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/func-checkout-passengers-dev-eus"
  }
  virtual_network_subnet_id                      = azurerm_subnet.res-1292.id
  webdeploy_publish_basic_authentication_enabled = false
  identity {
    type = "SystemAssigned"
  }
  site_config {
    application_insights_connection_string = "InstrumentationKey=562b0ff0-411c-46ae-b5a2-c7beaae25ceb;IngestionEndpoint=https://eastus-8.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus.livediagnostics.monitor.azure.com/;ApplicationId=9a940d6a-f0a4-47af-b2df-184c9b5913a3"
    ftps_state                             = "FtpsOnly"
    ip_restriction_default_action          = "Deny"
    cors {
      allowed_origins     = ["http://localhost:3000", "https://portal.azure.com"]
      support_credentials = true
    }
    ip_restriction {
      ip_address = "172.212.52.246/32"
      priority   = 789
    }
  }
}
resource "azurerm_function_app_function" "res-1645" {
  config_json = jsonencode({
    bindings = [{
      authLevel = "anonymous"
      direction = "in"
      methods   = ["GET", "POST"]
      name      = "httpTrigger942471f0eb"
      route     = "checkout/passengers"
      type      = "httpTrigger"
      }, {
      direction = "out"
      name      = "$return"
      type      = "http"
    }]
    entryPoint        = ""
    functionDirectory = "/home/site/wwwroot/dist"
    language          = "node"
    name              = "createPassengers"
    scriptFile        = "index.js"
  })
  function_app_id = azurerm_linux_function_app.res-1641.id
  name            = "createPassengers"
}
resource "azurerm_app_service_custom_hostname_binding" "res-1646" {
  app_service_name    = "func-checkout-passengers-dev-eus"
  hostname            = "func-checkout-passengers-dev-eus-ekf0erdhcxbcezfk.eastus-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_function_app.res-1641
  ]
}
resource "azurerm_linux_function_app" "res-1647" {
  app_settings = {
    BASE_URL                             = "https://test.airlines.api.amadeus.com"
    CART_UPDATE_API_URL                  = "https://test.airlines.api.amadeus.com/v2//shopping/carts/{cartId}/air-offers"
    DATABASE_URL                         = "postgresql://amadeus:1@neviodb@nevioscdb.postgres.database.azure.com:5432/postgres?schema=test_schema"
    DEPLOYMENT_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=amedeusneviorg99e3;AccountKey=tX6dSn2w8QvD18TofA/pmS9EgdR2Mehyn5fXI7P5RkxNWz7LlGed38Q9Ej4HUU9Nl72vyIB81QFL+AStmIsDWg==;EndpointSuffix=core.windows.net"
    KEY_VAULT_NAME                       = "KEY_VAULT_NAME"
    OFFERCART_DELETE_API_URL             = "https://test.airlines.api.amadeus.com/v2/shopping/carts/{cartId}/air-offers/{airOfferId}"
    OFFERCART_RETRIEVE_API_URL           = "https://test.airlines.api.amadeus.com/v2//shopping/carts/{cartId}/air-offers"
    TOKEN_URL                            = "https://nevioservicecenterapim.azure-api.net/token/amadeus"
  }
  builtin_logging_enabled                  = false
  client_certificate_mode                  = "Required"
  ftp_publish_basic_authentication_enabled = false
  functions_extension_version              = ""
  https_only                               = true
  location                                 = "eastus"
  name                                     = "func-checkout-update-dev-eus"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1513.id
  storage_account_access_key               = "tX6dSn2w8QvD18TofA/pmS9EgdR2Mehyn5fXI7P5RkxNWz7LlGed38Q9Ej4HUU9Nl72vyIB81QFL+AStmIsDWg=="
  storage_account_name                     = "amedeusneviorg99e3"
  tags = {
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/func-checkout-update-dev-eus"
  }
  virtual_network_subnet_id                      = azurerm_subnet.res-1292.id
  webdeploy_publish_basic_authentication_enabled = false
  identity {
    type = "SystemAssigned"
  }
  site_config {
    application_insights_connection_string = "InstrumentationKey=b5fff874-42d6-4386-89e5-2db829ce8351;IngestionEndpoint=https://eastus-8.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus.livediagnostics.monitor.azure.com/;ApplicationId=7b084375-0bb2-4fac-b55c-4f5a174c6991"
    ftps_state                             = "FtpsOnly"
    ip_restriction_default_action          = "Deny"
    cors {
      allowed_origins = ["https://portal.azure.com"]
    }
    ip_restriction {
      ip_address = "172.212.52.246/32"
      priority   = 788
    }
  }
}
resource "azurerm_function_app_function" "res-1651" {
  config_json = jsonencode({
    bindings = [{
      authLevel = "anonymous"
      direction = "in"
      methods   = ["GET", "POST"]
      name      = "httpTriggere609f63001"
      route     = "checkout/update"
      type      = "httpTrigger"
      }, {
      direction = "out"
      name      = "$return"
      type      = "http"
    }]
    entryPoint        = ""
    functionDirectory = "/home/site/wwwroot/dist"
    language          = "node"
    name              = "graphqlApollo"
    scriptFile        = "index.js"
  })
  function_app_id = azurerm_linux_function_app.res-1647.id
  name            = "graphqlApollo"
}
resource "azurerm_app_service_custom_hostname_binding" "res-1652" {
  app_service_name    = "func-checkout-update-dev-eus"
  hostname            = "func-checkout-update-dev-eus-bhcycreuacdvftgz.eastus-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_function_app.res-1647
  ]
}
resource "azurerm_linux_function_app" "res-1653" {
  app_settings = {
    BASE_URL                             = "https://your-api.com"
    DEPLOYMENT_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=amedeusneviorga71f;AccountKey=W1ts0kc9XdUWzf8JFKESDDpg1eXMHZc4bNSDMwvojFw1Pwat4mKWqFwUxLiaZ1BbtSm1IxTdoKAp+ASt+FAsNw==;EndpointSuffix=core.windows.net"
    FARE_CONDITION_API_URL               = "/fare/conditions"
    KEY_VAULT_NAME                       = "amadeus-key-vault"
    USE_MOCK                             = "true"
  }
  builtin_logging_enabled                  = false
  client_certificate_mode                  = "Required"
  ftp_publish_basic_authentication_enabled = false
  functions_extension_version              = ""
  https_only                               = true
  location                                 = "eastus"
  name                                     = "func-fare-condition-dev-eus"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1515.id
  storage_account_access_key               = "W1ts0kc9XdUWzf8JFKESDDpg1eXMHZc4bNSDMwvojFw1Pwat4mKWqFwUxLiaZ1BbtSm1IxTdoKAp+ASt+FAsNw=="
  storage_account_name                     = "amedeusneviorga71f"
  tags = {
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/func-fare-condition-dev-eus"
  }
  virtual_network_subnet_id                      = azurerm_subnet.res-1292.id
  webdeploy_publish_basic_authentication_enabled = false
  identity {
    type = "SystemAssigned"
  }
  site_config {
    application_insights_connection_string = "InstrumentationKey=0ba3a479-78df-4b29-a7a6-89ec5ba5fbf1;IngestionEndpoint=https://eastus-8.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus.livediagnostics.monitor.azure.com/;ApplicationId=e41105a5-446e-4c8f-b7e3-29ba644ab909"
    ftps_state                             = "FtpsOnly"
    ip_restriction_default_action          = "Deny"
    cors {
      allowed_origins = ["https://portal.azure.com"]
    }
    ip_restriction {
      ip_address = "172.212.52.246/32"
      priority   = 989
    }
  }
}
resource "azurerm_function_app_function" "res-1657" {
  config_json = jsonencode({
    bindings = [{
      authLevel = "anonymous"
      direction = "in"
      methods   = ["GET", "POST"]
      name      = "httpTrigger6d65b7aae3"
      route     = "air/fareconditions"
      type      = "httpTrigger"
      }, {
      direction = "out"
      name      = "$return"
      type      = "http"
    }]
    entryPoint        = ""
    functionDirectory = "/home/site/wwwroot/dist"
    language          = "node"
    name              = "graphqlApollo"
    scriptFile        = "index.js"
  })
  function_app_id = azurerm_linux_function_app.res-1653.id
  name            = "graphqlApollo"
}
resource "azurerm_app_service_custom_hostname_binding" "res-1658" {
  app_service_name    = "func-fare-condition-dev-eus"
  hostname            = "func-fare-condition-dev-eus-gmg3c4dgf7fvf2ea.eastus-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_function_app.res-1653
  ]
}
resource "azurerm_linux_function_app" "res-1659" {
  app_settings = {
    DEPLOYMENT_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=amedeusneviorg95f3;AccountKey=yNbs+uoHZzC1behiQIjHmkpmnNhtENFMu/Vb70mqJxzQ6u/p+ifs7Z3e6vwNM3mDKRKB7YNBQ6Gi+ASt2wp5vg==;EndpointSuffix=core.windows.net"
    KEY_VAULT_NAME                       = "amadeus-key-vault"
  }
  builtin_logging_enabled                  = false
  client_certificate_mode                  = "Required"
  ftp_publish_basic_authentication_enabled = false
  functions_extension_version              = ""
  https_only                               = true
  location                                 = "eastus"
  name                                     = "func-payment-dev-eus"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1523.id
  storage_account_access_key               = "yNbs+uoHZzC1behiQIjHmkpmnNhtENFMu/Vb70mqJxzQ6u/p+ifs7Z3e6vwNM3mDKRKB7YNBQ6Gi+ASt2wp5vg=="
  storage_account_name                     = "amedeusneviorg95f3"
  tags = {
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/func-payment-dev-eus"
  }
  virtual_network_subnet_id                      = azurerm_subnet.res-1292.id
  webdeploy_publish_basic_authentication_enabled = false
  identity {
    type = "SystemAssigned"
  }
  site_config {
    application_insights_connection_string = "InstrumentationKey=b2e77098-d7bb-4c40-97dc-c31cd51e2e2c;IngestionEndpoint=https://eastus-8.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus.livediagnostics.monitor.azure.com/;ApplicationId=ad1f5e8f-60ad-4942-8315-92b6340fd814"
    ftps_state                             = "FtpsOnly"
    ip_restriction_default_action          = "Deny"
    cors {
      allowed_origins = ["https://portal.azure.com"]
    }
    ip_restriction {
      ip_address = "172.212.52.246/32"
      priority   = 2202
    }
  }
}
resource "azurerm_function_app_function" "res-1663" {
  config_json = jsonencode({
    bindings = [{
      authLevel = "anonymous"
      direction = "in"
      methods   = ["GET", "POST"]
      name      = "httpTriggerbc0a974383"
      route     = "payment/process"
      type      = "httpTrigger"
      }, {
      direction = "out"
      name      = "$return"
      type      = "http"
    }]
    entryPoint        = ""
    functionDirectory = "/home/site/wwwroot/dist"
    language          = "node"
    name              = "graphqlApollo"
    scriptFile        = "index.js"
  })
  function_app_id = azurerm_linux_function_app.res-1659.id
  name            = "graphqlApollo"
}
resource "azurerm_app_service_custom_hostname_binding" "res-1664" {
  app_service_name    = "func-payment-dev-eus"
  hostname            = "func-payment-dev-eus-c2fhetdzahagf0au.eastus-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_function_app.res-1659
  ]
}
resource "azurerm_linux_function_app" "res-1665" {
  app_settings = {
    DATABASE_URL                         = "postgresql://amadeus:1@neviodb@nevioscdb.postgres.database.azure.com:5432/postgres?schema=test_schema"
    DEPLOYMENT_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=amedeusneviorgac41;AccountKey=I9RNF20nPMBJcPBIyR89RSwV1dgiAbQ0TGZO4idzFo7nmJsUX/pj3GRqPcGhzMbIHG7N4dHBilR8+AStnYF6MQ==;EndpointSuffix=core.windows.net"
    KEY_VAULT_NAME                       = "amadeus-key-vault"
  }
  builtin_logging_enabled                  = false
  client_certificate_mode                  = "Required"
  ftp_publish_basic_authentication_enabled = false
  functions_extension_version              = ""
  https_only                               = true
  location                                 = "eastus"
  name                                     = "func-rbac-dev-eus"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1518.id
  storage_account_access_key               = "I9RNF20nPMBJcPBIyR89RSwV1dgiAbQ0TGZO4idzFo7nmJsUX/pj3GRqPcGhzMbIHG7N4dHBilR8+AStnYF6MQ=="
  storage_account_name                     = "amedeusneviorgac41"
  tags = {
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/func-rbac-dev-eus"
  }
  virtual_network_subnet_id                      = azurerm_subnet.res-1292.id
  webdeploy_publish_basic_authentication_enabled = false
  identity {
    type = "SystemAssigned"
  }
  site_config {
    application_insights_connection_string = "InstrumentationKey=c4e31f1e-ea9c-438a-9b12-ea7a1fd60677;IngestionEndpoint=https://eastus-8.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus.livediagnostics.monitor.azure.com/;ApplicationId=5b37ab46-029e-4f2c-93dd-98c098dcd0ae"
    ftps_state                             = "FtpsOnly"
    cors {
      allowed_origins = ["https://portal.azure.com"]
    }
  }
}
resource "azurerm_function_app_function" "res-1669" {
  config_json = jsonencode({
    bindings = [{
      authLevel = "anonymous"
      direction = "in"
      methods   = ["GET", "POST"]
      name      = "httpTrigger21b379395b"
      properties = {
        supportsDeferredBinding = "false"
      }
      route = "rolepermissions"
      type  = "httpTrigger"
      }, {
      direction = "out"
      name      = "$return"
      type      = "http"
    }]
    entryPoint        = ""
    functionDirectory = "/home/site/wwwroot/dist"
    language          = "node"
    name              = "graphqlApollo"
    scriptFile        = "index.js"
  })
  function_app_id = azurerm_linux_function_app.res-1665.id
  name            = "graphqlApollo"
}
resource "azurerm_app_service_custom_hostname_binding" "res-1670" {
  app_service_name    = "func-rbac-dev-eus"
  hostname            = "func-rbac-dev-eus-cyhdgbhrgqaehybq.eastus-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_function_app.res-1665
  ]
}
resource "azurerm_linux_function_app" "res-1671" {
  app_settings = {
    AZURE_REDIS_SERVICE_PRINCIPAL_ID     = "f883459e-fa95-475d-b011-7c183625e701"
    BASE_URL                             = "https://test.airlines.api.amadeus.com"
    CACHE_EXPIRE_SECONDS                 = "86400"
    DATABASE_URL                         = "postgresql://amadeus:1@neviodb@nevioscdb.postgres.database.azure.com:5432/postgres?schema=test_schema"
    DEPLOYMENT_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=amedeusneviorgbb71;AccountKey=Ba0K70RrkHV3IPYdPBi/1lltjDZ2SXy7xSXg2OsVGqlQ867Uy6/q/3iNf4V5iSTMswmnQPRAuq4i+ASt7lLwNg==;EndpointSuffix=core.windows.net"
    KEY_VAULT_NAME                       = "amadeus-key-vault"
    REDIS_HOST                           = "amadeus-rc.redis.cache.windows.net"
    RETRIEVE_ORDER_API_URL               = "/v2/purchase/orders/{orderRecLocId}?showOrderEligibilities="
    TOKEN_URL                            = "https://nevioservicecenterapim.azure-api.net/token/amadeus"
  }
  builtin_logging_enabled                  = false
  client_certificate_mode                  = "Required"
  ftp_publish_basic_authentication_enabled = false
  functions_extension_version              = ""
  https_only                               = true
  location                                 = "eastus"
  name                                     = "func-retrieve-order-dev-eus"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1521.id
  storage_account_access_key               = "Ba0K70RrkHV3IPYdPBi/1lltjDZ2SXy7xSXg2OsVGqlQ867Uy6/q/3iNf4V5iSTMswmnQPRAuq4i+ASt7lLwNg=="
  storage_account_name                     = "amedeusneviorgbb71"
  tags = {
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/func-retrieve-order-dev-eus"
  }
  virtual_network_subnet_id                      = azurerm_subnet.res-1292.id
  webdeploy_publish_basic_authentication_enabled = false
  identity {
    type = "SystemAssigned"
  }
  site_config {
    application_insights_connection_string = "InstrumentationKey=70b81ca4-a7de-4362-8bba-221b6865f2b6;IngestionEndpoint=https://eastus-8.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus.livediagnostics.monitor.azure.com/;ApplicationId=d0c588ff-87c2-44b6-a799-67ad0122e969"
    ftps_state                             = "FtpsOnly"
    ip_restriction_default_action          = "Deny"
    cors {
      allowed_origins     = ["http://localhost:3006", "https://portal.azure.com"]
      support_credentials = true
    }
    ip_restriction {
      ip_address = "172.212.52.246/32"
      priority   = 9888
    }
  }
}
resource "azurerm_function_app_function" "res-1675" {
  config_json = jsonencode({
    bindings = [{
      authLevel = "anonymous"
      direction = "in"
      methods   = ["GET", "POST"]
      name      = "httpTrigger32b9de9991"
      route     = "orders/retrieve"
      type      = "httpTrigger"
      }, {
      direction = "out"
      name      = "$return"
      type      = "http"
    }]
    entryPoint        = ""
    functionDirectory = "/home/site/wwwroot/dist"
    language          = "node"
    name              = "retrieveOrder"
    scriptFile        = "index.js"
  })
  function_app_id = azurerm_linux_function_app.res-1671.id
  name            = "retrieveOrder"
}
resource "azurerm_app_service_custom_hostname_binding" "res-1676" {
  app_service_name    = "func-retrieve-order-dev-eus"
  hostname            = "func-retrieve-order-dev-eus-gtf8cddeggchh2gd.eastus-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_function_app.res-1671
  ]
}
resource "azurerm_linux_function_app" "res-1677" {
  app_settings = {
    AZURE_REDIS_SERVICE_PRINCIPAL_ID     = "f883459e-fa95-475d-b011-7c183625e701"
    CACHE_EXPIRE_SECONDS                 = "86400"
    DATABASE_URL                         = "postgresql://amadeus:1@neviodb@nevioscdb.postgres.database.azure.com:5432/postgres?schema=test_schema"
    DEPLOYMENT_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=amedeusneviorgb7c4;AccountKey=rmofvxjhAdZj4uwQehG4sq+E2NBU4sjIZ5+0ZAS4yosje+mQ74vJMlXbmLD5gzti3LBucUK9w6Bt+ASt2+JrJw==;EndpointSuffix=core.windows.net"
    KEY_VAULT_NAME                       = "amadeus-key-vault"
    REDIS_HOST                           = "amadeus-rc.redis.cache.windows.net"
  }
  builtin_logging_enabled     = false
  client_certificate_mode     = "Required"
  functions_extension_version = ""
  https_only                  = true
  location                    = "eastus"
  name                        = "func-searchpanel-dev-eus"
  resource_group_name         = "amedeusnevio_rg"
  service_plan_id             = azurerm_service_plan.res-1509.id
  storage_account_access_key  = "rmofvxjhAdZj4uwQehG4sq+E2NBU4sjIZ5+0ZAS4yosje+mQ74vJMlXbmLD5gzti3LBucUK9w6Bt+ASt2+JrJw=="
  storage_account_name        = "amedeusneviorgb7c4"
  tags = {
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/func-searchpanel-dev-eus"
  }
  virtual_network_subnet_id = azurerm_subnet.res-1292.id
  identity {
    type = "SystemAssigned"
  }
  site_config {
    application_insights_connection_string = "InstrumentationKey=6eb4636b-8cab-483a-86e4-91d86c66e64a;IngestionEndpoint=https://eastus-8.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus.livediagnostics.monitor.azure.com/;ApplicationId=90ff49d7-cc06-475c-858e-76b99d008d11"
    ftps_state                             = "FtpsOnly"
    http2_enabled                          = true
    ip_restriction_default_action          = "Deny"
    cors {
      allowed_origins     = ["https://portal.azure.com", "https://sc-ui-archive-hub6d4hedsfjdkgg.eastus2-01.azurewebsites.net"]
      support_credentials = true
    }
    ip_restriction {
      ip_address = "172.212.52.246/32"
      priority   = 888
    }
  }
}
resource "azurerm_function_app_function" "res-1681" {
  config_json = jsonencode({
    bindings = [{
      authLevel = "anonymous"
      direction = "in"
      methods   = ["GET", "POST"]
      name      = "httpTrigger693f82c6ce"
      properties = {
        supportsDeferredBinding = "false"
      }
      route = "searchpanel"
      type  = "httpTrigger"
      }, {
      direction = "out"
      name      = "$return"
      type      = "http"
    }]
    entryPoint        = ""
    functionDirectory = "/home/site/wwwroot/dist"
    language          = "node"
    name              = "graphqlApollo"
    scriptFile        = "index.js"
  })
  function_app_id = azurerm_linux_function_app.res-1677.id
  name            = "graphqlApollo"
}
resource "azurerm_app_service_custom_hostname_binding" "res-1682" {
  app_service_name    = "func-searchpanel-dev-eus"
  hostname            = "func-searchpanel-dev-eus-agg6hzdgbpdug6ea.eastus-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_function_app.res-1677
  ]
}
resource "azurerm_linux_function_app" "res-1683" {
  app_settings = {
    AZURE_REDIS_SERVICE_PRINCIPAL_ID     = "f883459e-fa95-475d-b011-7c183625e701"
    BASE_URL                             = "https://test.airlines.api.amadeus.com"
    CACHE_EXPIRE_SECONDS                 = "86400"
    DATABASE_URL                         = "postgresql://amadeus:1@neviodb@nevioscdb.postgres.database.azure.com:5432/postgres?schema=test_schema"
    DEPLOYMENT_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=amedeusneviorgb62e;AccountKey=I7zfR2QuTvgzp5KX6sLaacqGGjoElj+29rLu7loSasl7LFuWdHWwkjF32sccoXi6QS4UtTXpYAjH+AStkOjjVQ==;EndpointSuffix=core.windows.net"
    REDIS_HOST                           = "amadeus-rc.redis.cache.windows.net"
    TOKEN_URL                            = "https://apim-test-ay-fra-sc.azure-api.net/token/amadeus"
  }
  builtin_logging_enabled                  = false
  client_certificate_mode                  = "Required"
  ftp_publish_basic_authentication_enabled = false
  functions_extension_version              = ""
  https_only                               = true
  location                                 = "eastus"
  name                                     = "func-seat-map-dev-eus"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1512.id
  storage_account_access_key               = "I7zfR2QuTvgzp5KX6sLaacqGGjoElj+29rLu7loSasl7LFuWdHWwkjF32sccoXi6QS4UtTXpYAjH+AStkOjjVQ=="
  storage_account_name                     = "amedeusneviorgb62e"
  tags = {
    environment                              = "development"
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/func-seat-map-dev-eus"
  }
  webdeploy_publish_basic_authentication_enabled = false
  site_config {
    application_insights_connection_string = "InstrumentationKey=689b9f43-9a4d-4965-ad72-e729df9d27f8;IngestionEndpoint=https://eastus-8.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus.livediagnostics.monitor.azure.com/;ApplicationId=d49fa9f8-80be-406e-b3a7-8bf4cbcfc0b9"
    ftps_state                             = "FtpsOnly"
    ip_restriction_default_action          = ""
    scm_ip_restriction_default_action      = ""
    cors {
      allowed_origins = ["https://portal.azure.com"]
    }
  }
}
resource "azurerm_function_app_function" "res-1687" {
  config_json = jsonencode({
    bindings = [{
      authLevel = "anonymous"
      direction = "in"
      methods   = ["GET", "POST"]
      name      = "httpTriggerf6d6931751"
      route     = "api/seatmap"
      type      = "httpTrigger"
      }, {
      direction = "out"
      name      = "$return"
      type      = "http"
    }]
    entryPoint        = ""
    functionDirectory = "/home/site/wwwroot/dist"
    language          = "node"
    name              = "seatmap"
    scriptFile        = "index.js"
  })
  function_app_id = azurerm_linux_function_app.res-1683.id
  name            = "seatmap"
}
resource "azurerm_app_service_custom_hostname_binding" "res-1688" {
  app_service_name    = "func-seat-map-dev-eus"
  hostname            = "func-seat-map-dev-eus-eggjhjcjbpa6d7dz.eastus-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_function_app.res-1683
  ]
}
resource "azurerm_linux_function_app" "res-1689" {
  app_settings = {
    AZURE_REDIS_SERVICE_PRINCIPAL_ID     = "f883459e-fa95-475d-b011-7c183625e701"
    BASE_URL                             = "https://test.airlines.api.amadeus.com"
    CACHE_EXPIRE_SECONDS                 = "86400"
    DATABASE_URL                         = "postgresql://amadeus:1@neviodb@nevioscdb.postgres.database.azure.com:5432/postgres?schema=test_schema"
    DEPLOYMENT_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=amedeusneviorg9b75;AccountKey=tYPLfwnI6ZaVijXSoe0XHa7sNqLbr6n/yUwbpXJ6In0M9m/5RNgquv1sZvx5ql3p+V6K5MSf0PYR+ASth6zXnw==;EndpointSuffix=core.windows.net"
    FLIGHT_BOUND_API_URL                 = "/v2/search/air-bounds"
    KEY_VAULT_NAME                       = "amadeus-key-vault"
    REDIS_HOST                           = "amadeus-rc.redis.cache.windows.net"
    TOKEN_URL                            = "https://nevioservicecenterapim.azure-api.net/token/amadeus"
  }
  builtin_logging_enabled                  = false
  client_certificate_mode                  = "Required"
  ftp_publish_basic_authentication_enabled = false
  functions_extension_version              = ""
  https_only                               = true
  location                                 = "eastus"
  name                                     = "func-shop-offer-dev-eus"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1511.id
  storage_account_access_key               = "tYPLfwnI6ZaVijXSoe0XHa7sNqLbr6n/yUwbpXJ6In0M9m/5RNgquv1sZvx5ql3p+V6K5MSf0PYR+ASth6zXnw=="
  storage_account_name                     = "amedeusneviorg9b75"
  tags = {
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/func-shop-offer-dev-eus"
  }
  virtual_network_subnet_id                      = azurerm_subnet.res-1292.id
  webdeploy_publish_basic_authentication_enabled = false
  identity {
    type = "SystemAssigned"
  }
  site_config {
    application_insights_connection_string = "InstrumentationKey=437cfb50-f6a2-469e-9482-8b33ebdb771a;IngestionEndpoint=https://eastus-8.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus.livediagnostics.monitor.azure.com/;ApplicationId=0d3dbbd0-ffb2-43f9-ae6b-c922d4990e54"
    ftps_state                             = "FtpsOnly"
    ip_restriction_default_action          = "Deny"
    cors {
      allowed_origins     = ["http://localhost:3000", "http://localhost:3001", "https://*.vusercontent.net", "https://portal.azure.com", "https://v0.dev"]
      support_credentials = true
    }
    ip_restriction {
      ip_address = "172.212.52.246/32"
      priority   = 300
    }
  }
}
resource "azurerm_function_app_function" "res-1693" {
  config_json = jsonencode({
    bindings = [{
      authLevel = "anonymous"
      direction = "in"
      methods   = ["GET", "POST"]
      name      = "httpTrigger7a0150705a"
      route     = "shop/flights"
      type      = "httpTrigger"
      }, {
      direction = "out"
      name      = "$return"
      type      = "http"
    }]
    entryPoint        = ""
    functionDirectory = "/home/site/wwwroot/dist"
    language          = "node"
    name              = "graphqlApollo"
    scriptFile        = "index.js"
  })
  function_app_id = azurerm_linux_function_app.res-1689.id
  name            = "graphqlApollo"
}
resource "azurerm_app_service_custom_hostname_binding" "res-1694" {
  app_service_name    = "func-shop-offer-dev-eus"
  hostname            = "func-shop-offer-dev-eus-fcb0gydkbfggethp.eastus-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_function_app.res-1689
  ]
}
resource "azurerm_linux_function_app" "res-1695" {
  app_settings = {
    AUTH_URL                             = "https://login.microsoftonline.com/9bea73bd-2106-45da-a98b-33352e3784a3/oauth2/v2.0/token"
    BASE_URL                             = "https://test.airlines.api.amadeus.com"
    DATABASE_URL                         = "postgresql://amadeus:1@neviodb@nevioscdb.postgres.database.azure.com:5432/postgres?schema=token&connection_limit=2"
    DEPLOYMENT_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=amedeusneviorgaaff;AccountKey=Nq1ic5kj3Q9T1Ecyab3qmwIifUejRafXNxmjtKhpN1OBrqTABth4ErENVYzjRaR4CuzCeVfCEkda+ASts2I9tQ==;EndpointSuffix=core.windows.net"
    GRANT_TYPE                           = "client_credentials"
    KEY_VAULT_NAME                       = "amadeus-key-vault"
  }
  builtin_logging_enabled                  = false
  client_certificate_mode                  = "Required"
  ftp_publish_basic_authentication_enabled = false
  functions_extension_version              = ""
  https_only                               = true
  location                                 = "eastus"
  name                                     = "func-token-dev-eus"
  resource_group_name                      = "amedeusnevio_rg"
  service_plan_id                          = azurerm_service_plan.res-1517.id
  storage_account_access_key               = "Nq1ic5kj3Q9T1Ecyab3qmwIifUejRafXNxmjtKhpN1OBrqTABth4ErENVYzjRaR4CuzCeVfCEkda+ASts2I9tQ=="
  storage_account_name                     = "amedeusneviorgaaff"
  tags = {
    "hidden-link: /app-insights-resource-id" = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/microsoft.insights/components/func-token-dev-eus202507101214"
  }
  virtual_network_subnet_id                      = azurerm_subnet.res-1292.id
  webdeploy_publish_basic_authentication_enabled = false
  identity {
    type = "SystemAssigned"
  }
  site_config {
    api_management_api_id                  = "/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.ApiManagement/service/NevioServiceCenterAPIM/apis/func-token-dev-eus"
    application_insights_connection_string = "InstrumentationKey=48c8b8c3-51dd-4bb9-bbaf-6657c4899272;IngestionEndpoint=https://eastus-8.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus.livediagnostics.monitor.azure.com/;ApplicationId=5f4ff9cc-aa4f-4e82-adcb-2f9cb9009290"
    ftps_state                             = "FtpsOnly"
    ip_restriction_default_action          = "Deny"
    cors {
      allowed_origins     = ["http://localhost:3000", "http://localhost:3001", "https://portal.azure.com"]
      support_credentials = true
    }
    ip_restriction {
      ip_address = "172.212.52.246/32"
      priority   = 2200
    }
  }
}
resource "azurerm_function_app_function" "res-1699" {
  config_json = jsonencode({
    bindings = [{
      authLevel = "anonymous"
      direction = "in"
      methods   = ["POST"]
      name      = "httpTrigger3cd577e69a"
      route     = "token/amadeus"
      type      = "httpTrigger"
      }, {
      direction = "out"
      name      = "$return"
      type      = "http"
    }]
    entryPoint        = ""
    functionDirectory = "/home/site/wwwroot/dist"
    language          = "node"
    name              = "amadeusTokenHandler"
    scriptFile        = "index.js"
  })
  function_app_id = azurerm_linux_function_app.res-1695.id
  name            = "amadeusTokenHandler"
}
resource "azurerm_function_app_function" "res-1700" {
  config_json = jsonencode({
    bindings = [{
      authLevel = "anonymous"
      direction = "in"
      methods   = ["POST"]
      name      = "httpTriggerf30524ce09"
      route     = "token"
      type      = "httpTrigger"
      }, {
      direction = "out"
      name      = "$return"
      type      = "http"
    }]
    entryPoint        = ""
    functionDirectory = "/home/site/wwwroot/dist"
    language          = "node"
    name              = "tokenHandler"
    scriptFile        = "index.js"
  })
  function_app_id = azurerm_linux_function_app.res-1695.id
  name            = "tokenHandler"
}
resource "azurerm_app_service_custom_hostname_binding" "res-1701" {
  app_service_name    = "func-token-dev-eus"
  hostname            = "func-token-dev-eus-a2heagh0gzhma6ct.eastus-01.azurewebsites.net"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_linux_function_app.res-1695
  ]
}
resource "azurerm_static_web_app" "res-1702" {
  location            = "eastus2"
  name                = "SC-UI-FlightSearch"
  repository_branch   = "main"
  repository_url      = "https://github.com/NevioServiceCenter/SC-UI-MFE-FlightSearch"
  resource_group_name = "amedeusnevio_rg"
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1704" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - Global-instance"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/global-instance"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1705" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - SC-API-Checkout-Passengers"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/sc-api-checkout-passengers"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1706" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - SC-UI-Archive"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/sc-ui-archive"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1707" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - SC-UI-MFE-Admin"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/sc-ui-mfe-admin"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1708" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - SC-UI-MFE-FlightSearch"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/sc-ui-mfe-flightsearch"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1709" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - SC-UI-MFE-ScratchPad"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/sc-ui-mfe-scratchpad"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1710" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - SC-UI-Shell-SeviceCenter"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/sc-ui-shell-sevicecenter"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1711" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - ServiceCenter-UI"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/servicecenter-ui"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1712" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - func-Baggage-Policies-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/func-baggage-policies-dev-eus"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1713" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - func-app-config-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/func-app-config-dev-eus"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1714" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - func-checkout-confirm-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/func-checkout-confirm-dev-eus"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1715" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - func-checkout-initiate-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/func-checkout-initiate-dev-eus"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1716" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - func-checkout-passengers-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/func-checkout-passengers-dev-eus"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1717" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - func-checkout-update-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/func-checkout-update-dev-eus"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1718" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - func-fare-condition-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/func-fare-condition-dev-eus"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1719" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - func-payment-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/func-payment-dev-eus"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1720" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - func-rbac-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/func-rbac-dev-eus"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1721" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - func-retrieve-order-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/func-retrieve-order-dev-eus"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1722" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - func-searchpanel-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/func-searchpanel-dev-eus"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1723" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - func-seat-map-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/func-seat-map-dev-eus"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1724" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - func-shop-offer-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/func-shop-offer-dev-eus"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1725" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - func-token-dev-eus202507101214"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/func-token-dev-eus202507101214"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_smart_detector_alert_rule" "res-1726" {
  description         = "Failure Anomalies notifies you of an unusual rise in the rate of failed HTTP requests or dependency calls."
  detector_type       = "FailureAnomaliesDetector"
  frequency           = "PT1M"
  name                = "Failure Anomalies - testing-function-app-mock-searchpanel"
  resource_group_name = "amedeusnevio_rg"
  scope_resource_ids  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourcegroups/amedeusnevio_rg/providers/microsoft.insights/components/testing-function-app-mock-searchpanel"]
  severity            = "Sev3"
  action_group {
    ids = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.Insights/actionGroups/application insights smart detection"]
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_monitor_action_group" "res-1727" {
  name                = "Application Insights Smart Detection"
  resource_group_name = "amedeusnevio_rg"
  short_name          = "SmartDetect"
  arm_role_receiver {
    name                    = "Monitoring Contributor"
    role_id                 = "749f88d5-cbae-40b8-bcfc-e573ddc772fa"
    use_common_alert_schema = true
  }
  arm_role_receiver {
    name                    = "Monitoring Reader"
    role_id                 = "43d0d8ad-25c7-4714-9337-8ba259a9fe05"
    use_common_alert_schema = true
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1728" {
  application_type    = "web"
  location            = "eastus"
  name                = "SC-API-Checkout-Passengers"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1729" {
  application_type    = "web"
  location            = "eastus2"
  name                = "SC-UI-Archive"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1730" {
  application_type    = "web"
  location            = "eastus2"
  name                = "SC-UI-MFE-Admin"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1731" {
  application_type    = "web"
  location            = "eastus2"
  name                = "SC-UI-MFE-FlightSearch"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1732" {
  application_type    = "web"
  location            = "eastus2"
  name                = "SC-UI-MFE-ScratchPad"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1733" {
  application_type    = "web"
  location            = "eastus2"
  name                = "SC-UI-Shell-SeviceCenter"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1734" {
  application_type    = "web"
  location            = "eastus2"
  name                = "ServiceCenter-UI"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1735" {
  application_type    = "web"
  location            = "eastus"
  name                = "func-Baggage-Policies-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  tags = {
    environment = "dev"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1736" {
  application_type    = "web"
  location            = "eastus"
  name                = "func-app-config-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1737" {
  application_type    = "web"
  location            = "eastus"
  name                = "func-checkout-confirm-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1738" {
  application_type    = "web"
  location            = "eastus"
  name                = "func-checkout-initiate-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1739" {
  application_type    = "web"
  location            = "eastus"
  name                = "func-checkout-passengers-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1740" {
  application_type    = "web"
  location            = "eastus"
  name                = "func-checkout-update-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1741" {
  application_type    = "web"
  location            = "eastus"
  name                = "func-fare-condition-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1742" {
  application_type    = "web"
  location            = "eastus"
  name                = "func-payment-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1743" {
  application_type    = "web"
  location            = "eastus"
  name                = "func-rbac-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1744" {
  application_type    = "web"
  location            = "eastus"
  name                = "func-retrieve-order-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1745" {
  application_type    = "web"
  location            = "eastus"
  name                = "func-searchpanel-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1746" {
  application_type    = "web"
  location            = "eastus"
  name                = "func-seat-map-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  tags = {
    environment = "development"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1747" {
  application_type    = "web"
  location            = "eastus"
  name                = "func-shop-offer-dev-eus"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1748" {
  application_type    = "web"
  location            = "eastus"
  name                = "func-token-dev-eus202507101214"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1749" {
  application_type    = "web"
  location            = "eastus"
  name                = "offerapi"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights" "res-1750" {
  application_type    = "web"
  location            = "eastus"
  name                = "testing-function-app-mock-searchpanel"
  resource_group_name = "amedeusnevio_rg"
  sampling_percentage = 0
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
resource "azurerm_application_insights_workbook" "res-1751" {
  data_json = jsonencode({
    fallbackResourceIds = ["Azure Monitor"]
    isLocked            = true
    items = [{
      content = {
        chartId   = "workbook2915da1a-92f3-4be5-911b-d7849f0417ec"
        chartType = 2
        graphSettings = {
          centerContent = {
            columnMatch = "microsoft.compute/virtualmachines-Other-Percentage CPU"
            formatter   = 1
            numberFormat = {
              options = {
                maximumFractionDigits    = 2
                maximumSignificantDigits = 3
              }
              unit = 17
            }
          }
          topContent = {
            columnMatch = "Subscription"
            formatter   = 1
          }
          type = 0
        }
        gridSettings = {
          formatters = [{
            columnMatch = "Subscription"
            formatter   = 5
            }, {
            columnMatch = "Name"
            formatOptions = {
              linkTarget = "Resource"
            }
            formatter = 13
            }, {
            columnMatch = "microsoft.compute/virtualmachines-Other-Percentage CPU Timeline"
            formatter   = 5
            }, {
            columnMatch = "microsoft.compute/virtualmachines-Other-Percentage CPU"
            formatter   = 1
            numberFormat = {
              options = null
              unit    = 1
            }
          }]
          labelSettings = [{
            columnId = "microsoft.compute/virtualmachines-Other-Percentage CPU"
            label    = "Percentage CPU (Average)"
            }, {
            columnId = "microsoft.compute/virtualmachines-Other-Percentage CPU Timeline"
            label    = "Percentage CPU Timeline"
          }]
          rowLimit = 10000
        }
        mapSettings = {
          itemColorSettings = {
            colorAggregation = "Sum"
            heatmapPalette   = "greenRed"
            nodeColorField   = "microsoft.compute/virtualmachines-Other-Percentage CPU"
            type             = "heatmap"
          }
          legendAggregation = "Sum"
          legendMetric      = "microsoft.compute/virtualmachines-Other-Percentage CPU"
          locInfo           = "AzureResource"
          locInfoColumn     = "Name"
          sizeAggregation   = "Sum"
          sizeSettings      = "microsoft.compute/virtualmachines-Other-Percentage CPU"
        }
        metricScope = 0
        metrics = [{
          aggregation = 4
          metric      = "microsoft.compute/virtualmachines-Other-Percentage CPU"
          namespace   = "microsoft.compute/virtualmachines"
          splitBy     = null
        }]
        resourceIds  = [azurerm_linux_virtual_machine.res-525.id]
        resourceType = "microsoft.compute/virtualmachines"
        size         = 0
        timeContext = {
          durationMs = 3600000
        }
        version = "MetricsItem/2.0"
      }
      name = "metric - 0"
      type = 10
    }]
    version = "Notebook/1.0"
  })
  display_name        = "Vm"
  location            = "eastus"
  name                = "2a47f22f-c4bd-4b7a-b744-7736d39d5100"
  resource_group_name = "amedeusnevio_rg"
}
resource "azurerm_application_insights_workbook" "res-1752" {
  data_json = jsonencode({
    fallbackResourceIds = ["Azure Monitor"]
    isLocked            = false
    items = [{
      content = {
        chartId   = "workbook7d69ee21-665e-4629-b678-6a00d301b9f6"
        chartType = 2
        gridSettings = {
          rowLimit = 10000
        }
        metricScope = 0
        metrics = [{
          aggregation = 4
          metric      = "microsoft.dbforpostgresql/flexibleservers-Traffic-active_connections"
          namespace   = "microsoft.dbforpostgresql/flexibleservers"
          splitBy     = null
          }, {
          aggregation = 1
          metric      = "microsoft.dbforpostgresql/flexibleservers-Errors-connections_failed"
          namespace   = "microsoft.dbforpostgresql/flexibleservers"
          }, {
          aggregation = 3
          metric      = "microsoft.dbforpostgresql/flexibleservers-Availability-is_db_alive"
          namespace   = "microsoft.dbforpostgresql/flexibleservers"
        }]
        resourceIds  = ["/subscriptions/6894432a-17c6-42c4-8118-d547be97aca4/resourceGroups/amedeusnevio_rg/providers/Microsoft.DBforPostgreSQL/flexibleServers/nevioscuidb"]
        resourceType = "microsoft.dbforpostgresql/flexibleservers"
        size         = 0
        timeContext = {
          durationMs = 3600000
        }
        version = "MetricsItem/2.0"
      }
      name = "metric - 0"
      type = 10
    }]
    version = "Notebook/1.0"
  })
  display_name        = "Nevio Database"
  location            = "eastus"
  name                = "3bdad87e-932b-493d-8faa-174701ff401a"
  resource_group_name = "amedeusnevio_rg"
  tags = {
    application = "amedeus"
  }
  depends_on = [
    azurerm_resource_group.res-0
  ]
}
